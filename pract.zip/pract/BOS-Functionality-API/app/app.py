from flask import Flask, request
import numpy as np
import boto3
import os
import io
import json
import pandas as pd
from io import StringIO
from urllib.parse import urlparse
from sqlalchemy import create_engine
from botocore.exceptions import ClientError
from flask_restful import reqparse, Api, Resource
from sklearn.metrics import log_loss, accuracy_score, roc_auc_score, f1_score, mean_absolute_error, mean_squared_error
from sklearn.model_selection import train_test_split
from sshtunnel import SSHTunnelForwarder
from math import sqrt
from datetime import datetime
from flask_cors import CORS, cross_origin
from flask import jsonify

app = Flask(__name__)
CORS(app, support_credentials=True)


@app.route('/filechecker', methods = ['GET'])
@cross_origin(supports_credentials=True)
def FileChecker():
    args = request.args.to_dict()
    return jsonify(file_checker(args['fileid']))


@app.route('/get_headers', methods = ['GET'])
@cross_origin(supports_credentials=True)
def GetHeaders():
    args = request.args.to_dict()
    return jsonify(get_headers(args['filepath']))


@app.route('/evaluation', methods = ['GET'])
@cross_origin(supports_credentials=True)
def Eval_files():
    args = request.args.to_dict()
    return jsonify(get_evaluation_value(args['fileid']))


@app.route('/metadata', methods = ['GET'])
@cross_origin(supports_credentials=True)
def File_metadata():
    args = request.args.to_dict()
    res = get_metadata(args['filepath'])
    return jsonify({"size":res[0], "data_types": json.loads(res[1].to_json())})


@app.route('/validation', methods = ['GET'])
@cross_origin(supports_credentials=True)
def Validation_checker():
    args = request.args.to_dict()
    res = validation_checker(args['fileid'], args['primary'], args['dependent'])
    return jsonify({"message": res[0], "flag": res[1]})

@app.route('/split_data', methods = ['GET'])
@cross_origin(supports_credentials=True)
def Test_data_preparation():
    args = request.args.to_dict()
    return jsonify(test_data_prepare(args['filepath'], args['test_file_path'], args['train_file_path'], args['dependent']))


def test_data_prepare(file_url, testfile_url, train_file_url, dependent):
    try:
        train, test = train_test_split(get_pdfile(file_url), test_size=0.25)
        pd_to_s3(train, train_file_url)
        del test[dependent]
        pd_to_s3(test, testfile_url)
    except ClientError as e:
        print(e)
        return False
    return True


def validation_checker(fileid, primary, dependent):
    row_data = execute_query("select challenge_statement_original_file_path from VChallengeFileUpload where `challenge_statement_fileupload_id` = {};".format(fileid))
    # primary = row_data[0][10]
    # dependent = row_data[0][9]
    dataset = get_pdfile(row_data[0][0])
    if dataset[primary].isnull().values.any():
        message = "Primary key column has null values"
        flag = 1
    elif dataset[primary].isna().values.any():
        message = "Primary key column has not defined values"
        flag = 1
    elif dataset[dependent].isnull().values.any():
        message = "Dependent variable has null values"
        flag = 1
    elif dataset[dependent].isna().values.any():
        message = "Dependent variable has not defined values"
        flag = 1
    elif not dataset[primary].is_unique:
        message = "Primary key column has duplicate values"
        flag = 1
    else:
        message = "Primary key & dependent variable validated"
        flag = 0
    return [message, flag]


def get_metadata(filepath):
    dataset = get_pdfile(filepath)
    matrix = dataset.shape
    matrix = list(matrix)
    my_json_matrix = json.dumps(matrix)

    data_type = dataset.dtypes
    data_type = pd.DataFrame(data_type)
    data_type.reset_index(level=0, inplace=True)
    data_type.columns = ['column_name', 'data_type']
    return [my_json_matrix, data_type]


def get_evaluation_value(fileid):

    stmt = "select * from VChallengeFileUpload where `challenge_statement_fileupload_id` = {};".format(fileid)
    stmt2 = "SELECT challenge_evalution_type_Name FROM VChallengeEvaluationTypeMaster where challenge_evaluation_type_id = (SELECT challenge_evaluation_type_id FROM VChallengeStatement where challenge_statement_id = ( SELECT challenge_statement_id FROM VChallengeFileUpload where challenge_statement_fileupload_id = {}));".format(fileid)
    rowdata = execute_query(stmt)
    param_row = execute_query(stmt2)
    test = get_pdfile(rowdata[0][4])
    submission = get_pdfile(rowdata[0][6])
    dependent = rowdata[0][9]
    eval_param = param_row[0][0]
    eval_param = eval_param.lower()
    if eval_param == "log loss":
        eval_score = submission_score_logloss(test, submission, dependent)
    elif eval_param == "accuracy":
        eval_score = submission_score_accuracy(test, submission, dependent)
    elif eval_param == "auc-roc":
        eval_score = submission_score_auc(test, submission, dependent)
    elif eval_param == "f1 score":
        eval_score = submission_score_f1(test, submission, dependent)
    elif eval_param == "mean absolute error":
        eval_score = submission_score_mae(test, submission, dependent)
    elif eval_param == "mean squared error":
        eval_score = submission_score_mse(test, submission, dependent)
    elif eval_param == "root mean square error":
        eval_score = submission_score_rmse(test, submission, dependent)
    else:
        return "Evaluation parameter is not valid"

    chal_stmt_id = rowdata[0][1]
    temp_res = execute_query("SELECT `participation_id`, `participant_user_id` from VChallenge_Participation_Request where `challenge_statement_id` = {} ".format(chal_stmt_id))
    user_id = temp_res[0][0]
    pusrid = temp_res[0][1]
    sou_s3 = rowdata[0][6]
    sub_file_id = 99
    instance_id = 99

    insert_stmt = "INSERT INTO VLifeSchemaNew.VBose_Submission_Table (`user_id`, `challenge_statement_id`, `participant_user_id`, `instance_id`, `submission_time`, `evaluation_metric`, `evaluation_score`, `submission_file_id`, `source_s3`) VALUES ('{}', '{}', '{}', '{}', '{}', '{}', '{}', '{}', '{}');".format(user_id, chal_stmt_id, pusrid, instance_id, datetime.now(), eval_param, eval_score, sub_file_id, sou_s3)
    try:
        engine = create_engine("mysql+pymysql://xlabs_root:wSEbT4TF6YT8DtDQBZRK@vlife-dev-cluster.cluster-csdjjjdtlqoo.us-east-2.rds.amazonaws.com:3306/VLifeSchemaNew")
        connection = engine.connect()
        connection.execute(insert_stmt)
        connection.close()
    except Exception as e:
        print(e)
        return {"flag": 0, "message": "error"}
    return {"flag": 1, "message": "successful"}


def get_pdfile(file_url):
    o = urlparse(file_url)
    bucket = o.netloc
    key = o.path
    client = boto3.client('s3', aws_access_key_id='AKIAX6AGHAJCJFJ2OBDG', aws_secret_access_key='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', verify=False)
    obj = client.get_object(Bucket=bucket, Key=key.lstrip('/'))
    return pd.read_csv(obj['Body'])


def pd_to_s3(dataframe, file_url):
    o = urlparse(file_url)
    bucket = o.netloc
    key = o.path
    try:
        client = boto3.client('s3', aws_access_key_id='AKIAX6AGHAJCJFJ2OBDG', aws_secret_access_key='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')
        bytes_to_write = dataframe.to_csv(None, index=False).encode()
        # print("==> B: {}, K {}, path: {}".format(bucket,key,file_url ))
        client.put_object(Bucket=bucket, Key=key.lstrip('/'), Body=bytes_to_write)
    except Exception as e:
        print(e)
        return False
    return True

def get_headers(file_url):
    return list(get_pdfile(file_url).columns)


def file_checker(fileid):
    engine = create_engine("mysql+pymysql://xlabs_root:wSEbT4TF6YT8DtDQBZRK@vlife-dev-cluster.cluster-csdjjjdtlqoo.us-east-2.rds.amazonaws.com:3306/VLifeSchemaNew")
    stmt = "select * from VChallengeFileUpload where `challenge_statement_fileupload_id` = {};".format(fileid)
    connection = engine.connect()
    rowdata = connection.execute(stmt).fetchall()
    test = get_pdfile(rowdata[0][4])
    submission = get_pdfile(rowdata[0][6])
    dependent = rowdata[0][9]
    result = submission[dependent].isnull().values.any()
    result1 = submission[dependent].isna().values.any()
    result = np.where(result, False, True)
    result1 = np.where(result, True, False)
    result2 = np.where(test[dependent].dtypes == submission[dependent].dtypes, True, False)
    del test[dependent], submission[dependent]
    result3 = np.where(test.equals(submission), True, False)

    if not result:
        return {'message': "Submitted column has null values", "flag": 1}
    elif not result1:
        return {'message': "Submitted column has nan values", "flag": 1}
    elif not result2:
        return {'message': "Dependent variable data type mis-match", "flag": 1}
    elif not result3:
        return {'message': "Submitted file structure mis-match", "flag": 1}
    else:
        return {'message': "Submission Successful", "flag": 0}


def submission_score_logloss(test, submission, dependent):
    return log_loss(test[dependent], submission[dependent])


def submission_score_accuracy(test, submission, dependent):
    return accuracy_score(test[dependent], submission[dependent])


def submission_score_auc(test, submission, dependent):
    return roc_auc_score(test[dependent], submission[dependent])


def submission_score_f1(test, submission, dependent):
    return f1_score(test[dependent], submission[dependent])


def submission_score_mae(test, submission, dependent):
    return mean_absolute_error(test[dependent], submission[dependent])


def submission_score_mse(test, submission, dependent):
    return mean_squared_error(test[dependent], submission[dependent])


def submission_score_rmse(test, submission, dependent):
    return sqrt(mean_squared_error(test[dependent], submission[dependent]))


def upload_file(file_name, bucket, object_name=None):
    if object_name is None:
        object_name = file_name
    s3_client = boto3.client('s3',aws_access_key_id='AKIAX6AGHAJCJFJ2OBDG',aws_secret_access_key='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',verify=False)
    try:
        response = s3_client.upload_file(file_name, bucket, object_name)
    except ClientError as e:
        print(e)
        return False
    return True


def execute_query(stmt):
    engine = create_engine("mysql+pymysql://xlabs_root:wSEbT4TF6YT8DtDQBZRK@vlife-dev-cluster.cluster-csdjjjdtlqoo.us-east-2.rds.amazonaws.com:3306/VLifeSchemaNew")
    connection = engine.connect()
    res = connection.execute(stmt).fetchall()
    connection.close()
    return res


if __name__ == "__main__":
    # server = SSHTunnelForwarder(
    #     'ec2-18-222-111-229.us-east-2.compute.amazonaws.com',
    #     ssh_username="hyd",
    #     ssh_password="1234qwer$",
    #     remote_bind_address=('127.0.0.1', 8080)
    # )
    # server.start()
    app.run(host='0.0.0.0')

