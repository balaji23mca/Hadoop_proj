$(aws --profile vlife-dev ecr get-login --no-include-email --region us-east-2)
docker build -t vlifedock .
docker tag vlifedock:latest 545473888836.dkr.ecr.us-east-2.amazonaws.com/vlifedock:v9.3
docker push 545473888836.dkr.ecr.us-east-2.amazonaws.com/vlifedock:v9.3

kubectl delete -f ingress.yaml -n vlife
kubectl delete -f deployment.yml -n vlife

kubectl apply -f deployment.yml -n vlife
kubectl apply -f ingress.yaml -n vlife
