import socket
import re
import boto3
import pandas as pd
from datetime import datetime
from botocore.exceptions import ClientError
from urllib.parse import urlparse
from sklearn.metrics import log_loss, accuracy_score, roc_auc_score, f1_score, mean_absolute_error, mean_squared_error
from sqlalchemy import create_engine
from math import sqrt
import warnings
warnings.filterwarnings('ignore')

def evaluate(file_name):
    servr = socket.gethostname()
    servr = servr[18:]
    match = re.search("-", servr)
    servr = servr[:match.span()[0]]
    url = "https://ide-" + servr + ".services.vlife.virtusa.dev/lab"

    stmt1 = "SELECT user_id, challenge_statement_id FROM `vlife-ide-manager-dev`.`ide-instance` where url = '{}'".format(url)
    rowdata1 = execute_query(stmt1)
    user_id = rowdata1[0][0]
    challenge_statement_id = rowdata1[0][1]
    
    stmt = "select challenge_statement_test_file_path,challenge_statement_dependent from VLifeSchemaNew.VChallengeFileUpload where `challenge_statement_id` = {};".format(challenge_statement_id)
    stmt2 = "SELECT challenge_evalution_type_Name FROM VLifeSchemaNew.VChallengeEvaluationTypeMaster where challenge_evaluation_type_id = (SELECT challenge_evaluation_type_id FROM VLifeSchemaNew.VChallengeStatement where challenge_statement_id = ( SELECT challenge_statement_id FROM VLifeSchemaNew.VChallengeFileUpload where challenge_statement_id = {}));".format(challenge_statement_id)
    rowdata = execute_query(stmt)
    # print("row data: {}".format(rowdata))
    param_row = execute_query(stmt2)
    # print("param data: {}".format(param_row))
    test = get_pdfile(rowdata[0][0])
    submission = pd.read_csv(file_name)
    dependent = rowdata[0][1]
    eval_param = param_row[0][0]
    eval_param = eval_param.lower()
    if eval_param == "log loss":
        eval_score = submission_score_logloss(test, submission, dependent)
    elif eval_param == "accuracy":
        eval_score = submission_score_accuracy(test, submission, dependent)
    elif eval_param == "auc-roc":
        eval_score = submission_score_auc(test, submission, dependent)
    elif eval_param == "f1 score":
        eval_score = submission_score_f1(test, submission, dependent)
    elif eval_param == "mean absolute error":
        eval_score = submission_score_mae(test, submission, dependent)
    elif eval_param == "mean squared error":
        eval_score = submission_score_mse(test, submission, dependent)
    elif eval_param == "root mean square error":
        eval_score = submission_score_rmse(test, submission, dependent)
    else:
        return "Evaluation parameter is not valid"

    chal_stmt_id = challenge_statement_id
    temp_res = execute_query("SELECT `participation_id`, `participant_user_id` from VLifeSchemaNew.VChallenge_Participation_Request where `challenge_statement_id` = {} ".format(chal_stmt_id))
    user_id = temp_res[0][0]
    pusrid = temp_res[0][1]
    sou_s3 = 99
    sub_file_id = 99
    instance_id = 99

    insert_stmt = "INSERT INTO VLifeSchemaNew.VBose_Submission_Table (`user_id`, `challenge_statement_id`, `participant_user_id`, `instance_id`, `submission_time`, `evaluation_metric`, `evaluation_score`, `submission_file_id`, `source_s3`) VALUES ('{}', '{}', '{}', '{}', '{}', '{}', '{}', '{}', '{}');".format(user_id, chal_stmt_id, pusrid, instance_id, datetime.now(), eval_param, eval_score, sub_file_id, sou_s3)
    try:
        engine = create_engine("mysql+pymysql://xlabs_root:wSEbT4TF6YT8DtDQBZRK@vlife-dev-cluster.cluster-csdjjjdtlqoo.us-east-2.rds.amazonaws.com:3306/VLifeSchemaNew")
        connection = engine.connect()
        connection.execute(insert_stmt)
        connection.close()
    except Exception as e:
        print(e)
        print({"flag": 0, "message": "error"})
    print({"flag": 1, "message": "successful"})


def submission_score_logloss(test, submission, dependent):
    return log_loss(test[dependent], submission[dependent])


def submission_score_accuracy(test, submission, dependent):
    return accuracy_score(test[dependent], submission[dependent])


def submission_score_auc(test, submission, dependent):
    return roc_auc_score(test[dependent], submission[dependent])


def submission_score_f1(test, submission, dependent):
    return f1_score(test[dependent], submission[dependent])


def submission_score_mae(test, submission, dependent):
    return mean_absolute_error(test[dependent], submission[dependent])


def submission_score_mse(test, submission, dependent):
    return mean_squared_error(test[dependent], submission[dependent])


def submission_score_rmse(test, submission, dependent):
    return sqrt(mean_squared_error(test[dependent], submission[dependent]))

def execute_query(stmt):
    engine = create_engine("mysql+pymysql://xlabs_root:wSEbT4TF6YT8DtDQBZRK@vlife-dev-cluster.cluster-csdjjjdtlqoo.us-east-2.rds.amazonaws.com:3306/VLifeSchemaNew")
    connection = engine.connect()
    res = connection.execute(stmt).fetchall()
    connection.close()
    return res

def get_pdfile(file_url):
    o = urlparse(file_url)
    bucket = o.netloc
    key = o.path
    client = boto3.client('s3', aws_access_key_id='AKIAX6AGHAJCJFJ2OBDG', aws_secret_access_key='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', verify=False)
    obj = client.get_object(Bucket=bucket, Key=key.lstrip('/'))
    return pd.read_csv(obj['Body'])


def read(f_name):
    servr = socket.gethostname()
    servr = servr[18:]
    match = re.search("-", servr)
    servr = servr[:match.span()[0]]
    url = "https://ide-" + servr + ".services.vlife.virtusa.dev/lab"
    stmt1 = "SELECT user_id, challenge_statement_id FROM `vlife-ide-manager-dev`.`ide-instance` where url = '{}'".format(url)
    rowdata1 = execute_query(stmt1)
    user_id = rowdata1[0][0]
    challenge_statement_id = rowdata1[0][1]
    stmt2 = "SELECT challenge_statement_training_file_path FROM VLifeSchemaNew.VChallengeFileUpload where challenge_statement_id = {};".format(challenge_statement_id)
    rdata = execute_query(stmt2)
    s3_url = rdata[0][0]
    try:
        return get_pdfile(s3_url+f_name)
    except ClientError as e:
        return "File not found"


def list_files():
    servr = socket.gethostname()
    servr = servr[18:]
    match = re.search("-", servr)
    servr = servr[:match.span()[0]]
    url = "https://ide-" + servr + ".services.vlife.virtusa.dev/lab"

    stmt1 = "SELECT user_id, challenge_statement_id FROM `vlife-ide-manager-dev`.`ide-instance` where url = '{}'".format(url)
    rowdata1 = execute_query(stmt1)
    user_id = rowdata1[0][0]
    challenge_statement_id = rowdata1[0][1]

    stmt = "select challenge_statement_training_file_path,challenge_statement_dependent from VLifeSchemaNew.VChallengeFileUpload where `challenge_statement_id` = {};".format(challenge_statement_id)
    rowdata = execute_query(stmt)
    s3_path = rowdata[0][0]
    o = urlparse(s3_path)
    bucket = o.netloc
    b_path = o.path
    client = boto3.client('s3', aws_access_key_id='AKIAX6AGHAJCJFJ2OBDG', aws_secret_access_key='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')
    fname_list = []
    for key in client.list_objects(Bucket=bucket)['Contents']:
        if b_path[1:] in key['Key']:
            fname = key['Key'].split('/')[-1]
            if fname != "":
                fname_list.append(fname)
    print(fname_list)