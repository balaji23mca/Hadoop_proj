$(aws --profile vlife-dev ecr get-login --no-include-email --region us-east-2)
docker build -t vlifejupyteride .
docker tag vlifejupyteride:latest 545473888836.dkr.ecr.us-east-2.amazonaws.com/vlife-jupyter-ide:1.0.24
docker push 545473888836.dkr.ecr.us-east-2.amazonaws.com/vlife-jupyter-ide:1.0.24

helm del --purge vlife-jupyter-ide;
helm install -n vlife-jupyter-ide --namespace ide -f vlife-jupyter-ide/values.yaml --version 1.0.24 vlife-jupyter-ide/ 