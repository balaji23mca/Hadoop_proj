#!/bin/sh

python work/bose.py