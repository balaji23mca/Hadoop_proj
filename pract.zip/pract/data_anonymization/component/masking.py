import logging
import re

def pattern_masking(ptrn, ip):
    op = ""
    if len(ptrn) != len(ip):
        ip = ip + (len(ptrn) - len(ip)) * "X" if len(ip) < len(ptrn) else ip[:len(ptrn)]
    if len(ptrn) == len(ip):
        for i in range(len(ip)):
            if ptrn[i] == "X" or ptrn[i] == "x":
                op += "X"
            else:
                op += ip[i]
    return op


def anonymize(column_name, row, inputTabledf):
    length = len(inputTabledf)
    policy = row.get('policy', None)
    if policy:
        parameters = eval(policy)

    if parameters and isinstance(parameters, dict):
        try:
            value = parameters.get('value', None)  ## value to replace
            value_length = len(value) if value is not None else 0  ## size to replace
            location = parameters.get('location', None)  ## mask start  end
            pattern = parameters.get('pattern', None)
            condition = parameters.get('condition', None)
        except Exception as e:
            print(e)

    for i, row in inputTabledf.iterrows():
        item_org_value = str(row.get(column_name, None))
        item = item_org_value
        # item = item.replace('-', '')
        if pattern is not None:
            try:
                masked = pattern_masking(pattern, item)
                inputTabledf.set_value(i, column_name, masked)
            except Exception as e:
                inputTabledf.set_value(i, column_name, item_org_value)
                logging.error(e)
        elif condition is not None:
            try:
                masked = condition_masking(condition, item)
                inputTabledf.set_value(i, column_name, masked)
            except Exception as e:
                inputTabledf.set_value(i, column_name, item_org_value)

        else:
            try:
                if location == 'end':
                    masked = item.replace(item, item[0:len(item) - value_length] + value)
                elif location == 'start':
                    masked = item.replace(item, value + item[value_length:len(item)])
                else:
                    masked = item
                    for itr in item:
                        if itr.isalnum():
                            masked = masked.replace(itr, value)
                inputTabledf.set_value(i, column_name, masked)
            except Exception as e:
                inputTabledf.set_value(i, column_name, item_org_value)

    # inputTabledf[column_name] = inputTabledf[column_name].astype(str)
    # if location == 'end':
    #     inputTabledf[column_name]  = inputTabledf[column_name].map(lambda x: x.replace(x, x[0:len(x) - value_length] + value))
    # elif location == 'start':
    #     inputTabledf[column_name] = inputTabledf[column_name].map(lambda x: x.replace(x,  value + x[value_length:len(x)]))
    return inputTabledf[column_name]


def condition_masking(condtn, ip):
    op = ip
    for itr in range(len(condtn)):
        val = condtn[itr]['value']
        position = condtn[itr]['position']
        op_len = len(op)
        if position[1]-1 < position[0]:
            pass
        if op_len < position[1]:
            op += (position[1] - op_len) * val
        op_len = len(op)
        for n in range(op_len):
            if n in range(position[0]-1, position[1]):
                op = op[:n] + val + op[n+1:]
    return op
