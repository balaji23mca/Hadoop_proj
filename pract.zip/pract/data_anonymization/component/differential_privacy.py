import random

import numpy as np
import pandas as pd


def process_value(inputTabledf_column_name, p, k):
    """
    :param value: The value to apply the differentially private scheme to.
    :param     p: The probability of returning a random value instead of the true one
    :param     k: The probability of returning 1 when generating a random value
    :    returns: A new, differentially private value
    """
    n = len(inputTabledf_column_name)

    unique_list = pd.unique(inputTabledf_column_name)
    values = []
    if len(unique_list) == 2:
        for value in inputTabledf_column_name:
            rv = random.random()
            if rv <= p:
                # we return a random value
                rv = random.random()
                # index = rv*len()
                if rv <= k:
                    values.append(unique_list[0])
                else:
                    values.append(unique_list[1])
            else:
                values.append(value)

    if len(unique_list) == 3:
        for value in inputTabledf_column_name:
            rv = random.random()
            if rv <= p:
                # we return a random value
                rv = random.random()
                index = random.randint(0, n)
                if unique_list.index(value) == index:
                    index = (index + 1) % n
                if rv <= k:
                    values.append(unique_list[index])
                else:
                    values.append(unique_list[index])
            else:
                values.append(value)

    if len(unique_list) > 3:
        for value in inputTabledf_column_name:
            rv = random.random()
            if rv <= p:
                # we return a random value
                rv = random.random()
                index = random.randint(0, n)
                if unique_list.index(value) == index:
                    index = (index + 1) % n
                values.append(unique_list[index])
            else:
                values.append(value)

    return values


def anonymize(column_name, row, inputTabledf, p=0.5, k=0.5):
    # p = 0.7
    # k = 0.3

    values = process_value(inputTabledf[column_name], p, k)

    # values = []
    # # df['income_binary'] = np.where(df['income'] == '<=50k', 0, 1)
    # # df['income_dp'] = 0
    # for i, x in enumerate(inputTabledf[column_name]):
    #     values.append(process_value(x, p, k))

    inputTabledf[column_name] = np.array(values)

    return inputTabledf[column_name]
