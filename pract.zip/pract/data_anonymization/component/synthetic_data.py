from mimesis import Address
from mimesis import Datetime
from mimesis import Person


def anonymize(column_name, row, inputTabledf):
    length = len(inputTabledf)
    policy = row.get('policy', None)
    if policy:
        parameters = eval(policy)

    if parameters and isinstance(parameters, dict):
        try:
            api = parameters.get('api', None)
            method = parameters.get('method', None)
        except Exception as e:
            print(e)

    if api:
        if api == "Address":
            fake = Address()
            method = getattr(fake, method)
            value = [method() for _ in range(length)]

            return value

        elif api == "Datetime":
            fake = Datetime()
            method = getattr(fake, method)
            value = [method() for _ in range(length)]

            return value


    else:

        if method == 'id':
            import random
            seed = int(random.random() * 10000)
            value = []
            for j in range(length):
                seed = seed + 1
                value.append(seed)
            return value

        else:
            fake = Person()

            method = getattr(fake, method)
            value = [method() for _ in range(length)]

            return value


if __name__ == '__main__':
    import os
    import pandas as pd
    input_folder = "os.path.normpath(os.path.join(os.path.dirname(__file__), '../../../input/csv/"
    input_file = os.path.join(input_folder, "{}.csv".format("person"))
    inputTabledf = pd.read_csv(input_file)
    row = {"policy" : "{'method': 'city', 'api' : 'Address'}"}
    value = anonymize('city', row, inputTabledf)

    print(value)