import logging

import component
from component import aggregation;
from component import generalization, swapping, perturbation;
from component import masking, pseudonymization, aggregation;
from component import synthetic_data, noise_addition, differential_privacy;


def aggregation(column_name, row, inputTabledf):
    logging.info('pseudonymization technique executed on column --->  {}'.format(column_name))
    value = aggregation.anonymize(column_name, row, inputTabledf)
    return value


def masking(column_name, row, inputTabledf):
    logging.info('masking technique executed on column --->  {}'.format(column_name))
    value = component.masking.anonymize(column_name, row, inputTabledf)
    return value


def aggregation(column_name, row, inputTabledf):
    logging.info('pseudonymization technique executed on column --->  {}'.format(column_name))
    value = component.aggregation.anonymize(column_name, row, inputTabledf)
    return value


def pseudonymization(column_name, row, inputTabledf):
    logging.info('pseudonymization technique executed on column --->  {}'.format(column_name))
    value = component.pseudonymization.anonymize(column_name, row, inputTabledf)
    return value


def generalization(column_name, row, inputTabledf):
    logging.info('generalization technique executed on column --->  {}'.format(column_name))
    value = component.generalization.anonymize(column_name, row, inputTabledf)
    return value


def swapping(column_name, row, inputTabledf):
    logging.info('swapping technique executed on column --->  {}'.format(column_name))
    value = component.swapping.anonymize(column_name, row, inputTabledf)
    return value


def perturbation(column_name, row, inputTabledf):
    logging.info('perturbation technique executed on column --->  {}'.format(column_name))
    value = component.perturbation.anonymize(column_name, row, inputTabledf)
    return value


def synthetic_data(column_name, row, inputTabledf):
    logging.info('synthetic_data technique executed on column --->  {}'.format(column_name))
    value = component.synthetic_data.anonymize(column_name, row, inputTabledf)
    return value


def noise_addition(column_name, row, inputTabledf):
    logging.info('noise_addition technique executed on column --->  {}'.format(column_name))
    value = component.noise_addition.anonymize(column_name, row, inputTabledf)
    return value


def differential_privacy(column_name, row, inputTabledf):
    logging.info('differential_privacy technique executed on column --->  {}'.format(column_name))
    value = component.differential_privacy.anonymize(column_name, row, inputTabledf)
    return value
