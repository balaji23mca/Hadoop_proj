import numpy as np
import pandas as pd


def anonymize(column_name, row, inputTabledf):
    value = generalize_combination(inputTabledf, column_name)

    return value


def find_closest_lower_upper(value):
    """
    finding the closest lower and closest upper end for a given one value
    """
    evaluating_value = value

    bigger = []
    smaller = []
    for i in numeric_series_list:
        if i > evaluating_value:
            bigger.append(i)
        elif i < evaluating_value:
            smaller.append(i)

    if not smaller:
        closest_lower = evaluating_value
    else:
        closest_lower = max(smaller)

    if not bigger:
        closest_upper = evaluating_value
    else:
        closest_upper = min(bigger)

    return {"closest_upper": closest_upper, "closest_lower": closest_lower}


def create_generalized_value(value):
    """
    Creating a generalized value by finding the closest neighbors
    """
    # if not str(value).isdigit():
    #     return {value: numpy.nan}
    try:
        closest = find_closest_lower_upper(value)
    except Exception as e:
        return {value: "{0}-{1}".format(0, 0)}

    return {int(value): "{0}-{1}".format(int(closest["closest_lower"]), int(closest["closest_upper"]))}


def replace_dict_in_series(partial_series, replacement_list):
    gernalized_list = []
    for idx, val in partial_series.iteritems():
        try:
            value = replacement_list[idx]

            split_list = value.split('-')
            gernalized_value = np.random.randint(low=split_list[0], high=split_list[1])

        except Exception as e:
            gernalized_value = val

        gernalized_list.append(gernalized_value)
    return gernalized_list


def generalize_combination(representatives, colname_for_treatment):
    """
    Generalizing specific rows for a specified column. Depending on the setting either multiprocessed
    or single processed if already part of multiprocessing.
    """
    global numeric_series_list

    # unique = representatives.loc[representatives['count'] == 1]
    rows_to_be_anonymized = representatives[colname_for_treatment].values
    numeric_series = pd.to_numeric(representatives[colname_for_treatment], errors='coerce')
    numeric_series = numeric_series.dropna(how='any').unique()
    numeric_series_list = list(numeric_series)

    replacement_list = []

    for row in rows_to_be_anonymized:
        for key, value in create_generalized_value(row).items():
            replacement_list.append(value)

    return replacement_list
