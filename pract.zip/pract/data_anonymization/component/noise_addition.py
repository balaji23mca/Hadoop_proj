import random
import re
import math

def anonymize(column_name, row, inputTabledf):
    length = len(inputTabledf)

    policy = row.get('policy', None)
    if  policy:
        parameters = eval(policy)

    # value = inputTabledf[column_name].map(lambda x: x.replace(x, x[0:len(x) - 4] + value))
    noise = parameters.get('noise',None)
    low = parameters.get('low',None)
    high = parameters.get('high',None)
    p = parameters.get('p', None)

    if noise == 'number':
        inputTabledf[column_name] = generate_random_int(inputTabledf[column_name], low, high, p)

    elif noise == 'nanify':
        inputTabledf[column_name] = nanify(inputTabledf[column_name], p)

    return inputTabledf[column_name]


def generate_random_int(inputTabledf_column_name, low=0, high=100, p = 0.5):
    """ Generate and integer between low and high
        Arguments:
            val (value): ignored for now
        Kwargs:
            low   (int): low value (default: 0)
            high   (int): high value (default: 100)
        Returns:
            int
        TODO:
            - should val be used in some way?
    """

    for i in range(math.floor(len(inputTabledf_column_name)*p)):
        num = int(random.uniform(0, 1)*len(inputTabledf_column_name))
        if num == len(inputTabledf_column_name):
            num = num-1
        inputTabledf_column_name[num] += random.randint(low, high)
    inputTabledf_column_name = inputTabledf_column_name.map(lambda x: x + random.randint(low, high))
    return inputTabledf_column_name


# def generate_random_float(val, low=0, high=1.0):
#     """ Generate a float between low and high
#         Arguments:
#             val (value): ignored for now
#         Kwargs:
#             low   (int): low value (default: 0)
#             low   (int): high value (default: 1)
#         Returns:
#             float
#         TODO:
#             - should val be used in some way?
#     """
#     return random.uniform(low, high)

def nanify(inputTabledf_column_name, p):
    # """ Insert some random null values  """

    null_choices = [None, 'null', 'n/a', '', -1]

    for i in range(math.floor(len(inputTabledf_column_name)*p)):
        num = int(random.uniform(0, 1)*len(inputTabledf_column_name))
        if num == len(inputTabledf_column_name):
            num = num-1
        inputTabledf_column_name[num] = random.choice(null_choices)

    #inputTabledf_column_name = inputTabledf_column_name.map(lambda x: random.choice(null_choices))

    return inputTabledf_column_name