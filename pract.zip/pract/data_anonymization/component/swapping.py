def anonymize(column_name, row, inputTabledf):
    inputTabledf = inputTabledf.sample(frac=1).reset_index(drop=True)

    return inputTabledf[column_name]
