import pandas as pd


def anonymize(column_name, row, inputTabledf):
    value = perturbized_value(inputTabledf, column_name)

    return value


def find_closest_lower_upper(value):
    """
    finding the closest lower and closest upper end for a given one value
    """
    evaluating_value = int(value)

    bigger = []
    smaller = []
    for i in numeric_series_list:
        if int(i) > evaluating_value:
            bigger.append(int(i))
        elif int(i) < evaluating_value:
            smaller.append(int(i))

    if not smaller:
        closest_lower = evaluating_value
    else:
        closest_lower = max(smaller)

    if not bigger:
        closest_upper = evaluating_value
    else:
        closest_upper = min(bigger)

    distance_lower = int(evaluating_value) - int(closest_lower)
    distance_upper = int(closest_upper) - int(evaluating_value)

    if distance_lower == 0 or distance_upper == 0:
        return {evaluating_value: 0}

    if distance_lower > distance_upper:
        return {evaluating_value: closest_upper}
    else:
        return {evaluating_value: closest_lower}


def create_perturbed_value_smarter(value):
    """
    Creating a generalized value by finding the closest neighbors
    """
    # if not str(value).isdigit():
    #     return {value: numpy.nan}
    try:
        closest = find_closest_lower_upper(value)
    except Exception as e:
        return {value: value}

    return closest


def replace_dict_in_series(partial_series, replacement_list):
    gernalized_list = []
    for idx, val in partial_series.iteritems():
        try:
            value = replacement_list[idx]
            gernalized_value = value

        except Exception as e:
            gernalized_value = val

        gernalized_list.append(gernalized_value)
    return gernalized_list


def perturbized_value(representatives, colname_for_treatment):
    """
    Generalizing specific rows for a specified column. Depending on the setting either multiprocessed
    or single processed if already part of multiprocessing.
    """
    global numeric_series_list

    # unique = representatives.loc[representatives['count'] == 1]
    rows_to_be_anonymized = representatives[colname_for_treatment].values
    numeric_series = pd.to_numeric(representatives[colname_for_treatment], errors='coerce')
    numeric_series = numeric_series.dropna(how='any').unique()
    numeric_series_list = list(numeric_series)

    replacement_list = []

    for row in rows_to_be_anonymized:
        for key, value in create_perturbed_value_smarter(row).items():
            replacement_list.append(value)

    representatives[colname_for_treatment] = replace_dict_in_series(representatives[colname_for_treatment],
                                                                    replacement_list)

    return representatives[colname_for_treatment]


def _get_input_table(input_file):
    try:
        df = pd.read_csv(input_file)
        return df
    except Exception as e:
        return None


if __name__ == '__main__':
    representatives = _get_input_table("person.csv")
    colname_for_treatment = "salary"
    value = perturbized_value(representatives, colname_for_treatment, with_multiprocessing=False)
    print(value)
