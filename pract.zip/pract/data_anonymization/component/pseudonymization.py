import warnings

import numpy as np
import pandas as pd
import scipy.stats
from sklearn.preprocessing import LabelEncoder
from sklearn_pandas import DataFrameMapper

warnings.filterwarnings("ignore")

import scipy.stats as st


def anonymize(column_name, row, inputTabledf):
    try:
        if _is_continous(inputTabledf[column_name]):
            value = generate_for_continous(column_name, inputTabledf)
        else:
            value = generate_for_categorical(column_name, inputTabledf)
    except Exception as e:
        return inputTabledf[column_name]
    return value


def generate_for_continous(column_name, inputTabledf):
    best_distributions = []
    length = len(inputTabledf)
    bin = int(length / 10)
    try:
        best_fit_name, best_fit_params = best_fit_distribution(inputTabledf[column_name], bin)
    except Exception as e:
        return inputTabledf[column_name]
    best_distributions.append((best_fit_name, best_fit_params))

    dist = getattr(scipy.stats, best_distributions[0])
    value = dist.rvs(size=length, *best_distributions[1])

    return value


def generate_for_categorical(column_name, inputTabledf):
    encoders = []
    encoders.append(([column_name], LabelEncoder()))
    mapper = DataFrameMapper(encoders, df_out=True)
    return mapper.fit_transform(inputTabledf.copy())


def _is_continous(col):
    is_continous = True
    nunique = col.nunique()
    if nunique < len(col) / 2:
        is_continous = False
    return is_continous


def best_fit_distribution(data, bins=200, ax=None):
    """Model data by finding best fit distribution to data"""
    # Get histogram of original data

    if np.histogram(data, bins=bins, density=True):
        y, x = np.histogram(data, bins=bins, density=True)
        x = (x + np.roll(x, -1))[:-1] / 2.0

        # Distributions to check
        DISTRIBUTIONS = [
            st.alpha, st.beta, st.dgamma, st.logistic, st.uniform
        ]

        # Best holders
        best_distribution = st.norm
        best_params = (0.0, 1.0)
        best_sse = np.inf

        # Estimate distribution parameters from data
        for idx, distribution in enumerate(DISTRIBUTIONS):

            # Try to fit the distribution
            try:
                # Ignore warnings from data that can't be fit
                with warnings.catch_warnings():
                    warnings.filterwarnings('ignore')

                    # fit dist to data
                    params = distribution.fit(data)

                    # Separate parts of parameters
                    arg = params[:-2]
                    loc = params[-2]
                    scale = params[-1]

                    # Calculate fitted PDF and error with fit in distribution
                    pdf = distribution.pdf(x, loc=loc, scale=scale, *arg)
                    sse = np.sum(np.power(y - pdf, 2.0))

                    # if axis pass in add to plot
                    try:
                        if ax:
                            pd.Series(pdf, x).plot(ax=ax)
                    except Exception:
                        pass

                    # identify if this distribution is better
                    if best_sse > sse > 0:
                        best_distribution = distribution
                        best_params = params
                        best_sse = sse

            except Exception:
                pass

        return (best_distribution.name, best_params)
