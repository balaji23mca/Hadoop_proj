import numpy as np


def anonymize(column_name, row, inputTabledf):
    p = eval(row['policy']).get("p", None)
    value = aggregation(column_name, p, inputTabledf)

    return value


def aggregation(column_name, p, inputTabledf):
    column = inputTabledf[column_name]

    p_len = int(len(column) * p)
    if column.dtype == np.float64 or column.dtype == np.int64:
        i = 0
        while i < len(column):
            if i + p_len > len(column):
                p_len = len(column) - i
            k_mean = column[i:i + p_len].mean()
            j = i
            while j < i + p_len:
                column[j] = k_mean
                j += 1
            i = i + p_len

    return column
