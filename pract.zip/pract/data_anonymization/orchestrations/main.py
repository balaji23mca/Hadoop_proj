import os
import time

import numpy as np
import pandas as pd
from component.helper import *
from orchestrations import setup_logging
from utils.helper import *

result = {}

def execute_new(configfile=None):
    start_time = time.time()

    parameter = readParameter(configfile)
    logging.info('--- starting data  anonymization  process ---')

    configdbStstus = checkDbConnections(parameter.configdburl, connectionType="Config DB")

    if configdbStstus == constants.CONNECTION_SUCCESSFUL:
        column_details = readTable(table_name=parameter.column_details, dburl=parameter.configdburl)
        table_name_list = column_details['table_name'].unique()

        for idx, table_name in enumerate(table_name_list):
            input_table = _get_input_table(table_name=table_name, dburl=parameter.inputdburl)
            if input_table is not None:
                input_table_df = input_table.copy()
                anonymize_df = pd.DataFrame()
                input_table_col = list(input_table_df.columns.values)  ## input DB column names
                column_details_of_table = column_details[column_details['table_name'] == table_name]

                column_details_of_table = column_details_of_table[
                    column_details_of_table['anonymize_technique'].notnull()]

                primary_key_list = _get_primary_key_list(column_details_of_table, table_name)

                if len(column_details_of_table) > 0:
                    for index, row in column_details_of_table.iterrows():
                        df_column_name = row['column_name']

                        anonymized_column = call_column_anonymizer(df_column_name, row, input_table_df)

                        anonymize_df = anonymize_df.assign(**{df_column_name: anonymized_column})

                    column_table_col = list(column_details_of_table['column_name'])

                    diff_list = np.setdiff1d(input_table_col, column_table_col)
                    if len(diff_list) > 0:
                        for idx, df_column_name in enumerate(diff_list):
                            anonymize_df = anonymize_df.assign(**{df_column_name: input_table_df[df_column_name]})


                else:
                    anonymize_df = input_table_df.copy()

                anonymize_df = anonymize_df[input_table_col]

                if primary_key_list:
                    mapping_df = pd.DataFrame()
                    for anonomizing_name in primary_key_list:
                        mapping_df[anonomizing_name] = input_table[anonomizing_name]

                        mapping_df['anonymized_' + anonomizing_name] = pd.Series(anonymize_df[anonomizing_name])
                        _saveDataframe(table_name + '_mapping_table', mapping_df, parameter.inputdburl, 'replace')

                _saveDataframe(table_name, anonymize_df, parameter.outputdburl, 'replace');
                try:
                    _test_anonymization(anonymize_df=anonymize_df, input_df=input_table, table_name = table_name);
                except Exception as e:
                    logging.error(e)

    _print_testing_values()
    logging.info('Total execution tine - : %.3f seconds' % (time.time() - start_time))


def _print_testing_values():
    try:
        logging.info('--- --- Testing result using wasserstein distance method (higher value signifies greater difference).')
        for column, distance in result.items():
            logging.info('--- For numeric column {}, wasserstein distance between Input and Annonymized value is {}'.format(column,distance ))
    except Exception as e:
        logging.error(e)

def _test_anonymization(anonymize_df, input_df, table_name):
    try:
        for col in input_df:
            if col in anonymize_df and (anonymize_df[col].dtype == np.float64 or anonymize_df[col].dtype == np.int64):
                result[table_name +'.'+ col] = wasserstein_dist(input_df[col], anonymize_df[col])
    except Exception as e:
        logging.error(e)

def _get_primary_key_list(column_details_of_table, table_name):
    column_details_of_table = column_details_of_table[column_details_of_table['table_name'] == table_name]
    primary_key_list = column_details_of_table[column_details_of_table.get('is_primary_key', None) == 'Y']
    primary_key_list = primary_key_list.get('column_name', None)
    primary_key_list = primary_key_list.tolist()
    if primary_key_list:
        return primary_key_list
    else:
        return []

def call_column_anonymizer(column_name, row, inputTable):
    switcher = {
        'masking': masking,
        'aggregation': aggregation,
        'pseudonymization': pseudonymization,
        'generalization': generalization,
        'swapping': swapping,
        'perturbation': perturbation,
        'synthetic_data': synthetic_data,
        'noise_addition': noise_addition,
        'differential_privacy': differential_privacy,
    }
    try:
        anonymize_technique = row.get('anonymize_technique', None)

        functionObj = switcher.get(anonymize_technique)
        if functionObj:
            row = functionObj(column_name, row, inputTable)
    except Exception as e:
        logging.error(e)
    return row

def _saveDataframe(table_name, df, dburl, if_exists):
    try:
        if dburl:
            saveDataframe(table_name, df, dburl, if_exists)
        else:
            output_folder = "os.path.normpath(os.path.join(os.path.dirname(__file__), '../../../output/csv/"
            output_file = os.path.join(output_folder, "{}.csv".format(table_name))
            df.to_csv(output_file, index=False)
    except Exception as e:
        logging.error(e)
        return None

def _get_input_table(table_name, dburl=None):
    try:
        if dburl:
            df = readTable(table_name=table_name, dburl=dburl)
        else:
            input_folder = "os.path.normpath(os.path.join(os.path.dirname(__file__), '../../../input/csv/"
            input_file = os.path.join(input_folder, "{}.csv".format(table_name))
            df = pd.read_csv(input_file)
        return df
    except Exception as e:
        logging.error(e)
        return None

if __name__ == '__main__':
    setup_logging()
    execute_new(configfile=os.path.normpath(
        os.path.join(os.path.dirname(__file__), '../anonymization_config_file.properties')));