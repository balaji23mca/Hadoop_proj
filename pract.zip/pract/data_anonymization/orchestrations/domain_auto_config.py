import os
import pandas as pd
from difflib import SequenceMatcher

from sqlalchemy import create_engine, text

from orchestrations import setup_logging
from utils.helper import *


def _get_input_table(table_name, dburl=None):
    try:
        if dburl:
            df = readTable(table_name=table_name, dburl=dburl)
        else:
            input_folder = "os.path.normpath(os.path.join(os.path.dirname(__file__), '../../../input/csv/"
            input_file = os.path.join(input_folder, "{}.csv".format(table_name))
            df = pd.read_csv(input_file)
        return df
    except Exception as e:
        logging.error(e)
        return None


def _saveDataframe(table_name, df, dburl, if_exists):
    try:
        if dburl:
            saveDataframe(table_name, df, dburl, if_exists)
        else:
            output_folder = "os.path.normpath(os.path.join(os.path.dirname(__file__), '../../../output/csv/"
            output_file = os.path.join(output_folder, "{}.csv".format(table_name))
            df.to_csv(output_file, index=False)
    except Exception as e:
        logging.error(e)
        return None


def sequenceMatcher(s_1, some_list):
    # s_1 = 'fname'
    #
    # some_list = ['first_name', 'last_name', 'address', 'city']
    s_1 = s_1.replace('_', ' ')
    some_list = pd.Series.tolist(some_list)
    dicts = {}
    for s in some_list:
        ratio = SequenceMatcher(a=s_1, b=s).ratio()
        if (ratio > 0.60):
            dicts[s] = SequenceMatcher(a=s_1, b=s).ratio()
        if ratio > 0.90:
            break
    if len(dicts) == 0:
        return None
    else:
        return (max(dicts, key=dicts.get))


def has_table(table_name, dburl):
    is_table_exists = False
    if isinstance(dburl, str):
        uri = dburl

    elif isinstance(dburl, dict):
        uri = dburl.get("uri", None)

    engine = create_engine(uri, echo=False)
    is_table_exists = engine.dialect.has_table(engine, table_name)

    return is_table_exists


def run_script_file(sql_file_path, dburl, table_name):
    if isinstance(dburl, str):
        uri = dburl

    elif isinstance(dburl, dict):
        uri = dburl.get("uri", None)
    try:
        file = open(sql_file_path, 'r+')
        engine = create_engine(uri, echo=False)
        if engine.connect():
            query = file.read().split(';')[0]
            query = query.replace("REPLACE_TABLE_NAME", table_name)
            engine.execute(text(query))
    except Exception as e:
        logging.error("Exception occurred at save_to_db".format(e))
        raise e


def execute(configfile):
    parameter = readParameter(configfile)

    table_name = parameter.input_table_name
    t_name = parameter.domain_policy

    input_table_df = _get_input_table(table_name=table_name, dburl=parameter.inputdburl)
    input_table_col = list(input_table_df.columns.values)  ## input DB column names

    new_df = pd.DataFrame()
    new_df = new_df.assign(**{"column_name": input_table_col})
    new_df = new_df.assign(**{"table_name": table_name})
    new_df['policy'] = None
    df_t = readTable(dburl=parameter.configdburl, table_name=t_name)

    for index, row in new_df.iterrows():
        c_name = row['column_name']

        expected_name = sequenceMatcher(c_name, df_t['column name'])
        if expected_name:
            new_df.at[index, 'anonymize_technique'] = \
                df_t.loc[df_t['column name'] == expected_name, 'anonymize technique'].values[0]

            policy_value = df_t.loc[df_t['column name'] == expected_name, 'parameters'].values[0]
            if policy_value:
                new_df.at[index, 'policy'] = str(policy_value)
            else:
                new_df.at[index, 'policy'] = None

    ## check and create config table :STARTS

    if has_table(parameter.column_details, parameter.configdburl):
        column_details = readTable(table_name=parameter.column_details, dburl=parameter.configdburl)  ## config table.
        column_details = column_details[column_details['table_name'].map(lambda x: str(x) != table_name)]
        _saveDataframe(table_name=parameter.column_details, df=column_details, dburl=parameter.configdburl,
                       if_exists='replace');

    if not has_table(parameter.column_details, parameter.configdburl):
        sql_file_path = os.path.normpath(
            os.path.join(os.path.dirname(__file__), '../input/sql_scripts/sql_execute.sql'))  # .format(sql_file_path)
        run_script_file(sql_file_path, parameter.configdburl, parameter.column_details)
    ## check and create config table : ENDS

    column_details = readTable(table_name=parameter.column_details, dburl=parameter.configdburl)
    column_details = column_details[column_details['table_name'].map(lambda x: str(x) != table_name)]
    output_df = pd.concat([column_details, new_df], axis=0, ignore_index=True)
    _saveDataframe(table_name=parameter.column_details, df=output_df, dburl=parameter.configdburl, if_exists='append');


if __name__ == '__main__':
    setup_logging()
    execute(configfile=os.path.normpath(
        os.path.join(os.path.dirname(__file__), '../anonymization_config_file.properties')),
    );
