import logging
import os


def setup_logging():
    log_output_folder = "os.path.normpath(os.path.join(os.path.dirname(__file__), '../../../../output/logs/"

    if not os.path.exists(log_output_folder):
        os.makedirs(log_output_folder)

    output_file = os.path.join(log_output_folder, "{}.log".format("app"))

    logging.basicConfig(filename=output_file,
                        filemode='a',
                        format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
                        level=logging.INFO)

    # set up logging to console
    console = logging.StreamHandler()
    console.setLevel(logging.DEBUG)
    # set a format which is simpler for console use
    formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
    console.setFormatter(formatter)
    # add the handler to the root logger
    logging.getLogger('').addHandler(console)

    logger = logging.getLogger(__name__)
