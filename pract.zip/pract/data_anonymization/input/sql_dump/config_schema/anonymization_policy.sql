CREATE DATABASE  IF NOT EXISTS `anonymization` /*!40100 DEFAULT CHARACTER SET utf8 */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `anonymization`;
-- MySQL dump 10.13  Distrib 8.0.16, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: anonymization
-- ------------------------------------------------------
-- Server version	8.0.16

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
 SET NAMES utf8 ;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `domain_bank_policy`
--

DROP TABLE IF EXISTS `domain_bank_policy`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8 ;
CREATE TABLE `domain_bank_policy` (
  `column name` varchar(50) NOT NULL,
  `anonymize technique` varchar(50) NOT NULL,
  `parameters` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`column name`),
  UNIQUE KEY `column name_UNIQUE` (`column name`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `domain_bank_policy`
--

LOCK TABLES `domain_bank_policy` WRITE;
/*!40000 ALTER TABLE `domain_bank_policy` DISABLE KEYS */;
INSERT INTO `domain_bank_policy` VALUES (' address','synthetic_data','{\"method\": \"address\", \"api\": \"Address\"}'),(' relationship','pseudonymization',NULL),('account name','synthetic_data','{\"method\": \"name\"}'),('age','generalization',NULL),('amount','aggregation','{\"p\":0.2}'),('balance','generalization',NULL),('bank','masking','{\"value\": \"#\"}'),('birth place','synthetic_data','{\"api\": \"Address\", \"method\": \"region\"}'),('branch','masking','{\"value\": \"#\"}'),('city','synthetic_data','{\"api\": \"Address\", \"method\": \"city\"}'),('country','synthetic_data','{\"api\": \"Address\", \"method\": \"country\"}'),('credit card expiration date','masking','{\"value\": \"XX\", \"location\": \"end\"}'),('credit card number','masking','{\"pattern\": \"00XX-XXXX-XXXX-XX00\"}'),('credit debit indicator','differential_privacy','{\"p\":0.3}'),('currency','noise_addition','{\"noise\": \"nanify\", \"p\": 0.8}'),('customer id','synthetic_data','{\"method\": \"id\"}'),('date','synthetic_data','{\"method\": \"date\", \"api\": \"Datetime\"}'),('date of birth','synthetic_data','{\"method\": \"date\", \"api\": \"Datetime\"}'),('email','synthetic_data','{\"method\": \"email\"}'),('frozen','pseudonymization',NULL),('gender','differential_privacy','{\"p\":0.3}'),('id','synthetic_data','{\"method\": \"id\"}'),('income type','pseudonymization',NULL),('is joint account','noise_addition','{\"noise\": \"nanify\", \"p\": 0.8}'),('is online access enabled','noise_addition','{\"noise\": \"nanify\", \"p\": 0.8}'),('job title','pseudonymization',NULL),('marital status','pseudonymization',NULL),('name','synthetic_data','{\"method\": \"name\"}'),('nationality','synthetic_data','{\"api\": \"Address\", \"method\": \"country\"}'),('nickname','synthetic_data','{\"method\": \"name\"}'),('no credit','pseudonymization',NULL),('no debit','pseudonymization',NULL),('nominee date of birth','synthetic_data','{\"method\": \"date\", \"api\": \"Datetime\"}'),('party','swapping',NULL),('passbook','pseudonymization',NULL),('person id','synthetic_data','{\"method\": \"id\"}'),('phone','masking','{\"value\": \"#\"}'),('product','pseudonymization',NULL),('reward point','noise_addition','{\"low\": 100, \"high\": 500, \"noise\": \"number\"}'),('salary','perturbation',NULL),('scheme','pseudonymization',NULL),('sex','differential_privacy','{\"p\":0.3}'),('ssn','masking','{\"value\": \"#\"}'),('status','pseudonymization',NULL),('type','pseudonymization',NULL),('usage','swapping',NULL);
/*!40000 ALTER TABLE `domain_bank_policy` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `policy_configurations`
--

DROP TABLE IF EXISTS `policy_configurations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8 ;
CREATE TABLE `policy_configurations` (
  `column_details_id` int(11) NOT NULL AUTO_INCREMENT,
  `table_name` varchar(50) DEFAULT NULL,
  `column_name` varchar(50) DEFAULT NULL,
  `anonymize_technique` varchar(50) DEFAULT NULL,
  `policy` varchar(50) DEFAULT NULL,
  `addtional_parameter` json DEFAULT NULL,
  `is_primary_key` varchar(5) DEFAULT NULL,
  PRIMARY KEY (`column_details_id`),
  UNIQUE KEY `index_UNIQUE` (`column_details_id`)
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `policy_configurations`
--

LOCK TABLES `policy_configurations` WRITE;
/*!40000 ALTER TABLE `policy_configurations` DISABLE KEYS */;
INSERT INTO `policy_configurations` VALUES (1,'person','person_id','synthetic_data','{\"method\": \"id\"}',NULL,'\'Y\''),(2,'person','gender','differential_privacy','{\"p\":0.3}',NULL,NULL),(3,'person','age','generalization',NULL,NULL,NULL),(4,'person','income_type','pseudonymization',NULL,NULL,NULL),(5,'person','minor_major','differential_privacy','{\"p\":0.3}',NULL,NULL),(6,'person','marital_status','pseudonymization',NULL,NULL,NULL),(7,'person','employment_status','differential_privacy','{\"p\":0.3}',NULL,NULL),(8,'person','job_title','pseudonymization','',NULL,NULL),(9,'person','salary','perturbation',NULL,NULL,NULL),(10,'person','city','synthetic_data','{\"api\": \"Address\", \"method\": \"city\"}',NULL,NULL),(11,'person','phone','masking','{\"value\": \"#\"}',NULL,NULL),(12,'person','email_id','synthetic_data','{\"method\": \"email\"}',NULL,NULL),(13,'person','forenames','synthetic_data','{\"method\": \"name\"}',NULL,NULL),(14,'person','middlename','synthetic_data','{\"method\": \"name\"}',NULL,NULL),(15,'person','lastname','synthetic_data','{\"method\": \"name\"}',NULL,NULL),(16,'transaction','amount','aggregation','{\"p\":0.2}',NULL,NULL),(17,'transaction','credit_card_expiration_date','masking','{\"value\": \"XX\", \"location\": \"end\"}',NULL,NULL),(18,'transaction','credit_card_number','masking','{\"pattern\": \"00XX-XXXX-XXXX-XX00\"}',NULL,NULL),(19,'transaction','currency','noise_addition','{\"noise\": \"nanify\", \"p\": 0.8}',NULL,NULL),(20,'transaction','customer_id','synthetic_data','{\"method\": \"id\"}',NULL,'\'Y\''),(21,'transaction','email','synthetic_data','{\"method\": \"email\"}',NULL,NULL),(22,'transaction','timestamp','synthetic_data','{\"method\": \"date\", \"api\": \"Datetime\"}',NULL,NULL),(23,'transaction','credit_debit_indicator','differential_privacy','{\"p\":0.3}',NULL,NULL),(24,'transaction','balance','generalization',NULL,NULL,NULL);
/*!40000 ALTER TABLE `policy_configurations` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2019-07-09 15:11:30
