CREATE TABLE `REPLACE_TABLE_NAME` (
  `column_details_id` int(11) NOT NULL AUTO_INCREMENT,
  `table_name` varchar(50) DEFAULT NULL,
  `column_name` varchar(50) DEFAULT NULL,
  `anonymize_technique` varchar(50) DEFAULT NULL,
  `policy` varchar(50) DEFAULT NULL,
  `addtional_parameter` json DEFAULT NULL,
  `is_primary_key` varchar(5) DEFAULT NULL,
  PRIMARY KEY (`column_details_id`),
  UNIQUE KEY `index_UNIQUE` (`column_details_id`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=latin1;