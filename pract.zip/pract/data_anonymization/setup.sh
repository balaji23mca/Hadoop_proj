#!/bin/bash

currentpath=$PWD

export PYTHONPATH=currentpath:$PYTHONPATH
pip install -r requirements.txt