from setuptools import setup, find_packages

setup(
    name='generation',
    version='1.0.0',
    description='xLabs Synthetic Data Generation Tool',
    url='https://git-codecommit.eu-west-1.amazonaws.com/v1/repos/syn_data_generation',
    author='Mohammed Asifuddin',

    classifiers=[
        'Development Status :: 5 - Production/Stable',
        'Intended Audience :: Developers',
        'Topic :: Software Development :: Libraries :: Application Frameworks',
        'License :: OSI Approved :: Virtusa License',
        'Programming Language :: Python :: 3.7',
    ],

    keywords='xLabs Synthetic Data Generation Tool',

    packages=find_packages(),

    install_requires=['flask-restplus==0.9.2', 'Flask-SQLAlchemy==2.1'],
)
