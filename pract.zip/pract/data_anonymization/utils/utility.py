import configparser
import logging
import os.path
import time

import pandas as pd

from utils import helper
from utils.database import db_helper

const_path = os.path.normpath(os.path.join(os.path.dirname(__file__), '../../../output/cache/'))


def read_parameter(configfile=None):
    import collections
    parameter = collections.namedtuple('parameter',
                                       ['inputdburl', 'configdburl', 'outputdburl', 'column_details',
                                        'input_table_name', 'domain_policy'])

    config = configparser.RawConfigParser()
    config.read(configfile)

    configdburl = config.get('DatabaseSection', 'configdburl', fallback=None);
    inputdburl = config.get('DatabaseSection', 'inputdburl', fallback=None);
    outputdburl = config.get('DatabaseSection', 'outputdburl', fallback=None);

    column_details = config.get('DatabaseSection', 'column_details', fallback=None);

    input_table_name = config.get('DatabaseSection', 'input_table_name', fallback=None);
    domain_policy = config.get('DatabaseSection', 'domain_policy', fallback=None);

    parameter = parameter(configdburl=configdburl, inputdburl=inputdburl, outputdburl=outputdburl,
                          column_details=column_details, input_table_name=input_table_name, domain_policy=domain_policy)
    return parameter


# _saveDataframe(table_name = parameter.column_details, df = output_df, dburl = parameter.configdburl,if_exists= 'append');

def save_dataframe(table_name, respDataframe, outputdburl, if_exists=None):
    start_time = time.time()

    logging.debug('Execution time - in saving cache data - : %.3f seconds' % (time.time() - start_time))

    if outputdburl:
        db_helper.save_to_db(respDataframe, table_name, outputdburl, use_async=False, if_exists=if_exists)

    else:
        pass

    logging.info('Execution time - in saving dataframe - : %.3f seconds' % (time.time() - start_time))


def get_table(table_name, parameter=None, filter=None):
    if not parameter:
        parameter = helper.readParameter()

    if parameter.wsprefix:
        wsname = parameter.wsprefix
    else:
        wsname = "temp"

    path_url = os.path.join(const_path, wsname)

    store = None
    try:
        store = pd.HDFStore(path_url)
    except Exception as e:
        logging.error(' Exception occured in fetching cache {}'.format(e))

    if parameter.wsprefix:
        if store and (wsname + '_' + table_name in store):
            return pd.read_hdf(path_url, parameter.wsprefix + '_' + table_name, mode='a')
        else:
            respDataframe = db_helper.read_table(table_name=table_name, dburl=parameter.outputdburl,
                                                 wsprefix=parameter.wsprefix,
                                                 filter=None)
            return respDataframe
    else:
        if store and (table_name in store):
            try:
                respDataframe = pd.read_hdf(path_url, table_name, mode='a')
            except:
                respDataframe = db_helper.read_table(table_name=table_name, dburl=parameter.outputdburl, wsprefix=None,
                                                     filter=None)
            return respDataframe
        else:
            respDataframe = db_helper.read_table(table_name=table_name, dburl=parameter.outputdburl, wsprefix=None,
                                                 filter=None)
            return respDataframe


def setup_logging():
    log_output_folder = "os.path.normpath(os.path.join(os.path.dirname(__file__), '../../../../output/logs/"

    if not os.path.exists(log_output_folder):
        os.makedirs(log_output_folder)

    output_file = os.path.join(log_output_folder, "{}.log".format("app"))

    logging.basicConfig(filename=output_file,
                        filemode='a',
                        format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
                        level=logging.INFO)

    # set up logging to console
    console = logging.StreamHandler()
    console.setLevel(logging.DEBUG)
    # set a format which is simpler for console use
    formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
    console.setFormatter(formatter)
    # add the handler to the root logger
    logging.getLogger('').addHandler(console)

    logger = logging.getLogger(__name__)
