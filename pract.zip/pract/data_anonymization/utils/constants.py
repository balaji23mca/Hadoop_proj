# Responses
CONNECTION_SUCCESSFUL = 'Connection Successful'
CONNECTION_FAILED = 'Connection Failed'
#
