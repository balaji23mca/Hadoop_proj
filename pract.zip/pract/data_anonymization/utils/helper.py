import logging

from utils import constants
from utils import utility
from utils.database import db_helper


def readParameter(configfile=None):
    try:
        return utility.read_parameter(configfile)
    except Exception as e:
        logging.error('Exception occurred in readParameter {}'.format(e))
        raise e
    finally:
        logging.debug('----------- call to readparameter completed -----------')


def checkDbConnections(dburl, connectionType):
    try:
        response = db_helper.check_db_connection(dburl)
        if response:
            logging.debug('----------- {} connection successful'.format(connectionType))
        else:
            logging.debug('----------- {} connection failure'.format(connectionType))
        return response
    except Exception as e:
        logging.debug('----------- {} Exception occurred in checkDbConnections'.format(connectionType))
        logging.error(e)
        return constants.CONNECTION_FAILED
    finally:
        logging.debug('----------- {} connection check completed'.format(connectionType))


def readTable(table_name, dburl, wsprefix=None, filter=None):
    try:

        return db_helper.read_table(table_name, dburl, wsprefix, filter)
    except Exception as e:
        logging.debug('Exception occurred in reading table {}'.format(table_name))
        logging.error(e)
    finally:
        logging.debug('----------- call to readConfigTable completed')


def hasTable(table_name, wsprefix, dburl):
    try:
        return db_helper.has_table(table_name, dburl, wsprefix)
    except Exception as e:
        logging.debug('Exception occurred in hasTable')
        logging.error(e)
    finally:
        logging.debug('----------- hasTable ENDS -----------')


def getTableSize(table_name, wsprefix, dburl):
    try:
        return db_helper.get_table_size(table_name, dburl, wsprefix)
    except Exception as e:
        logging.debug('Exception occurred in getTableSize')
        logging.error(e)
    finally:
        logging.debug('----------- getTableSize ENDS -----------')


# _saveDataframe(table_name = parameter.column_details, df = output_df, dburl = parameter.configdburl,if_exists= 'append');
def saveDataframe(table_name, respDataframe, outputdburl, if_exists=None):
    try:
        return utility.save_dataframe(table_name, respDataframe, outputdburl, if_exists)
    except Exception as e:
        logging.debug('Exception occurred in saveDataframe')
        logging.error(e)
    finally:
        logging.debug('----------- getTableSize ENDS -----------')

def jaccard_similarity(x, y):
    """ returns the jaccard similarity between two lists """
    intersection_cardinality = len(set.intersection(*[set(x), set(y)]))
    union_cardinality = len(set.union(*[set(x), set(y)]))
    return intersection_cardinality / float(union_cardinality)

def wasserstein_dist(x, y):
    from scipy.stats import wasserstein_distance
    return wasserstein_distance(x, y)
