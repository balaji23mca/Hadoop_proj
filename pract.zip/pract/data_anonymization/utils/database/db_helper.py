import logging
import threading

import pandas as pd
from flask_restplus import abort
from pandas import read_sql_table
from sqlalchemy import create_engine, text, MetaData
from sqlalchemy.ext.declarative import declarative_base

from utils import constants


def check_db_connection(dburl):
    if dburl:
        if isinstance(dburl, str):
            uri = dburl

        if isinstance(dburl, dict):
            uri = dburl.get("uri", None)

        if uri:
            try:
                engine = create_engine(uri, echo=False)
                if engine.connect():
                    responseStr = constants.CONNECTION_SUCCESSFUL
                engine.dispose()
                return responseStr

            except Exception as e:
                logging.error("Exception occurred at check_db_connection")
                raise e
        else:
            return constants.CONNECTION_FAILED
    else:
        abort(500, "Input DB not specified")


def has_table(table_name, dburl, wsprefix=None):
    is_table_exists = False
    if isinstance(dburl, str):
        uri = dburl

    elif isinstance(dburl, dict):
        uri = dburl.get("uri", None)

    engine = create_engine(uri, echo=False)
    if wsprefix:

        is_table_exists = engine.dialect.has_table(engine, wsprefix + '_' + table_name)

    else:
        is_table_exists = engine.dialect.has_table(engine, table_name)

    return is_table_exists


def drop_table(table_name, dburl, wsprefix=None):
    is_table_exists = False
    if isinstance(dburl, str):
        uri = dburl

    elif isinstance(dburl, dict):
        uri = dburl.get("uri", None)

    engine = create_engine(uri, echo=False)
    if wsprefix:
        is_table_exists = engine.dialect.has_table(engine, wsprefix + '_' + table_name)
    else:
        is_table_exists = engine.dialect.has_table(engine, table_name)

    if is_table_exists:
        try:
            base = declarative_base()
            metadata = MetaData(engine, reflect=True)
            table = metadata.tables.get(table_name)
            base.metadata.drop_all(engine, [table], checkfirst=True)
            return False
        except Exception as e:
            logging.error("Exception occurred at drop_table".format(e))
            return True


def get_table_size(table_name, dburl, wsprefix=None):
    if isinstance(dburl, str):
        uri = dburl

    elif isinstance(dburl, dict):
        uri = dburl.get("uri", None)

    if wsprefix:
        data = read_sql_table(wsprefix + '_' + table_name, uri)
    else:
        data = read_sql_table(table_name, uri)

    return len(data.index)


def read_table(table_name, dburl, wsprefix=None, filter=None):
    if isinstance(dburl, str):
        uri = dburl

    elif isinstance(dburl, dict):
        uri = dburl.get("uri", None)

    if wsprefix:
        data = read_sql_table(wsprefix + '_' + table_name, uri)
    else:
        data = read_sql_table(table_name, uri)

    if filter:
        for key, values in filter.items():
            data = data[data[key].isin(values)]
    return data


def save_data(wsprefix, data, uri):
    df = pd.DataFrame.from_records(data.get("list", None))
    table_name = data.get("table_name", None)
    save_to_db(wsprefix, df, table_name, uri)


# _saveDataframe(table_name = parameter.column_details, df = output_df, dburl = parameter.configdburl,if_exists= 'append');

def save_to_db(df, table_name, dburl, use_async=True, if_exists='replace'):
    logging.info('Saving table {} , of row size {}'.format(table_name, len(df)))
    if isinstance(dburl, str):
        uri = dburl

    elif isinstance(dburl, dict):
        uri = dburl.get("uri", None)

    if use_async:
        thread = threading.Thread(target=async_save_to_db, args=(df, table_name, uri, if_exists))
        thread.start()
        thread.join()

    else:
        try:
            engine = create_engine(uri, echo=False)
            if engine.connect():
                df.to_sql(table_name, con=engine, if_exists=if_exists, index=False)
                if engine.dialect.has_table(engine, table_name):
                    engine.connect()
                    return 'Table saved successfully'
        except Exception as e:
            logging.error("Exception occurred at save_to_db".format(e))
            raise e


def async_save_to_db(df, table_name, outputdburl, if_exists):
    try:
        engine = create_engine(outputdburl, echo=False)
        df.to_sql(table_name, con=engine, if_exists=if_exists, index=False)
        if engine.dialect.has_table(engine, table_name):
            engine.connect()
            return 'Table saved successfully'
    except Exception as e:
        logging.error("Exception occurred at async_save_to_db".format(e))
        raise e


def run_script_file(sql_file_path, dburl):
    if isinstance(dburl, str):
        uri = dburl

    elif isinstance(dburl, dict):
        uri = dburl.get("uri", None)
    try:
        file = open(sql_file_path)
        engine = create_engine(uri, echo=False)
        if engine.connect():
            escaped_sql = file.read().split(';')
            for query in escaped_sql:
                engine.execute(text(query))
    except Exception as e:
        logging.error("Exception occurred at save_to_db".format(e))
        raise e


if __name__ == '__main__':
    dburl = "mysql+pymysql://user:password@34.246.21.248/dataGenerationConfig"
    run_script_file(dburl)
