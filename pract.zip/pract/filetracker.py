import os
import time
import sys
import boto3
from botocore.exceptions import ClientError
import urllib3
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

def upload_file(file_name, bucket, object_name=None):
    # print("in upload {}".format(file_name))
    if object_name is None:
        object_name = file_name
    s3_client = boto3.client('s3',aws_access_key_id='AKIAX6AGHAJCMQA6IEOW',aws_secret_access_key='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',verify=False)
    try:
        response = s3_client.upload_file(file_name, bucket, object_name)
    except ClientError as e:
        print(e)
        return False
    return True


def files_tracker():
    # print("in file tracker")
    src_path = sys.argv[1] if len(sys.argv) > 1 else '.'
    last_modified = time.time() - 30
    s3_bucket = "vlifestore"
    res = os.walk(src_path)
    for r, d, ff in res:
        for f in ff:
            if f.split(".")[-1] in ["csv", "ipynb"]:
                if os.stat(os.path.join(r,f)).st_mtime >= last_modified or os.stat(os.path.join(r,f)).st_ctime >= last_modified:
                    # print(os.path.join(r,f))
                    # print(os.stat(os.path.join(r,f)))
                    obj_path = os.path.join(r,f)[2:]
                    if len(sys.argv) > 1:
                        obj_path = os.path.relpath(obj_path, src_path)
                    # print("f path : {}".format(obj_path))
                    upload_file(os.path.join(r,f), s3_bucket, object_name="710/106/" + obj_path.replace("\\", '/'))


while True:
    files_tracker()
    time.sleep(30)
