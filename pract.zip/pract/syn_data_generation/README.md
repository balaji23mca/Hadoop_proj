xLabs Synthetic Data Generation Tool
=============

•	Synthetic Data Generation Tool provides data for every aspect of your application, in real-time.
•	Synthetic Data Generation Tool generates quality, synthetic data that's using AI and statistical methods, based on distributions, interdependencies, and statistical correlations.
•	Synthetic Data Generation Tool includes Persona based Data Generation design technique. 
•	User can configured Meta Data using smart User Interface provided. 



