import logging

from flask import request, session
from flask_restplus import Resource
from components.rest_data_serializers import connection
from components.restplus import api

from components.core_components.utils.database import db_helper

log = logging.getLogger(__name__)

ns = api.namespace('datagenerationconfig', description='API related to setting up config databases')

@ns.route('/setup/inputdb')
class DatagenerationInputDbSetup(Resource):

    def get(self):
        """
        Returns inputdb URL.
        """

        wsprefix = session.get('workspace', None)

        if wsprefix:
            wsname = wsprefix
        else:
            wsname = "temp"

        return str(session.get(wsname + '_'+'inputdb', 'No input set!'))

    @api.response(201, 'URL saved successfully.')
    @api.expect(connection)
    def post(self):
        """
        Save input DB URL.
        """
        data = request.json

        wsprefix = session.get('workspace', None)

        if wsprefix:
            wsname = wsprefix
        else:
            wsname = "temp"

        session[wsname + '_'+'inputdb'] = data
        return None, 201

    @api.response(204, 'inputdb successfully deleted.')
    def delete(self):
        """
        Deletes inputdb url.
        """
        wsprefix = session.get('workspace', None)

        if wsprefix:
            wsname = wsprefix
        else:
            wsname = "temp"
        session.pop(wsname + '_'+'inputdb', None)
        return None, 204

@ns.route('/setup/outputdb')
class DatagenerationOutputDbSetup(Resource):

    def get(self):
        """
        Returns outputdb URL.
        """

        wsprefix = session.get('workspace', None)

        if wsprefix:
            wsname = wsprefix
        else:
            wsname = "temp"

        return str(session.get(wsname + '_'+'outputdb', 'No input set!'))

    @api.response(201, 'URL saved successfully.')
    @api.expect(connection)
    def post(self):
        """
        Save outputdb DB URL.
        """
        wsprefix = session.get('workspace', None)

        if wsprefix:
            wsname = wsprefix
        else:
            wsname = "temp"

        data = request.json
        session[ wsname + '_'+'outputdb'] = data
        return None, 201

    @api.response(204, 'outputdb successfully deleted.')
    def delete(self):
        """
        Deletes outputdb .
        """

        wsprefix = session.get('workspace', None)

        if wsprefix:
            wsname = wsprefix
        else:
            wsname = "temp"


        session.pop(wsname + '_'+'outputdb', None)
        return None, 204


@ns.route('/setup/test/inputdb')
class DatagenerationInputDbTest(Resource):

    def get(self):
        """
        Returns inputdb URL.
        """

        wsprefix = session.get('workspace', None)

        if wsprefix:
            wsname = wsprefix
        else:
            wsname = "temp"

        result = db_helper.check_db_connection(session.get(wsname + '_' + 'inputdb', None))

        return result

@ns.route('/setup/test/outputdb')
class DatagenerationOutputDbTest(Resource):

    def get(self):
        """
        Returns inputdb URL.
        """
        wsprefix = session.get('workspace', None)

        if wsprefix:
            wsname = wsprefix
        else:
            wsname = "temp"

        result = db_helper.check_db_connection(session.get(wsname + '_' + 'outputdb', None))

        return result


@ns.route('/setup/workspace')
class DatagenerationWorkspace(Resource):

    def get(self):
        """
        Returns workspace name.
        """

        return str(session.get('workspace', 'No workspace set!'))


    @api.response(204, 'workspace successfully deleted.')
    def delete(self):
        """
        Deletes workspace.
        """
        session.pop('workspace', None)
        return None, 204


@ns.route('/setup/workspace/<string:workspace>')
class DatagenerationWorkspaceSetup(Resource):

    @api.response(201, 'URL saved successfully.')
    def post(self,workspace):

        """
        Save workspace name.
        """
        session['workspace'] = workspace

        return None, 201