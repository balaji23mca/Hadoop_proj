import logging

from flask import request, session
from flask_restplus import Resource
from components.restplus import api
from components.core_components.utils import utility
from components.core_components.utils.database import db_helper
from components.rest_data_serializers import column_prpty_meta_list

log = logging.getLogger(__name__)

ns = api.namespace('datagenerationops', description='API related to utils')


@ns.route('/columnprpty/<string:columnprpty>')
class DatagenerationWorkspaceSetup(Resource):

    @api.response(201, 'columnprpty table name saved successfully.')
    def post(self, columnprpty):
        """
        Save workspace name.
        """

        wsprefix = session.get('workspace', None)
        if wsprefix:
            wsname = wsprefix
        else:
            wsname = "temp"

        session[wsname + '_' + 'columnprpty'] = columnprpty
        return None, 201


@ns.route('/tableprpty/<string:tableprpty>')
class DatagenerationWorkspaceSetup(Resource):

    @api.response(201, 'tableprpty table name saved successfully.')
    def post(self, tableprpty):
        """
        Save workspace name.
        """

        wsprefix = session.get('workspace', None)
        if wsprefix:
            wsname = wsprefix
        else:
            wsname = "temp"

        session[wsname + '_' + 'tableprpty'] = tableprpty
        return None, 201


@ns.route('/columnprpty')
class SaveColumnMetaData(Resource):

    def get(self):
        """
        Returns columns properties data
        """
        pass

    @api.response(201, 'Table created sucessfully.')
    @api.expect(column_prpty_meta_list)
    def post(self):
        """
        Creates a new columns properties data table
        """

        wsprefix = session.get('workspace', None)

        if wsprefix:
            wsname = wsprefix
        else:
            wsname = "temp"

        data = request.json
        inputdb = (session.get(wsname + '_' + 'inputdb', None))

        session[wsname + '_' + 'columnprpty'] = data.get("table_name", None)

        if inputdb:
            uri = inputdb.get("uri", None)
            if uri:
                db_helper.save_data(data, uri)
                return None, 201


@ns.route('/run')
class Datageneration(Resource):

    @api.response(201, 'Tool is running')
    def get(self):
        """
        Returns columns properties data
        """

        wsprefix = str(session.get('workspace', ''))
        inputdburl = session.get(wsprefix + '_' + 'inputdb', None)
        outputdburl = session.get(wsprefix + '_' + 'outputdb', None)

        utility.execute()

        return 'Tables are generated', 201
