import pytest
import pandas as pd

from mock import Mock, patch
from sqlalchemy import create_engine
from components.core_components.utils.database.db_helper import check_db_connection,read_table, save_data
import components.core_components.utils.database.db_helper


#This is engine mocking
@pytest.fixture(scope='module')
def mock_engine():
    print("in mock_engine")
    uri = "mysql+pymysql://user:password@34.246.21.248/dataGenerationConfig"
    return Mock(spec_set=create_engine(uri, echo=False))

#Mock Table for another methods
@pytest.fixture(scope='module')
def mock_table():
    print("running mock")
    uri = "mysql+pymysql://user:password@34.246.21.248/dataGenerationConfig"
    return Mock(create=True, spec_set=pd.DataFrame)


@pytest.mark.utilsApi
def test_check_db_connection(mock_engine):
    with patch.object(components.core_components.utils.database.db_helper,
                      'create_engine',create=True,  return_value=mock_engine):
        data = {
        "db_name": "mysql",
        "uri": "mysql+pymysql://user:password@34.246.21.248/datagen"
        }
        #print("in test_db_connection")
        result = check_db_connection(data)
        assert result == 'Connection Successful'


@pytest.mark.utilsApi
def test_read_table(mock_table):
    with patch.object(components.core_components.utils.database.db_helper,
                      'read_sql_table', create=True, return_value=mock_table):
        temp_data = {
            "db_name": "mysql",
            "uri": "mysql+pymysql://user:password@34.246.21.248/datagen"
        }
        result = read_table('temp1',temp_data)
        print(result)
        #assert result=='Sucessful'


@pytest.mark.utilsApi
def test_save_data(mock_table):
    with patch.object(components.core_components.utils.database.db_helper,
                      'save_to_db', return_value='Table saved successfully'):
        temp_ws_prefix = "myws"
        temp_uri = "mysql+pymysql://user:password@34.246.21.248/datagen"
        result = save_data(temp_ws_prefix, mock_table, temp_uri)
        print("running")
        assert result == 'Table saved successfully'

        


