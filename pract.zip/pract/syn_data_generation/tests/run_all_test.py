import os

# All test case wiil be present in "tests" folder.
# Name of Test class must contain "test" keyword either at the end or at start.
# To run all test cases: Run "run_all_test.py"
# "testlog.log" contain all the test result of test. "dot" denotes sucess of test and "F" denotes fail.


if __name__ == "__main__":
    os.system("python -m pytest --resultlog=testlog.log")
