import pytest
from flask import session
from mock import Mock

@pytest.fixture(scope='module')
def mock_session():
    return Mock(spec_set=session)


