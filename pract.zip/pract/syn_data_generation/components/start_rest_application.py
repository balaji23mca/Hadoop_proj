import logging.config

from flask import Flask, Blueprint

import components.core_components.logging
from components import rest_app_settings
from api.datageneration_config import ns as datageneration_config
from api.datageneration_ops import ns as datageneration_ops
from components.restplus import api
from components.core_components.generators.utils import generator_utility
from flask_sqlalchemy import SQLAlchemy



db = SQLAlchemy()
app = Flask(__name__)
components.core_components.logging.setup_logging()


def configure_app(flask_app):
    flask_app.config['SERVER_NAME'] = rest_app_settings.FLASK_SERVER_NAME
    flask_app.config['SWAGGER_UI_DOC_EXPANSION'] = rest_app_settings.RESTPLUS_SWAGGER_UI_DOC_EXPANSION
    flask_app.config['RESTPLUS_VALIDATE'] = rest_app_settings.RESTPLUS_VALIDATE
    flask_app.config['RESTPLUS_MASK_SWAGGER'] = rest_app_settings.RESTPLUS_MASK_SWAGGER
    flask_app.config['ERROR_404_HELP'] = rest_app_settings.RESTPLUS_ERROR_404_HELP
    flask_app.config['SECRET_KEY'] = 'super secret'


def initialize_app(flask_app):
    configure_app(flask_app)

    blueprint = Blueprint('api', __name__, url_prefix='/api')
    api.init_app(blueprint)
    api.add_namespace(datageneration_config)
    api.add_namespace(datageneration_ops)
    flask_app.register_blueprint(blueprint)

    db.init_app(flask_app)


def main():
    initialize_app(app)
    logging.debug('>>>>> Starting development server at http://{}/api/ <<<<<'.format(app.config['SERVER_NAME']))
    app.run(debug=rest_app_settings.FLASK_DEBUG)


if __name__ == "__main__":
    main()
