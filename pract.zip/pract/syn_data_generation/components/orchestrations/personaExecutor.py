import time

import components.core_components.logging
from components.core_components.utils.helper import *;

"""
   Comment : 
"""


def _get_countofrecords(row):
    table_parameters = row.get('table_parameters', None)
    if table_parameters and table_parameters.get('size', None):
        return table_parameters.get('size', 100)
    else:
        logging.debug('Size is not specified, running for default size 10')
        return 10  # default size is 10 records

def _get_otherGenerators_list(meta_config_list):
    otherGenerators_list = [d for d in meta_config_list if
                            d.get('generator_name', "N") != "SequencialGenerator"
                            ]
    if otherGenerators_list:
        return otherGenerators_list
    else:
        return []


def _get_SequencialGenerator_list(meta_config_list):
    sequencialGenerator_list = [d for d in meta_config_list if
                                d.get('generator_name', "N") == "SequencialGenerator"
                                ]
    if sequencialGenerator_list:
        return sequencialGenerator_list
    else:
        return []


def execute(row, parameter, meta_config_list,table_size, flag):
    start_time = time.time()

    table_name = row.get('table_name', None)
    logging.info('starting executor to create {} table of size {}'.format(table_name, table_size))

    countofrecords = table_size

    otherGenerators_list = _get_otherGenerators_list(meta_config_list)


    table_parameters = row.get('table_parameters', None)
    if table_parameters:
        master_seed = table_parameters.get('master_seed', 1234)

    ###
    commit_size = row.get('commit_size', None)
    if commit_size:
        commit_size = int(commit_size)

    iteration_count = int((countofrecords // commit_size)) # 1
    reminder_count = int(countofrecords % commit_size)

    gen_instance_df_from_store = batchCacheRead(table_name)

    if flag:
        flag1 = True
    else:
        flag1 = False
    for i in range(iteration_count):
        gen_instance_list = []
        container = createContainerObject(name=table_name, size=commit_size,
                                          master_seed=master_seed, parameter=parameter);
        population = initializePopulation(container=container)

        if gen_instance_df_from_store is None:
            ############# creating new instance
            try:
                for gen_param in meta_config_list:  #### creating instance for all
                    logging.debug('initializeGenerators with param : {}'.format(gen_param))
                    gen_instance = generator_factory.getInstance(gen_param,
                                                                 initiating_population=container.populations[
                                                                     table_name])
                    gen_instance_list.append(gen_instance)
            except Exception as e:
                logging.error('Exception occurred :{} '.format(e))
            #############
        else:
            ############# using pickled instance and setting to list
            try:
                for index, gen_instance in gen_instance_df_from_store.iterrows():
                    gen_instance_list.append(gen_instance['gen_instance'])
            except Exception as e:
                logging.error('Exception occurred :{} '.format(e))
            ############# creating new instance of other generators and setting it to list
            try:
                for gen_param in otherGenerators_list:
                    logging.debug('initializeGenerators with param : {}'.format(gen_param))
                    gen_instance = generator_factory.getInstance(gen_param,
                                                                 initiating_population=container.populations[
                                                                     table_name])
                    gen_instance_list.append(gen_instance)
            except Exception as e:
                logging.error('Exception occurred :{} '.format(e))
            #############

        population = createPopulation(gen_instance_list=gen_instance_list, population=population,
                                      size=commit_size);
        dataframe = population.to_dataframe(size=commit_size)
        dataframe_after_rule = applyRules(dataframe, gen_instance_list);

        if meta_config_list and flag1:
            graph_parameters_list = _get_graph_parameters_list(meta_config_list)
            generateGraph(dataframe, graph_parameters_list)  # calling for graph generation
            generateEDAGraph(dataframe, graph_parameters_list)
            flag1 = False

        logging.info('saving df of size :{} '.format(len(dataframe_after_rule)))
        saveDataframe(container, dataframe_after_rule, parameter.wsprefix, parameter.joblogdburl, 'append');
        # saveDataframe(container, dataframe_after_rule, parameter.wsprefix, parameter.outputdburl, 'append');

        gen_instance_list_itr = []
        for generator_instance in gen_instance_list:
            if isinstance(generator_instance, components.core_components.generators.sequencialGenerator.SequencialGenerator):
                gen_instance_list_itr.append(generator_instance)

        gen_instance_df_from_store = pd.DataFrame(gen_instance_list_itr, columns=['gen_instance'])

    ###

    ### running for reminder

    if reminder_count > 0:
        gen_instance_list = []
        container = createContainerObject(name=table_name, size=reminder_count,
                                          master_seed=master_seed, parameter=parameter);
        population = initializePopulation(container=container)

        if gen_instance_df_from_store is None:
            ############# creating new instance
            try:
                for gen_param in meta_config_list:  #### creating instance for all
                    logging.debug('initializeGenerators with param : {}'.format(gen_param))
                    gen_instance = generator_factory.getInstance(gen_param,
                                                                 initiating_population=container.populations[
                                                                     table_name])
                    gen_instance_list.append(gen_instance)
            except Exception as e:
                logging.error('Exception occurred :{} '.format(e))
            #############
        else:
            ############# using pickled instance and setting to list
            try:
                for index, gen_instance in gen_instance_df_from_store.iterrows():
                    gen_instance_list.append(gen_instance['gen_instance'])
            except Exception as e:
                logging.error('Exception occurred :{} '.format(e))
            ############# creating new instance of other generators and setting it to list
            try:
                for gen_param in otherGenerators_list:
                    logging.debug('initializeGenerators with param : {}'.format(gen_param))
                    gen_instance = generator_factory.getInstance(gen_param,
                                                                 initiating_population=container.populations[
                                                                     table_name])
                    gen_instance_list.append(gen_instance)
            except Exception as e:
                logging.error('Exception occurred :{} '.format(e))
            #############

        population = createPopulation(gen_instance_list=gen_instance_list, population=population,
                                      size=reminder_count);
        dataframe = population.to_dataframe(size=reminder_count)
        dataframe_after_rule = applyRules(dataframe, gen_instance_list);

        if meta_config_list and flag1:
            graph_parameters_list = _get_graph_parameters_list(meta_config_list)
            generateGraph(dataframe, graph_parameters_list)  # calling for graph generation
            generateEDAGraph(dataframe, graph_parameters_list)
            flag1 = False

        logging.info('saving df of size :{} '.format(len(dataframe_after_rule)))
        saveDataframe(container, dataframe_after_rule, parameter.wsprefix, parameter.joblogdburl, 'append');
        # saveDataframe(container, dataframe_after_rule, parameter.wsprefix, parameter.outputdburl, 'append');

        gen_instance_list_itr = []
        for generator_instance in gen_instance_list:
            if isinstance(generator_instance,
                          components.core_components.generators.sequencialGenerator.SequencialGenerator):
                gen_instance_list_itr.append(generator_instance)

        gen_instance_df_from_store = pd.DataFrame(gen_instance_list_itr, columns=['gen_instance'])

    ######
    logging.debug('----------- shape of dataframe is : {}'.format(dataframe.shape))

    # if meta_config_list and flag:
    #     graph_parameters_list = _get_graph_parameters_list(meta_config_list)
    #     generateGraph(dataframe, graph_parameters_list)  # calling for graph generation
    #     generateEDAGraph(dataframe, graph_parameters_list)

    # dataframe_after_rule = applyRules(dataframe, gen_instance_list);

    logging.info('{} creation completed in : %.3f seconds'.format(table_name) % (time.time() - start_time))
    batchCacheWrite(table_name, gen_instance_df_from_store)
    ##########


def _get_graph_parameters_list(meta_config_list):
    graph_parameters_list = [d for d in meta_config_list if
                                   d.get('graph_parameters', None)]
    if graph_parameters_list:
        return graph_parameters_list
    else:
        return []


    ####################


if __name__ == '__main__':
    import os
    import pandas as pd

    components.core_components.logging.setup_logging()
    parameter = readParameter()
    str_row = {
        'table_id': 1,
        'table_name': 'Persona',
        'tabledescription': 'Persona table',
        'dependency_level': 0,
        'related_tables': None,
        'lastupddate': '03/25/2019',
        'countofrecords': 100,
        'type': {"table_type": "PERSONA", "size": 100},
        'table_parameters': {
            'master_seed': 1234
        },
        'active_status': 'y'
    }
    row = pd.Series(str_row)

    columnprpty = readConfigTable(table_name=parameter.columnprpty, wsprefix=parameter.wsprefix,
                                  dburl=parameter.inputdburl, filter={'table_id': [row.get('table_id', None)]})
    meta_config_list = transformConfig(columnprpty)
    validation_result = validateGeneratorParam(column_prptys_meta_json_list=meta_config_list)

    if validation_result and all(validation_result):
        execute(row, parameter, meta_config_list);
