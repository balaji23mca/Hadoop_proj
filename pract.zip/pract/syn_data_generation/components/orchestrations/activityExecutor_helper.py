import time

import numpy as np

from components.core_components.generators.generator import ConstantDependentGenerator
from components.core_components.table_container import operations
from components.core_components.utils.helper import *;

"""
   Comment : One to Many type table creation
"""



def create_story_in_container(row, container, ):
    table_name = row.get('table_name', None)  ## : Output table name

    transaction_story = container.create_story(
        name=table_name,
        initiating_population=container.populations[table_name],
        member_id_field="ID",
        timer_gen=ConstantDependentGenerator(value=1)
    )

    transaction_story.set_operations(
        # container.populations[table_name].ops.select_one(named_as="OTHER_PERSON"),
        container.clock.ops.timestamp(named_as="TIME"))

    return transaction_story


def add_activity(row, parameter, meta_config_list, dataframe, filedList,gen_instance_list):
    table_name = row.get('table_name', None)

    dataframe = dataframe.sample(frac=1).reset_index(drop=True)
    container = createContainerObject(name=table_name, size=len(dataframe.index),
                                      master_seed=1234, parameter=parameter);

    population = create_population_from_df(dataframe, container)

    container.populations[table_name] = population

    transaction_story = create_story_in_container(row, container)

    transaction_story, filedList = append_visible_particular_in_story(row, meta_config_list, filedList, container,
                                                                      transaction_story)

    if is_activity_in_list(meta_config_list):
        transaction_story, filedList = append_activity_in_story(row, meta_config_list, filedList, container,
                                                                transaction_story,gen_instance_list)
    ##################

    # filedList.sort()

    transaction_story.append_operations(
        operations.FieldLogger(log_id=table_name, cols=filedList)
    )

    dataframe = container.run(
        duration=int(1),  # wothout parameter
        log_output_folder="output/example_scenario",
        delete_existing_logs=True
    )

    return container, dataframe, filedList


def append_activity_in_story(row, meta_config_list, filedList, container, transaction_story,gen_instance_list):
    table_name = row.get('table_name', None)  ## : Output table name

    try:
        for gen_instance in gen_instance_list:

            dynamic_column_name = gen_instance.name
            transaction_story.append_operations(
                gen_instance.ops.generate(named_as=dynamic_column_name),
            )

            filedList.append(dynamic_column_name)
    except Exception as e:
        logging.error('Exception occured :{} '.format(e))

    return transaction_story, filedList


def append_visible_particular_in_story(row, meta_config_list, filedList, container, transaction_story):
    filedList_incomming = filedList
    filedList = []
    table_name = row.get('table_name', None)  ## : Output table name
    meta_config_visible_particular_list = _get_meta_config_visible_particular_list(meta_config_list)

    # meta_config_visible_particular_list = [d for d in meta_config_particular_list if
    #                                        d.get('table_parameters', None) and d.get('table_parameters').get(
    #                                            'visible',
    #                                            None)
    #                                        and d.get('table_parameters').get('visible') == "Y"]
    try:
        for gen_param in meta_config_visible_particular_list:
            column_name = gen_param.get("column_name", None)
            if column_name:
                transaction_story.append_operations(
                    container.populations[table_name]
                        .ops.lookup(id_field="ID", select={column_name: column_name}))
                filedList.append(column_name)
                logging.debug('creating operations with param : {}'.format(column_name))

    except Exception as e:
        logging.error('Exception occurred : '.format(e))

    if "time_series" in filedList_incomming:
        try:
            transaction_story.append_operations(
                container.populations[table_name]
                    .ops.lookup(id_field="ID", select={"time_series": "time_series"}))
            filedList.append("time_series")
            logging.debug('creating operations with param : {}'.format("time_series"))

        except Exception as e:
            logging.error('Exception occurred : '.format(e))

    return transaction_story, filedList


def get_particulars(row, parameter, meta_config_list):
    start_time = time.time()

    logging.debug('----------- running components/orchestrations/activityExecutor')

    table_name = row.get('table_name', None)  ## : Output table name

    relationships = row.get('relationships')

    relatedtables_table = _get_relatedtables_table(relationships)

    table_parameters = row.get('table_parameters', None)
    if table_parameters:
        master_seed = table_parameters.get('master_seed', 1234)

    container_size = getTableSize(table_name=relatedtables_table, wsprefix=parameter.wsprefix,
                                  dburl=parameter.joblogdburl)

    meta_config_particular_list = get_meta_config_particular_list(meta_config_list)

    ################## : reading and setting param for intital table : Ends
    return create_datafarme(table_name=table_name, size=container_size,
                            master_seed=master_seed, parameter=parameter,
                            meta_config__list=meta_config_particular_list
                            )


def _get_relatedtables_table(relationships):
    if isinstance(relationships, dict):
        relatedtables_table = relationships.get('table', None)
    else:
        for row in relationships:
            if row.get('rel_type', None) and row.get('rel_type') == "ONE_TO_ONE":
                relatedtables_table = row.get('table', None)
    return relatedtables_table


def _get_dependent_table_list(relationships):
    dependent_table_list = []
    if isinstance(relationships, dict):
        dependent_table_list.append(relationships.get('table', None))
    else:
        for row in relationships:
            if row.get('table', None):
                dependent_table_list.append(row['table'])

    return dependent_table_list


def is_activity_in_list(meta_config_list):
    is_activity_in_list = False

    meta_config_activity_list = _get_meta_config_activity_list(meta_config_list)

    if len(meta_config_activity_list) > 0:
        is_activity_in_list = True
    return is_activity_in_list


def _get_meta_config_activity_list(meta_config_list):
    meta_config_particular_list = [d for d in meta_config_list if
                                   d.get('is_reference_column', "N") != "Y"
                                   ]
    if meta_config_particular_list:
        return meta_config_particular_list
    else:
        return []


def get_meta_config_particular_list(meta_config_list):
    meta_config_particular_list = [d for d in meta_config_list if
                                   d.get('is_reference_column', None) and d.get('is_reference_column') == "Y"]
    if meta_config_particular_list:
        return meta_config_particular_list
    else:
        return []


def _get_meta_config_visible_particular_list(meta_config_list):
    meta_config_particular_list = [d for d in meta_config_list if
                                   d.get('is_reference_column', None) and d.get('is_reference_column') == "Y"
                                   and (d.get('is_helper_column', "N") != "Y")
                                   ]
    if meta_config_particular_list:
        return meta_config_particular_list
    else:
        return []


def fetch_one_to_many(dataframe, meta_config_list, inputdburl, table_name):
    oneToManyGenerator_list = [d for d in meta_config_list if d['generator_name'] in ['OneToManyGenerator']]

    for oneToManyGeneratorDict in oneToManyGenerator_list:
        filter = {
            'column_index': [oneToManyGeneratorDict.get("column_sequence_id")],
            'table_id': [oneToManyGeneratorDict.get("table_id")]
        }
        oneToManyCondDf = db_helper.read_table(table_name, inputdburl, wsprefix=None, filter=filter)

        column_name = oneToManyGeneratorDict.get("column_name")
        # for loop the dataframe
        for index_label, row_series in oneToManyCondDf.iterrows():

            if not row_series.get("frequency_in_duration", None) or not row_series.get("duration", None):
                dataframe = process_each_row(row_series, dataframe, column_name)
            else:
                dataframe = process_each_row_step(row_series, dataframe, column_name)
    return dataframe


def process_each_row_step(row_series, df, column_name):
    conditions = row_series.get("conditions")
    frequeny_of_occurrence = row_series.get("frequeny_of_occurrence")

    distribution_of_types = row_series.get("distribution_of_types")

    step_duration = row_series.get("frequency_in_duration", None)
    duration = row_series.get("duration", None)

    dependent_column = row_series.get("dependent_column").split(',')
    processed_df = None
    for vals in dependent_column:
        arrt = 'getattr(df, "{}")'.format(vals)
        # print(arrt)
        word1 = "'getattr(df, \"{}\")'".format(vals)
        word2 = "getattr(df, \"{}\")".format(vals)
        conditions = conditions.replace(vals, arrt).replace(word1,
                                                            word2).replace('[', '').replace(']', '')
    filtered_df = df[eval(conditions)]

    # 1 send for each dimension

    if "Probability" in distribution_of_types.keys():

        finaldf_multiplied = multpilydf(filtered_df, frequeny_of_occurrence, step_duration, duration)

        finaldf_dist_applied_df = applydistribution(finaldf_multiplied, distribution_of_types, column_name)

    else:
        finaldf_dist_applied_df = multpilyanddistdf(filtered_df, frequeny_of_occurrence,
                                                    distribution_of_types['ListofValues'], column_name, step_duration,
                                                    duration)

    remainingdf = df[~eval(conditions)]

    return pd.concat([remainingdf, finaldf_dist_applied_df], ignore_index=True)


def process_each_row(row_series, df, column_name):
    conditions = row_series.get("conditions")
    frequeny_of_occurrence = row_series.get("frequeny_of_occurrence")

    distribution_of_types = row_series.get("distribution_of_types")

    dependent_column = row_series.get("dependent_column").split(',')
    processed_df = None
    for vals in dependent_column:
        arrt = 'getattr(df, "{}")'.format(vals)
        # print(arrt)
        word1 = "'getattr(df, \"{}\")'".format(vals)
        word2 = "getattr(df, \"{}\")".format(vals)
        conditions = conditions.replace(vals, arrt).replace(word1,
                                                            word2).replace('[', '').replace(']', '')
    filtered_df = df[eval(conditions)]

    # 1 send for each dimension

    if "Probability" in distribution_of_types.keys():

        finaldf_multiplied = multpilydf(filtered_df, frequeny_of_occurrence)

        finaldf_dist_applied_df = applydistribution(finaldf_multiplied, distribution_of_types, column_name)

    else:
        finaldf_dist_applied_df = multpilyanddistdf(filtered_df, frequeny_of_occurrence,
                                                    distribution_of_types['ListofValues'], column_name)

    remainingdf = df[~eval(conditions)]

    return pd.concat([remainingdf, finaldf_dist_applied_df], ignore_index=True)


def multpilyanddistdf(filtered_df, frequeny_of_occurrence, listofValues, column_name, step_duration=None,
                      duration=None):
    perm = np.random.permutation(filtered_df.index)
    m = len(filtered_df.index)

    prev_end = 0
    finaldf_multiplied = None

    for key, val in frequeny_of_occurrence.items():
        iterationdf = None

        new_end = int(val * m)
        if prev_end == 0:
            iterationdf = filtered_df.ix[perm[:new_end]]
            prev_end = new_end
        else:
            iterationdf = filtered_df.ix[perm[prev_end: prev_end + new_end]]
            prev_end = prev_end + new_end

        occurence = int(key)

        for i in range(occurence):
            try:
                iterationdf[column_name] = listofValues[i]
            except IndexError:
                iterationdf[column_name] = 'NA'
            finaldf_multiplied = pd.concat([finaldf_multiplied, iterationdf], ignore_index=True)

    if step_duration and duration:
        container = createContainerObject(name="example", size=len(finaldf_multiplied),
                                          master_seed=12345, parameter=None, step_duration=pd.Timedelta(step_duration));
        population = create_population_from_df(finaldf_multiplied, container)

        container.populations["example"] = population

        iteration_story = container.create_story(
            name='story',
            initiating_population=container.populations["example"],
            member_id_field="ID",
            timer_gen=ConstantDependentGenerator(value=1)
        )

        iteration_story.set_operations(
            container.populations["example"].ops.lookup(
                id_field="ID",
                select=({i: i for i in finaldf_multiplied.columns})),
            operations.FieldLogger(log_id="example", cols=list(finaldf_multiplied.columns))
        )

        finaldf_multiplied = container.runtimed(
            duration=pd.Timedelta(duration),
            log_output_folder="output/example3",
            delete_existing_logs=True
        )

    return finaldf_multiplied


def applydistribution(finaldf_multiplied, distribution_of_types, column_name):
    finaldf_multiplied = finaldf_multiplied.sample(frac=1).reset_index(drop=True)

    finaldf_multiplied[column_name] = np.random.choice(size=len(finaldf_multiplied),
                                                       a=distribution_of_types['ListofValues'],
                                                       p=distribution_of_types['Probability'])

    return finaldf_multiplied


def multpilydf(filtered_df, frequeny_of_occurrence, step_duration=None, duration=None):
    perm = np.random.permutation(filtered_df.index)
    m = len(filtered_df.index)

    prev_end = 0
    finaldf_multiplied = None

    for key, val in frequeny_of_occurrence.items():
        iterationdf = None

        new_end = int(val * m)
        if prev_end == 0:
            iterationdf = filtered_df.ix[perm[:new_end]]
            prev_end = new_end
        else:
            iterationdf = filtered_df.ix[perm[prev_end: prev_end + new_end]]
            prev_end = prev_end + new_end

        int_multiplyer = int(key)
        iterationdf_multiplied = iterationdf.loc[iterationdf.index.repeat(int_multiplyer)].reset_index(drop=True)

        finaldf_multiplied = pd.concat([finaldf_multiplied, iterationdf_multiplied], ignore_index=True)

    if step_duration and duration:
        container = createContainerObject(name="example", size=len(finaldf_multiplied),
                                          master_seed=12345, parameter=None, step_duration=pd.Timedelta(step_duration));
        population = create_population_from_df(finaldf_multiplied, container)

        container.populations["example"] = population

        iteration_story = container.create_story(
            name='story',
            initiating_population=container.populations["example"],
            member_id_field="ID",
            timer_gen=ConstantDependentGenerator(value=1)
        )

        iteration_story.set_operations(
            container.populations["example"].ops.lookup(
                id_field="ID",
                select=({i: i for i in finaldf_multiplied.columns})),
            operations.FieldLogger(log_id="example", cols=list(finaldf_multiplied.columns))
        )

        itr_dataframe = container.runtimed(
            duration=pd.Timedelta(duration),
            log_output_folder="output/example3",
            delete_existing_logs=True
        )

    return finaldf_multiplied


def create_population_from_df(filtered_dataframe, container):
    from components.core_components.table_container.population import Population
    return Population.load_from_df(filtered_dataframe, container)


def create_datafarme(table_name, size, master_seed, parameter, meta_config__list):
    container = createContainerObject(name=table_name, size=size,
                                      master_seed=master_seed, parameter=parameter, step_duration=pd.Timedelta("1h"));

    population = initializePopulation(container=container)

    gen_instance_list = initializePersonaGenerators(
        column_prptys_meta_json_list=meta_config__list)

    population = createPopulation(gen_instance_list=gen_instance_list, population=population,
                                  size=container.size);

    dataframe = population.to_dataframe(size=container.size)

    logging.debug('----------- shape of dataframe is : {}'.format(dataframe.shape))
    logging.debug('----------- description of dataframe is : {}'.format(dataframe.describe()))

    return container, population, dataframe
