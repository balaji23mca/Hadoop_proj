
import time

import numpy as np
import pandas as pd

from components.core_components.generators.generator import ConstantDependentGenerator
from components.core_components.table_container import operations
from components.core_components.utils.helper import *;



def process_step_duration(row_series, df):
    conditions = row_series.get("conditions")
    step_duration = row_series.get("frequency_in_duration", None)
    duration = row_series.get("duration", None)

    dependent_column = row_series.get("dependent_column").split(',')
    processed_df = None
    for vals in dependent_column:
        arrt = 'getattr(df, "{}")'.format(vals)
        # print(arrt)
        word1 = "'getattr(df, \"{}\")'".format(vals)
        word2 = "getattr(df, \"{}\")".format(vals)
        conditions = conditions.replace(vals, arrt).replace(word1,
                                                            word2).replace('[', '').replace(']', '')
    filtered_df = df[eval(conditions)]

    if len(filtered_df.index) > 0:

        if step_duration and duration:
            container = createContainerObject(name="example", size=len(filtered_df),
                                              master_seed=12345, parameter=None, step_duration=pd.Timedelta(step_duration));
            population = create_population_from_df(filtered_df, container)

            cols = list(filtered_df.columns)

            if "time_series" in cols: cols.remove("time_series")

            container.populations["example"] = population

            iteration_story = container.create_story(
                name='story',
                initiating_population=container.populations["example"],
                member_id_field="ID",
                timer_gen=ConstantDependentGenerator(value=1)
            )



            iteration_story.set_operations(
                container.clock.ops.timestamp(named_as="time_series"),
                container.populations["example"].ops.lookup(
                    id_field="ID",
                    select=({i: i for i in cols})),
                operations.FieldLogger(log_id="example")
            )

            filtered_df = container.runtimed(
                duration=pd.Timedelta(duration),
                log_output_folder="output/example3",
                delete_existing_logs=True
            )

            cols.append("time_series") if "time_series" not in cols else cols

            filtered_df = filtered_df[cols]


        remainingdf = df[~eval(conditions)]


        return pd.concat([remainingdf, filtered_df], ignore_index=True, axis=0)
    else:
        return df

def create_population_from_df(filtered_dataframe, container):
    from components.core_components.table_container.population import Population
    return Population.load_from_df(filtered_dataframe, container)
