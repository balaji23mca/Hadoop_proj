import time

import numpy as np
import pandas as pd

from components.core_components.generators.generator import ConstantDependentGenerator
from components.core_components.table_container import operations
from components.core_components.utils.helper import *;

"""
   Comment : One to Many type table creation
"""

def spread_df_on_occuerence(filtered_df, frequeny_of_occurrence, step_duration=None, duration=None):

#[{"1-2": 0.6, "3-4": 0.4}, {"1-2": 0.6, "3-4": 0.4}]

    perm = np.random.permutation(filtered_df.index)
    m = len(filtered_df.index)

    prev_end = 0
    finaldf_multiplied = None

    for key, val in frequeny_of_occurrence.items(): #  distribution_of_probable_values
        iterationdf = None

        new_end = int(val * m)
        if prev_end == 0:
            iterationdf = filtered_df.ix[perm[:new_end]]
            prev_end = new_end
        else:
            iterationdf = filtered_df.ix[perm[prev_end: prev_end + new_end]]
            prev_end = prev_end + new_end

        int_multiplyer = int(key)
        iterationdf_multiplied = iterationdf.loc[iterationdf.index.repeat(int_multiplyer)].reset_index(drop=True)

        finaldf_multiplied = pd.concat([finaldf_multiplied, iterationdf_multiplied], ignore_index=True)

    return finaldf_multiplied