import time

import numpy as np
import pandas as pd

from components.core_components.generators.generator import ConstantDependentGenerator
from components.core_components.table_container import operations
from components.core_components.utils.helper import *;



def apply_distribution_on_spread(finaldf_multiplied, distribution_of_types, column_name):


    finaldf_multiplied = finaldf_multiplied.sample(frac=1).reset_index(drop=True)

    finaldf_multiplied[column_name] = np.random.choice(size=len(finaldf_multiplied),
                                                       a=distribution_of_types['ListofValues'],
                                                       p=distribution_of_types['Probability'])

    return finaldf_multiplied


def spread_and_distribution_combined(filtered_df, frequeny_of_occurrence, listofValues, column_name, step_duration=None,
                      duration=None):


#[{"1-2": 0.6, "3-4": 0.4}, {"1-2": 0.6, "3-4": 0.4}]
    perm = np.random.permutation(filtered_df.index)
    m = len(filtered_df.index)

    prev_end = 0
    finaldf_multiplied = None

    for key, val in frequeny_of_occurrence.items():
        iterationdf = None

        new_end = int(val * m)
        if prev_end == 0:
            iterationdf = filtered_df.ix[perm[:new_end]]
            prev_end = new_end
        else:
            iterationdf = filtered_df.ix[perm[prev_end: prev_end + new_end]]
            prev_end = prev_end + new_end


        occurence = int(key)

        for i in range(occurence):
            try:
                iterationdf[column_name] = listofValues[i]
            except IndexError:
                iterationdf[column_name] = 0
            finaldf_multiplied = pd.concat([finaldf_multiplied, iterationdf], ignore_index=True)

    return finaldf_multiplied
