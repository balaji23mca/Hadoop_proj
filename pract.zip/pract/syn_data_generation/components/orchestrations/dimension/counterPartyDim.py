import time

import numpy as np
import pandas as pd

from components.core_components.generators.generator import ConstantDependentGenerator
from components.core_components.table_container import operations
from components.core_components.utils.helper import *;



def add_counter_party(finaldf_multiplied,list_of_probable_values, counter_party_column_name,cond_column_name,filedList):
    try:

        logging.debug('before counter party size is {}'.format(len(finaldf_multiplied)))
        cols = list(finaldf_multiplied.columns)

        df_after_for_loop = None
        for counter_party_idx, counter_party_val in enumerate(list_of_probable_values):
            column_name = counter_party_column_name[counter_party_idx]

            finaldf_multiplied_filtered = finaldf_multiplied[finaldf_multiplied[cond_column_name] == counter_party_val]

            if len(finaldf_multiplied_filtered.index) > 0:

                if column_name != "":
                    counter_party_name = "counter_party_{}".format(column_name)

                    finaldf_multiplied_filtered = finaldf_multiplied_filtered.reset_index(drop=True)

                    if counter_party_name in cols: cols.remove(counter_party_name)

                    container = createContainerObject(name="counter_party", size=len(finaldf_multiplied_filtered.index),
                                                                master_seed=1234);

                    population = create_population_from_df(finaldf_multiplied_filtered, container)

                    container.populations["counter_party"] = population

                    transaction_story = create_story(container)

                    transaction_story.append_operations(
                        container.populations["counter_party"].ops.lookup(id_field="ID",select=({i: i for i in cols})),

                        container.populations["counter_party"].ops.lookup(id_field="OTHER_PERSON", select={column_name: counter_party_name}),

                    )
                    transaction_story.append_operations(
                        operations.FieldLogger(log_id="counter_party")
                    )

                    dataframe_itr = container.run(
                        duration=int(1),  # wothout parameter
                        log_output_folder="output/example_scenario",
                        delete_existing_logs=True
                    )

                    cols.append(counter_party_name) if counter_party_name not in cols else cols
                    # cols.append(counter_party_name)

                    dataframe_itr = dataframe_itr[cols]

                    df_after_for_loop = pd.concat([df_after_for_loop, dataframe_itr], ignore_index=True,sort=False)

                else:
                    df_after_for_loop = pd.concat([df_after_for_loop, finaldf_multiplied_filtered], ignore_index=True,sort=False)

                # return df_after_for_loop

            else:
                finaldf_multiplied
        logging.debug('after counter party size is {}'.format(len(df_after_for_loop)))
        return df_after_for_loop
    except Exception as e:
        logging.error(e)
        return finaldf_multiplied

def create_population_from_df(filtered_dataframe, container):
    from components.core_components.table_container.population import Population
    return Population.load_from_df(filtered_dataframe, container)

def create_story(container,):

    table_name =  "counter_party"

    transaction_story = container.create_story(
        name=table_name,
        initiating_population=container.populations[table_name],
        member_id_field="ID",
        timer_gen=ConstantDependentGenerator(value=1)
    )

    transaction_story.set_operations(
        container.populations[table_name].ops.select_one(named_as="OTHER_PERSON"))


    return transaction_story