import os

import matplotlib.pyplot as plt
from components.core_components.utils.utility import fetch_table
from components.orchestrations.dimension.counterPartyDim import *;
from components.orchestrations.dimension.stepNDurationDim import *;


######################

def one_to_many(meta_config_list, duration, inputdburl, table_name,oneToManyCondDf, splitted_dataframe):
    dataframe = splitted_dataframe.reset_index(drop=True)
    oneToManyGenerator_list = [d for d in meta_config_list if d['generator_name'] in ['OneToManyGenerator']]
    oneToManyCond = oneToManyCondDf
    for oneToManyGeneratorDict in oneToManyGenerator_list:  # fetching details from onetomany tables
        filter = {
            'column_name': [oneToManyGeneratorDict.get('column_name')],  #
            'table_name': [oneToManyGeneratorDict.get("table_name")]
        }
        if filter:
            for key, values in filter.items():
                oneToManyCond_filtered_df = oneToManyCond[oneToManyCond[key].isin(values)]



        column_name = oneToManyGeneratorDict.get("column_name")
        d_type = oneToManyGeneratorDict.get("column_data_type")

        # for loop the dataframe
        for index_label, row_series in oneToManyCond_filtered_df.iterrows():
            try:
                dataframe = process_each_row(row_series, dataframe, column_name, duration,d_type)

                # print('index {} , dtype {}'.format(index_label,dataframe.get(column_name).dtype ))
            except Exception as e:
                logging.debug(e)
        if d_type == 'varchar':
            d_type = 'str'
        elif d_type == 'double':
            d_type = 'float'
        dataframe = dataframe.astype({column_name: eval(d_type)})
    return dataframe


def process_each_row(row_series, df, column_name, duration,d_type):
    ###
    conditions = row_series.get("conditions")
    input_column_names = row_series.get("input_column_names").split(',')
    probable_count_distribution_for_the_period = row_series.get("probable_count_distribution_for_the_period", None)
    probable_period_of_occurrence = row_series.get("probable_period_of_occurrence", None)
    distribution_of_probable_values = row_series.get("distribution_of_probable_values", None)
    list_of_probable_values = row_series.get("list_of_probable_values", None)
    ###

    if not distribution_of_probable_values:  ## setting default probablity as equal prob
        len_list_of_probable_values = len(list_of_probable_values)
        val = 1.0 / len_list_of_probable_values
        distribution_of_probable_values = [val] * len_list_of_probable_values

    processed_df = None
    logging.debug('conditions is  : {}'.format(conditions))
    #### processing condition to get filtered df
    for vals in input_column_names:
        if vals[0] == ' ':
            vals = vals[1:]
        arrt = 'getattr(df, "{}")'.format(vals)
        word1 = "'getattr(df, \"{}\")'".format(vals)
        word2 = "getattr(df, \"{}\")".format(vals)
        conditions = conditions.replace(vals, arrt).replace(word1,
                                                            word2).replace('[', '').replace(']', '')
    filtered_df = df[eval(conditions)]
    len_filtered_df = len(filtered_df)
    if len(filtered_df) == 0:
        logging.debug('-----------No dataframe available for the filter : {}'.format(row_series.get("conditions")))
        return df
    logging.debug('Initial size before process_each_row : {}'.format(filtered_df.shape))
    ####
    filtered_df = filtered_df.reset_index(drop=True)
    perm = np.random.permutation(filtered_df.index)
    m = len(filtered_df.index)
    prev_end = 0
    finaldf_multiplied = None

    if len_filtered_df > len(distribution_of_probable_values):

        for idx, val in enumerate(distribution_of_probable_values):  # distribution_of_probable_values

            iterationdf = None
            if len(filtered_df) > 1:
                new_end = round(val * m)
                if new_end == 0:
                    iterationdf = filtered_df
                else:
                    if prev_end == 0:
                        iterationdf = filtered_df.loc[
                            filtered_df.index[perm[:new_end]]]  # dfd.ix[[0, 2]]  -->  dfd.loc[dfd.index[[0, 2]]]
                        prev_end = new_end
                    else:
                        iterationdf = filtered_df.loc[filtered_df.index[perm[prev_end: prev_end + new_end]]]
                        prev_end = prev_end + new_end
            else:
                iterationdf = filtered_df
            iterationdf = iterationdf.reset_index(drop=True)

            if isinstance(probable_count_distribution_for_the_period, list):
                probable_count_distribution = probable_count_distribution_for_the_period[idx]
            elif isinstance(probable_count_distribution_for_the_period, dict):
                probable_count_distribution = probable_count_distribution_for_the_period

            ###
            perm_in_internal_itr = np.random.permutation(iterationdf.index)
            m_1 = len(iterationdf.index)

            prev_end_in_internal_itr = 0
            finaldf_multiplied_1 = None

            if len(iterationdf) >= len(probable_count_distribution):

                for key_in_internal_itr, value_in_internal_itr in probable_count_distribution.items():  # distribution_of_probable_values
                    internal_itr_dataframe = None

                    if len(iterationdf) > 1:
                        new_end_in_internal_itr = round(value_in_internal_itr * m_1)
                        if prev_end_in_internal_itr == 0:
                            internal_itr_dataframe = iterationdf.loc[iterationdf.index[
                                perm_in_internal_itr[
                                :new_end_in_internal_itr]]]  # dfd.ix[[0, 2]]  -->  iterationdf.loc[iterationdf.index[perm[:new_end_1]]]
                            prev_end_in_internal_itr = new_end_in_internal_itr
                        else:
                            internal_itr_dataframe = iterationdf.loc[iterationdf.index[perm_in_internal_itr[
                                                                                       prev_end_in_internal_itr: prev_end_in_internal_itr + new_end_in_internal_itr]]]  # dfd.ix[[0, 2]]  -->  iterationdf.loc[iterationdf.index[perm[prev_end_1: prev_end_1 + new_end_1]]]
                            prev_end_in_internal_itr = prev_end_in_internal_itr + new_end_in_internal_itr
                    else:
                        internal_itr_dataframe = iterationdf
                    ### probable_count_distribution_for_the_period
                    iterationdf_1_multiplied = multiply_df_on_range(key_in_internal_itr, internal_itr_dataframe)

                    ### proable_period_of_ocurrene
                    if probable_period_of_occurrence:
                        try:
                            itr_count = int(calculate_iteration(duration, probable_period_of_occurrence[idx]))
                        except IndexError:
                            itr_count = 1

                        iterationdf_1_multiplied = iterationdf_1_multiplied.loc[
                            iterationdf_1_multiplied.index.repeat(itr_count)].reset_index(drop=True)

                    ### list_of_probable_values
                    try:
                        import random
                        value_to_set = []
                        if len(iterationdf_1_multiplied) == list_of_probable_values:
                            value_to_set = list_of_probable_values

                        for i in range(len(iterationdf_1_multiplied)):
                            value_to_set.append(random.choice(list_of_probable_values))

                        iterationdf_1_multiplied[column_name] = value_to_set # list(map(eval(d_type), value_to_set)) #value_to_set #d_type list(map(str, key_list))

                        # iterationdf_1_multiplied[column_name] = list_of_probable_values[idx]
                    except IndexError:
                        iterationdf_1_multiplied[column_name] = 0
                    ### timestamp
                    if probable_period_of_occurrence:
                        try:
                            iterationdf_1_multiplied['time_series'] = get_timestamp(len(iterationdf_1_multiplied),
                                                                                    probable_period_of_occurrence[idx], None)
                        except IndexError:
                            iterationdf_1_multiplied['time_series'] = get_timestamp(len(iterationdf_1_multiplied),
                                                                                    None, None)
                    else:
                        iterationdf_1_multiplied['time_series'] = get_timestamp(len(iterationdf_1_multiplied),
                                                                                None, duration)
                    ### adding back to df
                    finaldf_multiplied_1 = pd.concat([finaldf_multiplied_1, iterationdf_1_multiplied], ignore_index=True)
            else:
                finaldf_multiplied_1 = iterationdf

                if probable_period_of_occurrence:
                    try:
                        finaldf_multiplied_1['time_series'] = get_timestamp(len(finaldf_multiplied_1),
                                                                          probable_period_of_occurrence[0], None)
                    except IndexError:
                        finaldf_multiplied_1['time_series'] = get_timestamp(len(finaldf_multiplied_1),
                                                                          None, None)
                else:
                    finaldf_multiplied_1['time_series'] = get_timestamp(len(finaldf_multiplied_1),
                                                                      None, duration)


            ###
            finaldf_multiplied = pd.concat([finaldf_multiplied, finaldf_multiplied_1], ignore_index=True)
            if len(finaldf_multiplied) == 0:
                pass  # filtered_df

        logging.debug(
            'input df shape was {}, output df shape is {}'.format(filtered_df.shape, finaldf_multiplied.shape))

    else:
        finaldf_multiplied = filtered_df

        try:
            import random
            value_to_set = []
            if len(finaldf_multiplied) == list_of_probable_values:
                value_to_set = list_of_probable_values

            for i in range(len(finaldf_multiplied)):
                value_to_set.append(random.choice(list_of_probable_values))

            finaldf_multiplied[
                column_name] = value_to_set  # list(map(eval(d_type), value_to_set)) #value_to_set #d_type list(map(str, key_list))

            # iterationdf_1_multiplied[column_name] = list_of_probable_values[idx]
        except IndexError:
            finaldf_multiplied[column_name] = 0


        if probable_period_of_occurrence:
            try:
                finaldf_multiplied['time_series'] = get_timestamp(len(finaldf_multiplied),
                                                                        probable_period_of_occurrence[0], None)
            except IndexError:
                finaldf_multiplied['time_series'] = get_timestamp(len(finaldf_multiplied),
                                                                        None, None)
        else:
            finaldf_multiplied['time_series'] = get_timestamp(len(finaldf_multiplied),
                                                                    None, duration)


    ######
    remainingdf = df[~eval(conditions)]
    return pd.concat([remainingdf, finaldf_multiplied], ignore_index=True, axis=0, sort=False)


######################
########
def calculate_iteration(duration, occuerence):
    iterations = 1
    try:
        duration_list = duration.split()
        occuerence_days = 1
        days = 1

        if len(duration_list) > 1:
            if duration_list[1] == 'year' or duration_list[1] == 'years':
                days = 365
            elif duration_list[1] == 'month' or duration_list[1] == 'months':
                days = 30
            elif duration_list[1] == 'day' or duration_list[1] == 'days':
                days = 1

        no_of_days = int(duration_list[0]) * days

        if occuerence == 'yearly':
            occuerence_days = 365
        elif occuerence == 'monthly':
            occuerence_days = 30
        elif occuerence == 'daily':
            occuerence_days = 1

        iterations = no_of_days / occuerence_days
    except Exception as e:
        logging.error(e)
    return round(iterations)


########
def get_timestamp(size, occuerence=None, duration=None):
    import datetime
    import time
    import pandas as pd
    ts = time.time()
    if occuerence:
        try:
            st = datetime.datetime.fromtimestamp(ts).strftime('%Y-%m-%d %H:%M:%S')
            if occuerence == 'yearly':
                freq = 'Y'
            elif occuerence == 'monthly':
                freq = 'M'
            elif occuerence == 'daily':
                freq = 'D'
        except Exception as e:
            logging.error(e)

        dates = pd.date_range(end=st, periods=size, freq=freq)
    elif duration:
        try:
            start_date = datetime.datetime.fromtimestamp(ts)
            end_date = datetime.datetime.fromtimestamp(ts)
            duration_list = duration.split()

            if len(duration_list) > 1:
                days = int(duration_list[0])

                if duration_list[1] == 'year' or duration_list[1] == 'years':
                    start_date = start_date - datetime.timedelta(days=days * 365)
                elif duration_list[1] == 'month' or duration_list[1] == 'months':
                    start_date = start_date - datetime.timedelta(days=days * 30)
                elif duration_list[1] == 'day' or duration_list[1] == 'days':
                    start_date = start_date - datetime.timedelta(days=days - 1)
        except Exception as e:
            logging.error(e)

        dates = pd.date_range(start=start_date.strftime('%Y-%m-%d %H:%M:%S'),
                              end=end_date.strftime('%Y-%m-%d %H:%M:%S'), periods=size)
    return dates


########
def multiply_df_on_range(key_1, iterationdf_1):
    import numpy as np
    range_spilt_list = key_1.split("-")
    # print(range_spilt_list)

    df_after_multiply = None
    if len(range_spilt_list) > 1:
        range_list = list(range(int(range_spilt_list[0]), int(range_spilt_list[1]) + 1))

        range_size = len(range_list)
        df_split = np.array_split(iterationdf_1, range_size)

        for idx_range, val_range in enumerate(range_list):
            temp_df = df_split[idx_range].loc[df_split[idx_range].index.repeat(val_range)].reset_index(drop=True)
            df_after_multiply = pd.concat([df_after_multiply, temp_df], ignore_index=True)

    elif len(range_spilt_list) > 0:
        val_range = int(range_spilt_list[0])
        temp_df = iterationdf_1.loc[iterationdf_1.index.repeat(val_range)].reset_index(drop=True)
        df_after_multiply = pd.concat([df_after_multiply, temp_df], ignore_index=True)

    # print(df_after_multiply.shape)
    return df_after_multiply


######################
import multiprocessing
from multiprocessing import Pool

import time
from functools import partial


def calculate_running_balance(running_bal_list_df, meta_param,avg_time,pool_value):
    param = eval(meta_param)
    # running_balance = _get_running_balance(dataframe,)

    func = partial(running_banalce_method,  param['group_by_column'], param['apply_to_column'],
                                       param['updater_column']
                                       , param['column_operator'], param['action_operator'], param['conditions'])

    start_time1 = time.time()
    if avg_time:
        logging.info('submitting to multiprocessing pool, average wait time is {}'.format(avg_time))
    else:
        logging.info('submitting to multiprocessing pool....')
    pool = Pool(pool_value)
    list_of_dataframes = pool.map(func, running_bal_list_df)
    pool.close()
    pool.join()
    avg_time = '%.3f seconds' % (time.time() - start_time1)
    logging.info('time spent in pool - : {}'.format(avg_time))
    # dataframe = running_banalce_method(running_bal_list_df, param['group_by_column'], param['apply_to_column'],
    #                                    param['updater_column']
    #                                    , param['column_operator'], param['action_operator'], param['conditions'])
    dataframe = pd.concat(list_of_dataframes)
    return dataframe, avg_time


######################

def chunker_list(seq, size):
    return (seq[i::size] for i in range(size))


def running_banalce_method(group_by_column=None, apply_to_column=None, updater_column=None,
                           column_operator=None,
                           action_operator=None, conditions=None, running_bal_grouped_df_dict=None):
    from concurrent.futures import ThreadPoolExecutor, as_completed

    start_time1 = time.time()
    result = []

    # uncomment to run in sync without thread
    # for key, value_df in running_bal_grouped_df_dict.items():
    #     out_df_itr = running_value_helper(key, group_by_column, value_df, apply_to_column, column_operator,
    #                         conditions, updater_column, action_operator)
    #     result.append(out_df_itr)
    # out_df = pd.concat(result)
    # uncomment to run in sync without thread - Ends

    n = 10

    pool = ThreadPoolExecutor(n)
    futures = []

    for key, value_df in running_bal_grouped_df_dict.items():
        if value_df is not None:
            futures.append(
                pool.submit(running_value_helper, key, group_by_column, value_df, apply_to_column, column_operator,
                            conditions, updater_column, action_operator))

    for out_df_itr in as_completed(futures):
        response_df = out_df_itr.result()
        result.append(response_df)
        logging.debug('--response received for {} - {} '.format(group_by_column , response_df['account_id'][0]))
    out_df = pd.concat(result)

    logging.debug('Running value execution time - : %.3f seconds' % (time.time() - start_time1))
    return out_df


def running_value_helper(key, group_by_column, df, apply_to_column, column_operator, conditions, updater_column,
                         action_operator):
    import warnings
    warnings.filterwarnings('ignore')

    logging.debug('Submitting {} operations for {} - {}'.format(len(df), group_by_column, key))

    df = df.reset_index(drop=True)
    for index, row in df.iterrows():
        if column_operator is not None:
            try:
                if df[column_operator][index] == conditions[0]:
                    df[apply_to_column][index:] = df[apply_to_column][index] - df[updater_column][index]
                elif df[column_operator][index] == conditions[1]:
                    df[apply_to_column][index:] = df[apply_to_column][index] + df[updater_column][index]
            except Exception as e:
                logging.error(e)
        else:
            try:
                if action_operator == '-':
                    df[apply_to_column][index:] = df[apply_to_column][index] - df[updater_column][index]
                if action_operator == '+':
                    df[apply_to_column][index:] = df[apply_to_column][index] + df[updater_column][index]
            except Exception as e:
                logging.error(e)
    return df


def _get_running_balance(meta_config_list):
    running_value_list = [d for d in meta_config_list if
                          d.get('table_parameters', None) and d.get('table_parameters').get('running_value', None)
                          and d.get('table_parameters').get('running_value') == "Y"]
    if running_value_list:
        return running_value_list
    else:
        return []


# def transactionGraph(data, meta_config_list):
#     import numpy as np
#     import os.path
#     import matplotlib.pyplot as plt
#     import pandas as pd
#     # %matplotlib inline
#     from matplotlib import pyplot
#     # from pandas.tools.plotting import lag_plot
#
#     def trans_dispersion(data, trans_date, trans_id):
#         data[trans_date] = pd.to_datetime(data[trans_date])
#         tot_trans = data.groupby(data[trans_date].dt.strftime('%Y'))[trans_id].count()
#         y = tot_trans.to_frame().reset_index()
#         y[trans_date] = pd.to_datetime(y[trans_date])
#         y = y.set_index(trans_date)
#         y.plot(figsize=(10, 5), linewidth=2, fontsize=10, grid=True)
#         plt.xlabel('Year', fontsize=20)
#         plt.ylabel("#Transactions", fontsize=15)
#         # pyplot.show()
#         plt.savefig(os.path.normpath(
#             os.path.join(os.path.dirname(__file__), '../../../output/graphs/')) + '\\' + "Transaction_id_Time")
#         # plt.savefig("Test")
#         # gen_instance_list[j].get('column_name'))
#         # plt.savefig("00000000.png")
#
#     def trans_products_dispersion(data, trans_id, product_name):
#         tot_trans_per_prod = data.groupby(data[product_name])[trans_id].count().reset_index(name="count")
#         tot_trans_per_prod.plot.bar(x='product_name',
#                                     y='count',
#                                     align='center',
#                                     alpha=0.5)
#         # plt.bar(tot_trans_per_prod[product_name], tot_trans_per_prod['count'])
#         # plt.show()
#         plt.savefig(os.path.normpath(
#             os.path.join(os.path.dirname(__file__), '../../../output/graphs/')) + '/' + "BarGraph")
#
#     def trans_amount_dispersion(data, trans_date, tran_amt):
#         data[trans_date] = pd.to_datetime(data[trans_date])
#         tot_trans = data.groupby(data[trans_date].dt.strftime('%Y'))[tran_amt].sum()
#         y_amt = tot_trans.to_frame().reset_index()
#         y_amt[trans_date] = pd.to_datetime(y_amt[trans_date])
#         y_amt = y_amt.set_index(trans_date)
#         y_amt.plot(figsize=(10, 5), linewidth=2, fontsize=10, grid=True, style="k-")
#         # y.plot()
#         pyplot.show()
#         plt.savefig(os.path.normpath(
#             os.path.join(os.path.dirname(__file__),
#                          '../../../output/graphs/')) + '/' + "Transaction_id_tranAmount")
#
#     def trans_amount_dispersion_hist(data, trans_date, tran_amt):
#         data[trans_date] = pd.to_datetime(data[trans_date])
#         tot_trans = data.groupby(data[trans_date].dt.strftime('%Y'))[tran_amt].sum()
#         y_amt = tot_trans.to_frame().reset_index()
#         y_amt[trans_date] = pd.to_datetime(y_amt[trans_date])
#         y_amt = y_amt.set_index(trans_date)
#         y_amt.hist()
#         # pyplot.show()
#         plt.savefig(os.path.normpath(
#             os.path.join(os.path.dirname(__file__),
#                          '../../../output/graphs/')) + '/' + "Transaction_id_tranAmount_Histogram")
#
#     def trans_amount_log_dispersion(data, trans_date, transaction_amount):
#         data[trans_date] = pd.to_datetime(data[trans_date])
#         tot_trans = data.groupby(data[trans_date].dt.strftime('%Y'))[transaction_amount].sum()
#         ts_log = np.log(tot_trans)
#         # plt.plot(ts_log)
#         ts_log.plot(figsize=(10, 5), linewidth=2, fontsize=10, grid=True, style="k-")
#         # lag_plot(tot_trans)
#         # pyplot.show()
#         plt.savefig(os.path.normpath(
#             os.path.join(os.path.dirname(__file__),
#                          '../../../output/graphs/')) + '/' + "Transaction_id_tranAmount_LogDispersion")
#
#     def trans_amount_lag_plot(data, trans_date, transaction_amount):
#         data[trans_date] = pd.to_datetime(data[trans_date])
#         tot_trans = data.groupby(data[trans_date].dt.strftime('%Y'))[transaction_amount].sum()
#         ts_log = np.log(tot_trans)
#         # plt.plot(ts_log)
#         # ts_log.plot(figsize=(10,5), linewidth=2, fontsize=10,grid = True,style = "k-")
#         # lag_plot(tot_trans)
#         # pyplot.show()
#         plt.savefig(os.path.normpath(
#             os.path.join(os.path.dirname(__file__),
#                          '../../../output/graphs/')) + '/' + "Transaction_Date_tranAmount_LagPlot")
#
#     if meta_config_list:
#         for i in range(len(meta_config_list)):
#             if meta_config_list[i].get('graph_parameters', None):
#                 for j in range(len(eval(meta_config_list[i].get('graph_parameters', None)))):
#                     # l = len(eval(meta_config_list[i].get('graph_parameters', None))[j])
#                     # if l == 2:
#                     for dict in eval(meta_config_list[i].get('graph_parameters', None)):
#                         if dict.get('graph_type', None) == 'Bar_Graph':
#                             trans_products_dispersion(data,
#                                                       dict.get('y_axis', None), meta_config_list[i].get('column_name', None))
#
#                         elif dict.get('graph_type', None) == 'Hist_Graph':
#                             trans_amount_dispersion_hist(data,
#                                                          dict.get('y_axis', None), meta_config_list[i].get('column_name', None))
#
#                         elif dict.get('graph_type', None) == 'Time_Series_Graph':
#
#                             trans_dispersion(data,
#                                              dict.get('y_axis', None), meta_config_list[i].get('column_name', None))
#
#     # trans_dispersion(data, meta_config_list.value_date_time, meta_config_list.transaction_id) #trans_date='value_date_time', trans_id='transaction_id')
#     #
#     # trans_products_dispersion(data, trans_id='transaction_id', product_name='product_name')
#     #
#     # trans_amount_dispersion(data, trans_date='value_date_time', tran_amt='transaction_amount')
#     #
#     # trans_amount_dispersion_hist(data, trans_date = 'value_date_time', tran_amt='transaction_amount')
#     #
#     # trans_amount_log_dispersion(data, trans_date = 'value_date_time', transaction_amount='transaction_amount')
#     #
#     # trans_amount_lag_plot(data, trans_date = 'value_date_time', transaction_amount = 'transaction_amount')
#


def transactionGraph(data, meta_config_list):
    # %matplotlib inline
    # from matplotlib import pyplot
    # from pandas.tools.plotting import lag_plot

    def trans_dispersion(data, trans_id, trans_date):
        # if trans_date.type == date:
        # data[trans_date] = pd.to_datetime(data[trans_date])
        # tot_trans = data.groupby([data[trans_date].dt.strftime('%Y'),data[trans_date].dt.strftime('%m')])[trans_id].count()
        # #y = tot_trans.to_frame().reset_index()
        # y = pd.DataFrame(tot_trans)
        # # y[trans_date] = pd.to_datetime(y[trans_date]) #pd.to_datetime(data[trans_date])
        # # y = y.set_index(trans_date)
        # tot_trans.plot(figsize=(10, 5), linewidth=2, fontsize=10, grid=True)
        # plt.xlabel('Year', fontsize=20)
        # plt.ylabel(trans_id, fontsize=15)
        # from matplotlib import pyplot as pt
        data[trans_date] = pd.to_datetime(data[trans_date])
        if trans_date in data:
            data.set_index('time_series', inplace=True)
            # data.resample('1M').count()[trans_id].plot()
            df = data.resample('1M').count()['transaction_id']
            df = pd.DataFrame(df)
            df['time_s'] = df.index
            # import seaborn
            # seaborn.tsplot(df['transaction_id'], df['time_s'])
        plt.xlabel(trans_date)
        plt.ylabel(trans_id + '_count')
        plt.title('Time_Series_Graph')
        plt.plot(df['time_s'], df['transaction_id'])
        plt.xticks(rotation=45, ha='right')
        # pyplot.show()
        plt.savefig(os.path.normpath(
            os.path.join(os.path.dirname(__file__),
                         '../../../output/graphs/')) + '\\' + trans_date + '_vs_' + trans_id + '_Time_Series_Graph')
        plt.clf()
        # plt.savefig("Test")
        # gen_instance_list[j].get('column_name'))
        # plt.savefig("00000000.png")

    def trans_groupby(df, balance, trans_date, grpby_param):
        grp_df = df.groupby(grpby_param)
        # grp_df['account_id']
        # group_names_list = list(set(df[grpby_param]))
        # one_grp = grp_df.get_group(group_names_list[0])
        # pt.plot(one_grp[trans_date], one_grp[balance])
        group_names_list = list(set(df[grpby_param]))
        flag = 0
        # fig = plt.figure()
        for grp_name in group_names_list:
            one_grp = grp_df.get_group(grp_name)
            l = one_grp.index.values
            if len(one_grp) > 1 and one_grp[balance][l[0]] != 0:
                one_grp = one_grp.sort_values(by=trans_date, ascending=True)
                plt.xlabel(trans_date)
                plt.ylabel(balance)
                plt.title('Grouped_Time_Series_Graph')
                plt.plot(one_grp[trans_date], one_grp[balance])
                plt.xticks(rotation=45, ha='right')
                flag = 1
                break;
        if flag == 0:
            one_grp = grp_df.get_group(group_names_list[0])
            plt.xlabel(trans_date)
            plt.ylabel(balance)
            plt.title('Grouped_Time_Series_Graph')
            plt.plot(one_grp[trans_date], one_grp[balance])
            plt.xticks(rotation=45, ha='right')
        plt.tight_layout()
        plt.savefig(os.path.normpath(
            os.path.join(os.path.dirname(__file__),
                         '../../../output/graphs/')) + '\\' + trans_date + '_vs_' + balance + '_Grouped_Time_Series_Graph')
        plt.clf()
        # plt.savefig("Test")
        # gen_instance_list[j].get('column_name'))
        # plt.savefig("00000000.png")

    def trans_products_dispersion(data, product_name, trans_id):
        tot_trans_per_prod = data.groupby(data[product_name])[trans_id].count().reset_index(name="count")
        tot_trans_per_prod.plot.bar(x=product_name,
                                    y='count',
                                    align='center',
                                    alpha=0.5)
        # plt.bar(tot_trans_per_prod[product_name], tot_trans_per_prod['count'])
        # plt.show()
        plt.xticks(rotation=45, ha='right')
        plt.tight_layout()
        plt.savefig(os.path.normpath(
            os.path.join(os.path.dirname(__file__),
                         '../../../output/graphs/')) + '/' + product_name + '_' + trans_id + "_BarGraph")
        plt.clf()

    # def trans_amount_dispersion(data, trans_date, tran_amt):
    #     data[trans_date] = pd.to_datetime(data[trans_date])
    #     tot_trans = data.groupby(data[trans_date].dt.strftime('%Y'))[tran_amt].sum()
    #     y_amt = tot_trans.to_frame().reset_index()
    #     y_amt[trans_date] = pd.to_datetime(y_amt[trans_date])
    #     y_amt = y_amt.set_index(trans_date)
    #     y_amt.plot(figsize=(10, 5), linewidth=2, fontsize=10, grid=True, style="k-")
    #     # y.plot()
    #     pyplot.show()
    #     plt.savefig(os.path.normpath(
    #         os.path.join(os.path.dirname(__file__),
    #                      '../../../output/graphs/')) + '/' + "Transaction_id_tranAmount")

    # def trans_amount_dispersion_hist(data, tran_amt, trans_date):
    #     data[trans_date] = pd.to_datetime(data[trans_date])
    #     tot_trans = data.groupby(data[trans_date].dt.strftime('%Y'))[tran_amt].sum()
    #     y_amt = tot_trans.to_frame().reset_index()
    #     y_amt[trans_date] = pd.to_datetime(y_amt[trans_date])
    #     y_amt = y_amt.set_index(trans_date)
    #     y_amt.hist()
    #     # pyplot.show()
    #     pt.savefig(os.path.normpath(
    #         os.path.join(os.path.dirname(__file__),
    #                      '../../../output/graphs/')) + '/' + trans_date +'_' + tran_amt +"_Hist_Graph")
    #     pt.clf()

    # def trans_amount_log_dispersion(data, trans_date, transaction_amount):
    #     data[trans_date] = pd.to_datetime(data[trans_date])
    #     tot_trans = data.groupby(data[trans_date].dt.strftime('%Y'))[transaction_amount].sum()
    #     ts_log = np.log(tot_trans)
    #     # plt.plot(ts_log)
    #     ts_log.plot(figsize=(10, 5), linewidth=2, fontsize=10, grid=True, style="k-")
    #     # lag_plot(tot_trans)
    #     # pyplot.show()
    #     plt.savefig(os.path.normpath(
    #         os.path.join(os.path.dirname(__file__),
    #                      '../../../output/graphs/')) + '/' +  +trans_date+'_'+transaction_amount+"_LogDispersion")

    # def trans_amount_lag_plot(data, trans_date, transaction_amount):
    #     data[trans_date] = pd.to_datetime(data[trans_date])
    #     tot_trans = data.groupby(data[trans_date].dt.strftime('%Y'))[transaction_amount].sum()
    #     ts_log = np.log(tot_trans)
    #     # plt.plot(ts_log)
    #     # ts_log.plot(figsize=(10,5), linewidth=2, fontsize=10,grid = True,style = "k-")
    #     # lag_plot(tot_trans)
    #     # pyplot.show()
    #     plt.savefig(os.path.normpath(
    #         os.path.join(os.path.dirname(__file__),
    #                      '../../../output/graphs/')) + '/' + "Transaction_Date_tranAmount_LagPlot")

    if meta_config_list:
        for i in range(len(meta_config_list)):
            if meta_config_list[i].get('graph_parameters', None) is not None:
                # for j in range(len(eval(meta_config_list[i].get('graph_parameters', None)))):
                #     l = len(eval(meta_config_list[i].get('graph_parameters', None))[j])
                #     if l == 2:
                df = data.copy()
                for dict in eval(meta_config_list[i].get('graph_parameters', None)):
                    if dict.get('graph_type', None) == 'Bar_Graph':
                        trans_products_dispersion(df, meta_config_list[i].get('column_name', None),
                                                  dict.get('y_axis', None))

                    # elif dict.get('graph_type', None) == 'Hist_Graph':
                    #     trans_amount_dispersion_hist(df, meta_config_list[i].get('column_name', None),
                    #                                  dict.get('y_axis', None))

                    elif dict.get('graph_type', None) == 'Time_Series_Graph':

                        trans_dispersion(df, meta_config_list[i].get('column_name', None),
                                         dict.get('y_axis', None))
                    elif dict.get('graph_type', None) == 'Grouped_Time_Series_Graph':
                        trans_groupby(df, meta_config_list[i].get('column_name', None),
                                      dict.get('y_axis', None), dict.get('grpby_param', None))
                    # elif dict.get('graph_type', None) == 'LogDispersion':
                    #
                    #     trans_amount_log_dispersion(data, meta_config_list[i].get('column_name', None),
                    #                      dict.get('y_axis', None))

    # trans_dispersion(data, meta_config_list.value_date_time, meta_config_list.transaction_id) #trans_date='value_date_time', trans_id='transaction_id')
    #
    # trans_products_dispersion(data, trans_id='transaction_id', product_name='product_name')
    #
    # trans_amount_dispersion(data, trans_date='value_date_time', tran_amt='transaction_amount')
    #
    # trans_amount_dispersion_hist(data, trans_date = 'value_date_time', tran_amt='transaction_amount')
    #
    # trans_amount_log_dispersion(data, trans_date = 'value_date_time', transaction_amount='transaction_amount')
    #
    # trans_amount_lag_plot(data, trans_date = 'value_date_time', transaction_amount = 'transaction_amount')


def call_counter_party(dataframe, table_name, inputdburl, conditions_table, filedList):
    filter = {
        'table_name': [table_name]
    }
    oneToManyCondDf = fetch_table(conditions_table, inputdburl, wsprefix=None, filter=filter)

    oneToManyCondDf = oneToManyCondDf[oneToManyCondDf.counter_party_column_name.notnull()]
    # for loop the dataframe
    for index_label, row_series in oneToManyCondDf.iterrows():
        dataframe = process_each_row_for_counter_party(row_series, dataframe, filedList)
    return dataframe


def process_each_row_for_counter_party(row_series, df, filedList):
    try:
        conditions = row_series.get("conditions")
        list_of_probable_values = row_series.get("list_of_probable_values", None)
        counter_party_column_name = row_series.get("counter_party_column_name", None)
        column_name = row_series.get("column_name", None)

        dependent_column = row_series.get("input_column_names").split(',')
        processed_df = None
        for vals in dependent_column:
            arrt = 'getattr(df, "{}")'.format(vals)
            # print(arrt)
            word1 = "'getattr(df, \"{}\")'".format(vals)
            word2 = "getattr(df, \"{}\")".format(vals)
            conditions = conditions.replace(vals, arrt).replace(word1,
                                                                word2).replace('[', '').replace(']', '')
        filtered_df = df[eval(conditions)]

        if len(filtered_df.index) > 0:
            filtered_df = add_counter_party(filtered_df, list_of_probable_values, counter_party_column_name,
                                            column_name,
                                            filedList)
            remainingdf = df[~eval(conditions)]
            return pd.concat([remainingdf, filtered_df], ignore_index=True, axis=0, sort=False)
        else:
            return df

    except Exception as e:
        logging.error(e)
        return df


######################

def add_step_and_duration(dataframe, table_id, inputdburl, table_name):
    filter = {
        'table_id': [table_id]
    }
    oneToManyCondDf = fetch_table(table_name, inputdburl, wsprefix=None, filter=filter)
    oneToManyCondDf = oneToManyCondDf[
        oneToManyCondDf.frequency_in_duration.notnull() & oneToManyCondDf.duration.notnull()]
    # for loop the dataframe
    for index_label, row_series in oneToManyCondDf.iterrows():
        dataframe = process_step_duration(row_series, dataframe)
    return dataframe, list(dataframe.columns)
