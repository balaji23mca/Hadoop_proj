import copy
import multiprocessing as mp

import components.core_components.logging
import components.core_components.logging
from components.orchestrations.activityExecutor_helper import *;
from components.orchestrations.dimension.activityConditionsExecutor import *;

"""
   Comment : One to Many type table creation
"""


def execute(row, parameter, meta_config_list, flag):
    ########## : setting parameter and creating variables
    if_exists = 'append'
    table_name = row.get('table_name', None)
    logging.info('running executor to create {} table'.format(table_name))
    table_parameters = row.get('table_parameters', None)
    if table_parameters:
        duration = table_parameters.get('duration', None)
    commit_size = row.get('commit_size', None)
    if commit_size:
        commit_size = int(commit_size)

    if parameter.poolsize == 'auto':
        pool_value = mp.cpu_count() - 2
    else:
        pool_value = int(parameter.poolsize)

    ########## : creating df from using particulars
    logging.info('Submitting to create df using referenced columns from dependent tables')
    start_time1 = time.time()
    container, _, dataframe = get_particulars(row, parameter, meta_config_list)
    logging.info('time spent in creating dataframe from dependent tables  : %.3f seconds' % (time.time() - start_time1))
    particulars_size = len(dataframe)
    logging.info('starting executor to create {} table - using dependency table of  size {}'.format(table_name, int(
        particulars_size)))

    ########## : splitting df
    particulars_df_split = split(dataframe, commit_size)
    total_chunk_count = len(particulars_df_split)
    logging.debug('total chunks count is : {}'.format(total_chunk_count))

    ########## fetching helper lists
    meta_config_activity_list = _get_meta_config_activity_list(meta_config_list)
    otherGenerators_list = _get_otherGenerators_list(meta_config_activity_list)

    #############
    avg_time = None
    if flag:
        flag2 = True
    else:
        flag2 = False

    ############# reading cache
    try:
        gen_instance_df_from_store = batchCacheRead(table_name)
    except Exception as e:
        logging.error('Exception occurred :{} '.format(e))

    oneToManyCondDf = fetch_table(parameter.formation_conditions, parameter.inputdburl, wsprefix=None,
                                  filter={'table_name': [table_name]})

    #####

    is_counterparty = _is_counterparty(table_name, oneToManyCondDf)

    ####
    ############# processing splitted df
    for splitted_dataframe_idx, splitted_dataframe in enumerate(particulars_df_split):

        if len(splitted_dataframe) > 0:
            start_time_commit = time.time()
            logging.info('{} out of {} parts are remaining, to complete for {} table'.format(
                total_chunk_count - splitted_dataframe_idx, total_chunk_count, table_name))
            splitted_dataframe = splitted_dataframe.reset_index(drop=True)

            ######
            gen_instance_list = []
            size_length = int(len(splitted_dataframe))  # this will be used for chunks
            logging.info('Selecting {} rows from dependent table for processing'.format(size_length))

            ## perform one to many on the particualrs
            # dataframe = one_to_many(meta_config_list, duration, parameter.inputdburl,
            # parameter.formation_conditions, oneToManyCondDf, splitted_dataframe)
            ########## multiprocessing

            func = partial(one_to_many, meta_config_list, duration, parameter.inputdburl,
                                    parameter.formation_conditions,oneToManyCondDf)
            start_time1 = time.time()
            pool = Pool(pool_value)
            logging.info('one_to_many - time spent in creating pool obj  : %.3f seconds' % (time.time() - start_time1))

            start_time1 = time.time()
            df_split_for_pool = np.array_split(splitted_dataframe, pool_value)
            logging.info('one_to_many - time spent in pre-processing  : %.3f seconds' % (time.time() - start_time1))

            if avg_time:
                logging.info('one_to_many - submitting to multiprocessing pool, average wait time is {}'.format(avg_time))
            else:
                logging.info('one_to_many - submitting to multiprocessing pool....')

            start_time1 = time.time()
            list_of_dataframes = pool.map(func, df_split_for_pool)
            pool.close()
            pool.join()
            avg_time = '%.3f seconds' % (time.time() - start_time1)
            logging.info('one_to_many - time spent inside pool - : {}'.format(avg_time))

            start_time1 = time.time()
            dataframe = pd.concat(list_of_dataframes)
            logging.info('one_to_many - time spent post processing after pool : %.3f seconds' % (time.time() - start_time1))

            ########### multiprocessing
            filedList = list(dataframe.columns)
            logging.info(
                'one_to_many - feature created {} rows from input of {} rows'.format(len(dataframe), size_length))
            if gen_instance_df_from_store is None:

                ############# creating new instance
                try:
                    for gen_param in meta_config_activity_list:  #### creating instance for all
                        logging.debug('initializeGenerators with param : {}'.format(gen_param))
                        gen_instance = generator_factory.getInstance(gen_param,
                                                                     initiating_population=container.populations[
                                                                         table_name])
                        gen_instance_list.append(gen_instance)
                except Exception as e:
                    logging.error('Exception occurred :{} '.format(e))
                #############
            else:

                ############# using pickled instance and setting to list
                try:
                    for index, gen_instance in gen_instance_df_from_store.iterrows():
                        gen_instance_list.append(gen_instance['gen_instance'])
                except Exception as e:
                    logging.error('Exception occurred :{} '.format(e))

                ############# creating new instance of other generators and setting it to list
                try:
                    for gen_param in otherGenerators_list:
                        logging.debug('initializeGenerators with param : {}'.format(gen_param))
                        gen_instance = generator_factory.getInstance(gen_param,
                                                                     initiating_population=container.populations[
                                                                         table_name])
                        gen_instance_list.append(gen_instance)
                except Exception as e:
                    logging.error('Exception occurred :{} '.format(e))

            ############# : creating list of columns, this is used in output
            try:
                for gen_instance in gen_instance_list:
                    filedList.append(gen_instance.name)
            except Exception as e:
                logging.error('Exception occurred :{} '.format(e))

            ############# : adding unique values to the df like id
            try:
                logging.info('submitting to generate non ref columns')
                start_time1 = time.time()
                container, dataframe, filedList = add_activity(row, parameter, meta_config_list, dataframe, filedList,
                                                               gen_instance_list)
                logging.info('time spent in non ref generators: %.3f seconds' % (time.time() - start_time1))
                if is_counterparty:
                    start_time1 = time.time()
                    dataframe = call_counter_party(dataframe, table_name, parameter.inputdburl,
                                                   parameter.formation_conditions, filedList)
                    logging.info('time spent in counter party: %.3f seconds' % (time.time() - start_time1))
            except Exception as e:
                logging.error(e)
                saveDataframe(container, dataframe, parameter.wsprefix, parameter.joblogdburl, if_exists);

            if dataframe is not None:
                dataframe = dataframe.reset_index(drop=True)

                ############# : calling running balance if present
                if _is_running_balance_parameters_list(meta_config_list):
                    logging.debug('dataframe before running balance is of size {}'.format(len(dataframe)))
                    for i in range(len(meta_config_list)):
                        if meta_config_list[i].get('running_balance_parameters', None):
                            meta_param = meta_config_list[i].get('running_balance_parameters')
                            param = eval(meta_param)
                            groupby_column = param.get('group_by_column', None)

                            ### grouping df on group_by_column
                            running_bal_list_df = []
                            running_bal_grouped_df_list = dataframe.groupby(groupby_column)
                            strsize = len(running_bal_grouped_df_list) / pool_value
                            start_time1 = time.time()
                            running_bal_grouped_df_dict = {}

                            ### splitting df for multi processing
                            for n, g in running_bal_grouped_df_list:
                                running_bal_grouped_df_dict[n] = g
                                if len(running_bal_grouped_df_dict) >= strsize:
                                    running_bal_list_df.append(copy.deepcopy(running_bal_grouped_df_dict))
                                    running_bal_grouped_df_dict.clear()

                            ###
                            if len(running_bal_grouped_df_dict) > 0:
                                running_bal_list_df.append(copy.deepcopy(running_bal_grouped_df_dict))
                                running_bal_grouped_df_dict.clear()
                            logging.info('time spent pre-processing - : %.3f seconds' % (time.time() - start_time1))
                            chunk_for_save, time_spent = calculate_running_balance(running_bal_list_df, meta_param,
                                                                                   avg_time, pool_value)
                            avg_time = time_spent

                            logging.info('saving dataframe of size {}'.format(len(chunk_for_save)))

                            ### splitting df completed

                            ### creating graph
                            if _is_graph_parameters_in_list(meta_config_list) and flag2:
                                transactionGraph(chunk_for_save, meta_config_list)
                                flag2 = False

                            ############# : saving df to both the dbs
                            logging.info('saving df of size :{} '.format(len(chunk_for_save)))
                            saveDataframe(container, chunk_for_save, parameter.wsprefix, parameter.joblogdburl,
                                          if_exists);
                            saveDataframe(container, chunk_for_save, parameter.wsprefix, parameter.outputdburl,
                                          if_exists);

                ############# : if runningbalance not present, saving df
                else:
                    if _is_graph_parameters_in_list(meta_config_list) and flag2:
                        transactionGraph(dataframe, meta_config_list)
                        flag2 = False

                    logging.info('saving df of size :{} '.format(len(dataframe)))
                    saveDataframe(container, dataframe, parameter.wsprefix, parameter.joblogdburl, if_exists);

            ############# : persisting seqences
            gen_instance_list_itr = []
            for generator_instance in gen_instance_list:
                if isinstance(generator_instance,
                              components.core_components.generators.sequencialGenerator.SequencialGenerator):
                    gen_instance_list_itr.append(generator_instance)

            gen_instance_df_from_store = pd.DataFrame(gen_instance_list_itr, columns=['gen_instance'])
            batchCacheclean(table_name)
            batchCacheWrite(table_name, gen_instance_df_from_store)
    ##########


def split(dfm, chunk_size):
    indices = index_marks(dfm.shape[0], chunk_size)
    return np.split(dfm, indices)


def _get_otherGenerators_list(meta_config_list):
    otherGenerators_list = [d for d in meta_config_list if
                            d.get('generator_name', "N") != "SequencialGenerator"
                            ]
    if otherGenerators_list:
        return otherGenerators_list
    else:
        return []


def _get_SequencialGenerator_list(meta_config_list):
    sequencialGenerator_list = [d for d in meta_config_list if
                                d.get('generator_name', "N") == "SequencialGenerator"
                                ]
    if sequencialGenerator_list:
        return sequencialGenerator_list
    else:
        return []


def _get_meta_config_activity_list(meta_config_list):
    meta_config_particular_list = [d for d in meta_config_list if
                                   d.get('is_reference_column', "N") != "Y"
                                   ]
    if meta_config_particular_list:
        return meta_config_particular_list
    else:
        return []


def index_marks(nrows, chunk_size):
    return range(1 * chunk_size, (nrows // chunk_size + 1) * chunk_size, chunk_size)


def split_df(dfm, chunk_size):
    indices = index_marks(dfm.shape[0], chunk_size)
    return np.split(dfm, indices)


def _is_counterparty(table_name, oneToManyCondDf):
    if len(oneToManyCondDf[(oneToManyCondDf[
                                'table_name'] == table_name) & oneToManyCondDf.counter_party_column_name.notnull()]) > 0:
        return True
    else:
        return False


def _is_running_balance_parameters_list(meta_config_list):
    running_balance_parameters_list = [d for d in meta_config_list if
                                       d.get('running_balance_parameters', None)]
    if running_balance_parameters_list:
        return True
    else:
        return False


def _is_graph_parameters_in_list(meta_config_list):
    meta_config_particular_list = [d for d in meta_config_list if
                                   d.get('graph_parameters', None)]
    if meta_config_particular_list:
        return True
    else:
        return False


if __name__ == '__main__':
    import os
    import pandas as pd

    components.core_components.logging.setup_logging()
    parameter = readParameter()
    str_row = {
        'table_id': 5,
        'table_name': 'transaction',
        'tabledescription': 'Transaction table',
        'dependency_level': 1,
        'related_tables': {"table": "account"},
        'lastupddate': '03/25/2019',
        'type': {"relationship_type": "ONE_TO_MANY"},
        'table_parameters': {"master_seed": 1234},
        'status': 'y'
    }

    # str_row = {
    #     'table_id': 4,
    #     'table_name': 'account',
    #     'table_description': 'Account table',
    #     'dependency_level': 1,
    #     'related_tables': {"table": "person"},
    #     'last_upddate': '03/25/2019',
    #     'type': {"relationship_type": "ONE_TO_MANY"},
    #     'table_parameters': {
    #         "master_seed": 1234
    #     },
    #     'status': 'y'
    # }

    row = pd.Series(str_row)

    columnprpty = readConfigTable(table_name=parameter.columnprpty, wsprefix=parameter.wsprefix,
                                  dburl=parameter.inputdburl, filter={'table_id': [row.get('table_id', None)]})
    meta_config_list = transformConfig(columnprpty)
    validation_result = validateGeneratorParam(column_prptys_meta_json_list=meta_config_list)

    # if validation_result and all(validation_result):
    execute(row, parameter, meta_config_list);
