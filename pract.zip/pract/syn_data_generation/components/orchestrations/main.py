import components.core_components.logging
from components.core_components.splitting_jobs.jobs_utils import *
from components.core_components.utils.database.db_helper import *
from components.core_components.utils.helper import *

"""
   Comment : Main methods, it will call different creators based on config.
"""

fresh_run = 'fresh_run'
re_run = 're_run'
selected_table = 'selected_table'
completed = 'completed'


def execute_new():
    start_time = time.time()
    parameter = readParameter()
    cacheClean(parameter.wsprefix)
    logging.info('----------- DATA GENERATION STARTS with parameters - {}'.format(parameter))
    inputdbStstus = checkDbConnections(parameter.inputdburl, connectionType="Input DB")
    outputdbStstus = checkDbConnections(parameter.outputdburl, connectionType="Output DB")

    if inputdbStstus == rest_app_settings.CONNECTION_SUCCESSFUL and outputdbStstus == rest_app_settings.CONNECTION_SUCCESSFUL:
        ####
        tableprpty = readConfigTable(table_name=parameter.tableprpty, wsprefix=parameter.wsprefix,
                                     dburl=parameter.inputdburl,
                                     filter={rest_app_settings.ACTIVE_STATUS: ["Y"]})
        columnprpty = readConfigTable(table_name=parameter.columnprpty, wsprefix=parameter.wsprefix,
                                      dburl=parameter.inputdburl)
        job_table = readConfigTable(table_name=parameter.jobtable, wsprefix=parameter.wsprefix,
                                    dburl=parameter.inputdburl)
        ####
        generation_condition = get_generation_condition(job_table)
        ####
        if generation_condition == fresh_run:
            start_fresh_run(tableprpty=tableprpty, columnprpty=columnprpty, job_table=job_table, parameter=parameter)
        elif generation_condition == re_run:
            start_re_run(tableprpty=tableprpty, columnprpty=columnprpty, job_table=job_table, parameter=parameter)
        elif generation_condition == completed:
            logging.info('all jobs are in completed state')
        ####
    else:
        logging.info('DB unavailable')
    logging.info(
        '-----------TOTAL EXECUTION TIME IS - : %.3f seconds' % (time.time() - start_time))


def _get_zero_relationships(tableprpty):
    return tableprpty[tableprpty['relationships'].isnull()]


def _get_relationships(tableprpty):
    return tableprpty[tableprpty['relationships'].notnull()]


def start_re_run(tableprpty, columnprpty, job_table, parameter):
    not_started_list = get_not_started_list(job_table)
    static_tables_list = fetch_static_tables(tableprpty)
    table_names = np.unique(tableprpty['table_name'])
    table_names_fltr = [item for item in table_names if item not in static_tables_list]
    job_table = job_table[job_table['status'] != 'completed']
    job_log_df = readConfigTable(table_name='jobs_log', wsprefix=parameter.wsprefix,
                                 dburl=parameter.joblogdburl)

    if not_started_list:

        if job_log_df is not None and len(job_log_df) > 1:
            n = int(job_log_df['id'].max())
            n += 1
            for job_id in not_started_list:
                job_log_df = job_log_df[job_log_df.job_id != job_id]
                for table_name in table_names_fltr:
                    job_log_df = job_log_df.append(
                        {'id': n, 'job_id': int(job_id), 'table_name': table_name, 'record_count': None,
                         'status': 'not_started',
                         'message': None}, ignore_index=True)
                    n += 1


        else:
            job_log_df = pd.DataFrame(columns=["id", "job_id", "table_name", "record_count","status", "message"])
            n = 1
            for job_id in not_started_list:
                job_log_df = job_log_df[job_log_df.job_id != job_id]
                for table_name in table_names:
                    job_log_df = job_log_df.append(
                        {'id': n, 'job_id': int(job_id), 'table_name': table_name, 'record_count': None,
                         'status': 'not_started',
                         'message': None}, ignore_index=True)
                    n += 1
            drop_tables_if_exists(tableprpty, parameter.joblogdburl)
            create_all_output_tables(tableprpty, columnprpty, parameter.joblogdburl)

        save_job_log_df(job_log_df)

    if len(job_log_df) > 0:
        job_log_df = job_log_df[job_log_df['status'] != 'completed'] # and id in job_table
        if len(job_log_df) > 0:

            paramprpty = readDependentGeneratorConditions(columnprpty, parameter.dependentgenparam,
                                                          parameter.inputdburl)
            column_prptys_meta_json_list = transformConfig(paramprpty)
            validation_result = validateGeneratorParam(column_prptys_meta_json_list=column_prptys_meta_json_list)

            rerun_job_log_table(job_table, job_log_df, tableprpty, column_prptys_meta_json_list, parameter)


def start_fresh_run(tableprpty, columnprpty, job_table, parameter):
    drop_tables_if_exists(tableprpty, parameter.outputdburl)
    drop_tables_if_exists(tableprpty, parameter.joblogdburl)

    create_all_output_tables(tableprpty, columnprpty, parameter.outputdburl)
    create_all_output_tables(tableprpty, columnprpty, parameter.joblogdburl)

    table_names = np.unique(tableprpty['table_name'])
    static_tables_list = fetch_static_tables(tableprpty)

    table_names_fltr = [item for item in table_names if item not in static_tables_list]

    paramprpty = readDependentGeneratorConditions(columnprpty, parameter.dependentgenparam, parameter.inputdburl)

    column_prptys_meta_json_list = transformConfig(paramprpty)

    validation_result = validateGeneratorParam(column_prptys_meta_json_list=column_prptys_meta_json_list)

    for tables_to_clean in table_names_fltr:
        batchCacheclean(tables_to_clean)

    for index, row in job_table.iterrows():
        if index == 0:
            job_id = int(row.get('job_id', None))
            if job_id:
                create_job_log_table(job_id=job_id, table_names=table_names, table_name=None)
        else:

            job_id = int(row.get('job_id', None))
            if job_id:
                create_job_log_table(job_id=job_id, table_names=table_names_fltr, table_name=None)
    save_job_log_table()

    run_job_log_table(job_table, tableprpty, column_prptys_meta_json_list, parameter)

    # if table_names == 'person':
    #     persona_executor(row, parameter, filtered_list,table_size) get_rerun_reason


def get_not_started_list(job_table):
    job_table = job_table[job_table['status'] == 'not_started']

    if len(job_table) > 0:
        return job_table.get('job_id', None).tolist()
    else:
        return []


def get_generation_condition(job_table):
    status = 'not_started'
    table_name = job_table.get('table_name', None)

    statuscol = job_table.get('status', None)

    if statuscol is not None:
        statusList = statuscol.tolist()

        if all(x == 'not_started' for x in statusList):
            status = 'fresh_run'

        elif all(x == 'completed' for x in statusList):
            status = 'completed'

        else:
            status = 're_run'
    return status


def get_meta_config_particular_list(meta_config_list):
    meta_config_particular_list = [d for d in meta_config_list if
                                   d.get('table_parameters', None) and d.get('table_parameters').get('type', None)
                                   and d.get('table_parameters').get('type') == "PARTICULARS"]
    if meta_config_particular_list:
        return meta_config_particular_list
    else:
        return []


if __name__ == '__main__':
    components.core_components.logging.setup_logging()
    execute_new()
