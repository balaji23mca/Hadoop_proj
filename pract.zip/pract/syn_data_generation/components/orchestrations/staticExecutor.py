import os.path
import time
import components.core_components.logging
import components.core_components.logging
from components.core_components.utils.helper import *;
from components.core_components.utils.database.db_helper import run_script_file

"""
   Comment : 
"""


def execute(row, parameter, filtered_list):
    start_time = time.time()
    table_name = row.get('table_name', None)
    logging.info('running executor to create {} table'.format(table_name))

    table_parameters = row.get('table_parameters', None)
    if table_parameters:
        sql_file_path_type = table_parameters.get('sql_file_path_type', None)
        if sql_file_path_type and sql_file_path_type == 'RELATIVE':
            sql_file_path = table_parameters.get('sql_file_path', None)
            if sql_file_path:
                sql_file_path = os.path.normpath(os.path.join(os.path.dirname(__file__), '../../input/sql_scripts/{}'.format(sql_file_path)))

        run_script_file(sql_file_path,parameter.joblogdburl)

        run_script_file(sql_file_path, parameter.outputdburl)

    logging.info('{} creation completed in : %.3f seconds'.format(table_name) % (time.time() - start_time))


if __name__ == '__main__':
    import os
    import pandas as pd

    components.core_components.logging.setup_logging()
    parameter = readParameter()
    str_row = {
        'table_id': 3,
        'table_name': 'Product',
        'tabledescription': 'Account',
        'dependency_level': 1,
        'related_tables': '{"size": 100, "table": "Persona"}',
        'lastupddate': '03/25/2019',
        'countofrecords': 100,
        'type': 'STATIC',
        'table_parameters': {
            'master_seed': 1234,
            'sql_file_path' : 'product_static_data.sql',
            'sql_file_path_type': 'RELATIVE'
        },
        'status': 'y'
    }
    row = pd.Series(str_row)
    execute(row, parameter, filtered_list = None)