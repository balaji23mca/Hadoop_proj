import random
import string

import components.core_components.logging
from components.core_components.generators.utils.generator_helper import *
from components.core_components.utils.database.db_helper import *
from components.core_components.utils.helper import *
from components.orchestrations import personaExecutor, particularsExecutor, activityExecutor, staticExecutor

job_log_df = pd.DataFrame(columns=["id", "job_id", "table_name", "record_count", "start_time", "end_time", "status", "message"])
parameter = readParameter()
table_list = []
n = 1


def create_job_log_table(job_id,table_names, table_name=None):
    global job_log_df, n

    for table_name in table_names:
        job_log_df = job_log_df.append(
            {'id': n, 'job_id': int(job_id), 'table_name': table_name, 'record_count': None, 'status': 'not_started',
             'message': None}, ignore_index=True)
        n += 1


def save_job_log_df(job_log_df):
    to_sql_key(job_log_df, parameter.joblogdburl, tablename="jobs_log", id_column='id', if_exists='replace', index=False)
    # logging.info('created {} items in  jobs_log'.format(len(job_log_df)))

def save_job_log_table():
    global job_log_df, parameter
    to_sql_key(job_log_df, parameter.joblogdburl, tablename="jobs_log", id_column='id', if_exists='replace', index=False)
    logging.info('created {} items in  jobs_log'.format(len(job_log_df)))


def fetch_static_tables(tableprpty):
    static_tables_list = []
    tableprpty = tableprpty[tableprpty['relationships'].isnull()]
    for index, row in tableprpty.iterrows():
        table_parameters = row.get('table_parameters', None)
        if table_parameters and table_parameters.get('sql_file_path', None):
            static_tables_list.append(row.get('table_name', None))

    return static_tables_list


def run_job_log_table(job_table , tableprpty, column_prptys_meta_json_list, parameter):
    import warnings, pandas
    warnings.filterwarnings('ignore', category=pandas.io.pytables.PerformanceWarning)
    global job_log_df

    tables_with_zero_relationships_list = _get_zero_relationships(tableprpty)
    tables_with_relationships_list = _get_relationships(tableprpty)

    relationships_without_running_bal_list = _get_relationships_without_running(tableprpty,column_prptys_meta_json_list)


    static_tables_list = _get_static_tables(tableprpty)
    persona_tables_list = _get_persona_tables(tableprpty)


    tableprpty = tableprpty.sort_values(['dependency_level'])

    sorter = tableprpty.get('table_name', None).tolist()

    job_log_df = job_log_df.sort_values(['job_id'])

    job_log_df_grouped = job_log_df.groupby('job_id')

    flag = True

    for name, group in job_log_df_grouped:

        cacheClean(parameter.wsprefix)

        table_size = job_table[job_table['job_id'] == int(name)].iloc[0].get('recordNumber')
        ## sorting
        sorterIndex = dict(zip(sorter, range(len(sorter))))
        rank_list = group['table_name'].map(sorterIndex).tolist()
        group= group.assign(table_name_rank = rank_list)
        group.sort_values(['table_name_rank'],ascending=[ True], inplace=True)
        group.drop('table_name_rank', 1, inplace=True)
        ##
        update_row(dburl=parameter.inputdburl, table_name='job', update_col='start_time', update_val=time.strftime('%Y-%m-%d %H:%M:%S'), index_clm='job_id', index_val=name)
        update_row(dburl=parameter.inputdburl, table_name='job', update_col='status', update_val='in_progress', index_clm='job_id', index_val=name)
        msg_flag = 0
        for index, row in group.iterrows():
            table_name = row.get('table_name', None)
            if table_name:
                update_row(dburl=parameter.joblogdburl, table_name='jobs_log', update_col='status', update_val='in_progress', index_clm='id', index_val=row['id'])
                update_row(dburl=parameter.joblogdburl, table_name='jobs_log', update_col='start_time', update_val=time.strftime('%Y-%m-%d %H:%M:%S'), index_clm='id', index_val=row['id'])
                table_prpty_row = tableprpty[tableprpty['table_name'] == table_name]

                filtered_list = [d for d in column_prptys_meta_json_list if
                                 d['table_id'] == table_prpty_row.get('table_id', None).iloc[0]]

                if table_name in persona_tables_list:
                    truncate_table(table_name, parameter.joblogdburl, wsprefix=None)
                    persona_executor(table_prpty_row.iloc[0], parameter, filtered_list,table_size, flag)

                    ispersonaTableExists = False
                    time_to_wait = 10  # will wait upto 10 seconds
                    time_counter = 0
                    while not ispersonaTableExists:
                        time_counter += 1
                        time.sleep(1)
                        ispersonaTableExists = _isTableExists(table_name, parameter.wsprefix, parameter.joblogdburl)
                        if time_counter > time_to_wait: break
                    if ispersonaTableExists:
                        temp_table_df = read_table(table_name, parameter.joblogdburl, wsprefix=None, filter=None)
                        if temp_table_df is not None:
                            save_to_db(parameter.wsprefix, temp_table_df, table_name, parameter.outputdburl,
                                       use_async=False,
                                       if_exists="append")
                    else:
                        logging.error('table {} not moved to output database '.format(table_name))



                if table_name in static_tables_list:
                    static_executor(table_prpty_row.iloc[0], parameter, filtered_list)

                elif table_name in tables_with_relationships_list:
                    truncate_table(table_name, parameter.joblogdburl, wsprefix=None)
                    call_type_based_executor_with_rel(table_prpty_row.iloc[0], parameter, filtered_list,table_size, flag)
                    if table_name in relationships_without_running_bal_list:
                        isrelTableExists = False
                        time_to_wait = 10  # will wait upto 10 seconds
                        time_counter = 0
                        while not isrelTableExists:
                            time_counter += 1
                            time.sleep(1)
                            isrelTableExists = _isTableExists(table_name, parameter.wsprefix, parameter.joblogdburl)
                            if time_counter > time_to_wait: break
                        if isrelTableExists:
                            temp_table_df = read_table(table_name, parameter.joblogdburl, wsprefix=None, filter=None)
                            if temp_table_df is not None:
                                save_to_db(parameter.wsprefix, temp_table_df, table_name, parameter.outputdburl,
                                           use_async=False,
                                           if_exists="append")
                        else:
                            logging.error('table {} not moved to output database '.format(table_name))

                rec_count = get_row_count(parameter.joblogdburl, table_name)
                update_row(dburl=parameter.joblogdburl, table_name='jobs_log', update_col='record_count', update_val=rec_count, index_clm='id', index_val=row['id'])
                update_row(dburl=parameter.joblogdburl, table_name='jobs_log', update_col='end_time', update_val=time.strftime('%Y-%m-%d %H:%M:%S'), index_clm='id', index_val=row['id'])
                status = get_execution_flag()
                update_row(dburl=parameter.joblogdburl, table_name='jobs_log', update_col='status', update_val=status[0], index_clm='id', index_val=row['id'])
                update_row(dburl=parameter.joblogdburl, table_name='jobs_log', update_col='message', update_val=status[1], index_clm='id', index_val=row['id'])
                if status[0] == 'failed':
                    try:
                        update_row(dburl=parameter.inputdburl, table_name='job', update_col='end_time', update_val=time.strftime('%Y-%m-%d %H:%M:%S'), index_clm='job_id', index_val=name)
                        update_row(dburl=parameter.inputdburl, table_name='job', update_col='status', update_val='failed', index_clm='job_id', index_val=name)
                        update_row(dburl=parameter.inputdburl, table_name='job', update_col='message', update_val=status[1], index_clm='job_id', index_val=name)
                        msg_flag = 1
                        exit(0)
                    except Exception as e:
                        logging.debug("error in updating status: {}".format(e))
                        exit(0)
                else:
                    set_execution_flag()

            flag = False
        try:
            if msg_flag == 0:
                update_row(dburl=parameter.inputdburl, table_name='job', update_col='end_time', update_val=time.strftime('%Y-%m-%d %H:%M:%S'), index_clm='job_id', index_val=name)
                update_row(dburl=parameter.inputdburl, table_name='job', update_col='status', update_val='completed', index_clm='job_id', index_val=name)
                update_row(dburl=parameter.inputdburl, table_name='job', update_col='message', update_val='completed', index_clm='job_id', index_val=name)
        except Exception as e:
            logging.debug("error in updating status: {}".format(e))


def rerun_job_log_table(job_table ,job_log_df, tableprpty, column_prptys_meta_json_list, parameter):
    import warnings, pandas
    warnings.filterwarnings('ignore', category=pandas.io.pytables.PerformanceWarning)

    tables_with_zero_relationships_list = _get_zero_relationships(tableprpty)
    tables_with_relationships_list = _get_relationships(tableprpty)

    relationships_without_running_bal_list = _get_relationships_without_running(tableprpty,column_prptys_meta_json_list)


    static_tables_list = _get_static_tables(tableprpty)
    persona_tables_list = _get_persona_tables(tableprpty)


    tableprpty = tableprpty.sort_values(['dependency_level'])

    sorter = tableprpty.get('table_name', None).tolist()

    job_log_df = job_log_df.sort_values(['job_id'])

    job_log_df_grouped = job_log_df.groupby('job_id')

    flag = True

    for name, group in job_log_df_grouped:

        cacheClean(parameter.wsprefix)

        table_size = job_table[job_table['job_id'] == int(name)].iloc[0].get('recordNumber')

        ## sorting
        sorterIndex = dict(zip(sorter, range(len(sorter))))
        rank_list = group['table_name'].map(sorterIndex).tolist()
        group= group.assign(table_name_rank = rank_list)
        group.sort_values(['table_name_rank'],ascending=[ True], inplace=True)
        group.drop('table_name_rank', 1, inplace=True)
        ##
        update_row(dburl=parameter.inputdburl, table_name='job', update_col='start_time', update_val=time.strftime('%Y-%m-%d %H:%M:%S'), index_clm='job_id', index_val=name)
        update_row(dburl=parameter.inputdburl, table_name='job', update_col='status', update_val='in_progress', index_clm='job_id', index_val=name)
        msg_flag = 0
        for index, row in group.iterrows():
            table_name = row.get('table_name', None)
            if table_name:
                update_row(dburl=parameter.joblogdburl, table_name='jobs_log', update_col='status', update_val='in_progress', index_clm='id', index_val=row['id'])
                update_row(dburl=parameter.joblogdburl, table_name='jobs_log', update_col='start_time', update_val=time.strftime('%Y-%m-%d %H:%M:%S'), index_clm='id', index_val=row['id'])
                table_prpty_row = tableprpty[tableprpty['table_name'] == table_name]

                filtered_list = [d for d in column_prptys_meta_json_list if
                                 d['table_id'] == table_prpty_row.get('table_id', None).iloc[0]]

                if table_name in persona_tables_list: # persona
                    truncate_table(table_name, parameter.joblogdburl, wsprefix=None)
                    persona_executor(table_prpty_row.iloc[0], parameter, filtered_list,table_size, flag)

                    ispersonaTableExists = False
                    time_to_wait = 10  # will wait upto 10 seconds
                    time_counter = 0
                    while not ispersonaTableExists:
                        time_counter += 1
                        time.sleep(1)
                        ispersonaTableExists = _isTableExists(table_name, parameter.wsprefix, parameter.joblogdburl)
                        if time_counter > time_to_wait: break
                    if ispersonaTableExists:
                        temp_table_df = read_table(table_name, parameter.joblogdburl, wsprefix=None, filter=None)
                        if temp_table_df is not None:
                            save_to_db(parameter.wsprefix, temp_table_df, table_name, parameter.outputdburl,
                                       use_async=False,
                                       if_exists="append")
                    else:
                        logging.error('table {} not moved to output database '.format(table_name))



                if table_name in static_tables_list:
                    static_executor(table_prpty_row.iloc[0], parameter, filtered_list)

                elif table_name in tables_with_relationships_list:
                    truncate_table(table_name, parameter.joblogdburl, wsprefix=None)
                    call_type_based_executor_with_rel(table_prpty_row.iloc[0], parameter, filtered_list,table_size, flag)
                    if table_name in relationships_without_running_bal_list:
                        isrelTableExists = False
                        time_to_wait = 10  # will wait upto 10 seconds
                        time_counter = 0
                        while not isrelTableExists:
                            time_counter += 1
                            time.sleep(1)
                            isrelTableExists = _isTableExists(table_name, parameter.wsprefix, parameter.joblogdburl)
                            if time_counter > time_to_wait: break
                        if isrelTableExists:
                            temp_table_df = read_table(table_name, parameter.joblogdburl, wsprefix=None, filter=None)
                            if temp_table_df is not None:
                                save_to_db(parameter.wsprefix, temp_table_df, table_name, parameter.outputdburl,
                                           use_async=False,
                                           if_exists="append")
                        else:
                            logging.error('table {} not moved to output database '.format(table_name))

                rec_count = get_row_count(parameter.joblogdburl, table_name)
                update_row(dburl=parameter.joblogdburl, table_name='jobs_log', update_col='record_count', update_val=rec_count, index_clm='id', index_val=row['id'])
                update_row(dburl=parameter.joblogdburl, table_name='jobs_log', update_col='end_time', update_val=time.strftime('%Y-%m-%d %H:%M:%S'), index_clm='id', index_val=row['id'])
                status = get_execution_flag()
                update_row(dburl=parameter.joblogdburl, table_name='jobs_log', update_col='status', update_val=status[0], index_clm='id', index_val=row['id'])
                update_row(dburl=parameter.joblogdburl, table_name='jobs_log', update_col='message', update_val=status[1], index_clm='id', index_val=row['id'])
                if status[0] == 'failed':
                    try:
                        update_row(dburl=parameter.inputdburl, table_name='job', update_col='end_time', update_val=time.strftime('%Y-%m-%d %H:%M:%S'), index_clm='job_id', index_val=name)
                        update_row(dburl=parameter.inputdburl, table_name='job', update_col='status', update_val='failed', index_clm='job_id', index_val=name)
                        update_row(dburl=parameter.inputdburl, table_name='job', update_col='message', update_val=status[1], index_clm='job_id', index_val=name)
                        msg_flag = 1
                        exit(0)
                    except Exception as e:
                        logging.debug("error in updating status: {}".format(e))
                        exit(0)
                else:
                    set_execution_flag()

            flag = False
        try:
            if msg_flag == 0:
                update_row(dburl=parameter.inputdburl, table_name='job', update_col='end_time', update_val=time.strftime('%Y-%m-%d %H:%M:%S'), index_clm='job_id', index_val=name)
                update_row(dburl=parameter.inputdburl, table_name='job', update_col='status', update_val='completed', index_clm='job_id', index_val=name)
                update_row(dburl=parameter.inputdburl, table_name='job', update_col='message', update_val='completed', index_clm='job_id', index_val=name)
        except Exception as e:
            logging.debug("error in updating status: {}".format(e))


def _get_zero_relationships(tableprpty):
    tables_with_zero_relationships_list = []
    tableprpty_relationships = tableprpty[tableprpty['relationships'].isnull()]
    if len(tableprpty_relationships) > 0:
        for index, row in tableprpty_relationships.iterrows():
            tables_with_zero_relationships_list.append(row.get('table_name', None))
    return tables_with_zero_relationships_list


def _get_persona_tables(tableprpty):
    persona_tables_list = []
    tableprpty_relationships = tableprpty[tableprpty['relationships'].isnull()]
    if len(tableprpty_relationships) > 0:
        for index, row in tableprpty_relationships.iterrows():

            table_parameters = row.get('table_parameters', None)
            if table_parameters and not table_parameters.get('sql_file_path', None):
                persona_tables_list.append(row.get('table_name', None))

    return persona_tables_list


def _get_static_tables(tableprpty):
    static_tables_list = []
    tableprpty_relationships = tableprpty[tableprpty['relationships'].isnull()]
    if len(tableprpty_relationships) > 0:
        for index, row in tableprpty_relationships.iterrows():

            table_parameters = row.get('table_parameters', None)
            if table_parameters and table_parameters.get('sql_file_path', None):
                static_tables_list.append(row.get('table_name', None))

    return static_tables_list
#_get_relationships_without_running

def _get_relationships_without_running(tableprpty,meta_config_list):
    relationships_without_running_bal_list = []
    tableprpty_relationships = tableprpty[tableprpty['relationships'].notnull()]
    if len(tableprpty_relationships) > 0:
        for index, row in tableprpty_relationships.iterrows():
            if not _is_running_balance_parameters_list(row.get('table_name', None),meta_config_list):
                relationships_without_running_bal_list.append(row.get('table_name', None))
    return relationships_without_running_bal_list

def _get_relationships(tableprpty):
    tables_with_relationships_list = []
    tableprpty_relationships = tableprpty[tableprpty['relationships'].notnull()]
    if len(tableprpty_relationships) > 0:
        for index, row in tableprpty_relationships.iterrows():
            tables_with_relationships_list.append(row.get('table_name', None))
    return tables_with_relationships_list

def _is_running_balance_parameters_list(table_name,meta_config_list):
    filtered_list = [d for d in meta_config_list if d['table_name'] == table_name]

    running_balance_parameters_list = [d for d in filtered_list if
                                       d.get('running_balance_parameters', None)]
    if running_balance_parameters_list:
        return True
    else:
        return False


def get_job(job_id):
    global job_df
    return job_df.loc[job_df["job_id"] == job_id]


def get_job_status(search_text):
    global job_df
    for i, r in job_df.iterrows():
        if r["job_id"] == search_text:
            return r["job status"]
        if r["parameters"][1]["table_name"] == search_text:
            return r["job status"]
    return job_df.loc[job_df["job_id"] == search_text]["job status"].values[0]


def id_generator(size=6, chars=string.ascii_uppercase + string.digits):
    return ''.join(random.choice(chars) for _ in range(size))


def call_type_based_executor_no_rel(row, config_parameter, filtered_list,table_size=None):
    switcher = {
        'PERSONA': persona_executor,
        'STATIC': static_executor,
    }
    try:
        table_parameters = row.get('table_parameters', None)
        if table_parameters and table_parameters.get('sql_file_path', None):
            relationship_type = 'STATIC'
        else:
            relationship_type = 'PERSONA'
        functionObj = switcher.get(relationship_type)
        if functionObj:
            # filtered_list = [d for d in column_prptys_meta_json_list if
            #                  d['table_id'] == row.get('table_id', None)]
            row = persona_executor(row, config_parameter, filtered_list,table_size)
        return "done"
    except Exception as e:
        logging.error(e)
        return "failed"
    return row


def call_type_based_executor_with_rel(row, config_parameter, column_prptys_meta_json_list,flag,table_size=None):
    switcher = {
        'ONE_TO_ONE': particulars_executor,
        'ONE_TO_MANY': activity_executor,
    }
    try:
        if row.get('relationships', None):

            relationships = row.get('relationships')

            dependent_table_list = _get_dependent_table_list(relationships)

            relationship_type = _get_relationship_type(relationships)

            time_to_wait = 10  # will wait upto 10 seconds
            time_counter = 0

            isTableExists = False
            for table in dependent_table_list:
                isTableExists = _isTableExists(table, config_parameter.wsprefix, config_parameter.joblogdburl)
                while not isTableExists:
                    time.sleep(1)
                    time_counter += 1
                    logging.debug('Waiting for dependent table {}.'.format(table))
                    isTableExists = _isTableExists(table, config_parameter.wsprefix, config_parameter.joblogdburl)
                    if time_counter > time_to_wait: break

            if isTableExists:
                functionObj = switcher.get(relationship_type)
                if functionObj:
                    filtered_list = [d for d in column_prptys_meta_json_list if
                                     d['table_id'] == row.get('table_id', None)]
                    row = functionObj(row, config_parameter, filtered_list, flag)
            else:
                logging.debug('SKIPPING TABLE GENERATION WITH PARAM  : \n {}'.format(row))
        return "done"

    except Exception as e:
        logging.error(e)
        return "failed"
    return row


def _isTableExists(table_name, wsprefix, dburl):
    relatedtables_size_1 = getTableSize(table_name=table_name, wsprefix=wsprefix, dburl=dburl)
    time.sleep(2)
    relatedtables_size_2 = getTableSize(table_name=table_name, wsprefix=wsprefix, dburl=dburl)
    if relatedtables_size_1 > 0 and relatedtables_size_2 > 0:
        diff = relatedtables_size_2 - relatedtables_size_1
        if diff == 0:
            return True
        else:
            return False
    else:
        return False


def _get_relationship_type(relationships):
    relationship_type = 'ONE_TO_ONE'
    if isinstance(relationships, dict):
        relationship_type = relationships.get('rel_type', None)
    else:
        for row in relationships:
            if row.get('rel_type', None) and row.get('rel_type') == "ONE_TO_MANY":
                relationship_type = 'ONE_TO_MANY'
    return relationship_type


def _get_dependent_table_list(relationships):
    dependent_table_list = []
    if isinstance(relationships, dict):
        dependent_table_list.append(relationships.get('table', None))
    else:
        for row in relationships:
            if row.get('table', None):
                dependent_table_list.append(row['table'])

    return dependent_table_list


def persona_executor(row, parameter, filtered_list,table_size, flag):
    try:
        logging.debug('executor with param : \n {}'.format(row))
        logging.debug('-----------')
        components.orchestrations.personaExecutor.execute(row, parameter, filtered_list,table_size, flag)
        return "done"
    except Exception as e:
        logging.error(e)
        return "failed"
    return row


def particulars_executor(row, parameter, filtered_list, flag):
    logging.debug('executor with param : \n {}'.format(row))
    logging.debug('-----------')
    components.orchestrations.particularsExecutor.execute(row, parameter, filtered_list, flag)
    return row


def activity_executor(row, parameter, filtered_list, flag):
    logging.debug('executor with param : \n {}'.format(row))
    logging.debug('-----------')
    components.orchestrations.activityExecutor.execute(row, parameter, filtered_list, flag)
    return row


def static_executor(row, parameter, filtered_list):
    try:
        logging.debug('executor with param : \n {}'.format(row))
        logging.debug('-----------')
        components.orchestrations.staticExecutor.execute(row, parameter, filtered_list)
        return "done"
    except Exception as e:
        logging.error(e)
        return "failed"
    return row


def main():
    global job_df
    dict = {"country": ["Brazil", "Russia", "India", "China", "South Africa"],
            "capital": ["Brasilia", "Moscow", "New Dehli", "Beijing", "Pretoria"],
            "area": [8.516, 17.10, 3.286, 9.597, 1.221],
            "population": [200.4, 143.5, 1252, 1357, 52.98]}
    job_df = pd.DataFrame(dict)


if __name__ == '__main__':
    main()
