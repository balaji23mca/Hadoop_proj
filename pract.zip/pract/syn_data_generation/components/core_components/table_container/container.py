import json
import logging
import os
from datetime import datetime

import pandas as pd

from components.core_components.generators.generator import seed_provider
from components.core_components.generators.utils.generator_utility import ensure_non_existing_dir
from components.core_components.table_container import population
from components.core_components.table_container.clock import Clock
from components.core_components.table_container.story import Story
from components.core_components.utils import persist_gen


class Container(object):
    """
    A Container is just a container of a lot of objects that are required to make the simulation
    It is also the object that will execute the stories required for 1 iteration
    """

    def __init__(self, name, size, master_seed, parameter=None, **clock_params):
        """Create a new Container object

        :param master_seed: seed used to initialized random generatof of
        other seeds
        :type master_seed: int

        :rtype: Container
        :return: a new Container object, with the clock, is created
        """
        self.name = name

        self.parameter = parameter

        self.master_seed = master_seed

        self.size = size

        defaultparam = {'start': pd.Timestamp(datetime.now()), 'step_duration': pd.Timedelta("1h")}

        if 'start' in clock_params.keys():
            defaultparam['start'] = clock_params['start']

        if 'step_duration' in clock_params.keys():
                defaultparam['step_duration'] = clock_params['step_duration']

        self.clock_params = defaultparam


        self.seeder = seed_provider(master_seed=master_seed)
        self.clock = Clock(seed=next(self.seeder), start = self.clock_params['start'], step_duration = self.clock_params['step_duration' ])
        self.stories = []
        self.populations = {}
        self.generators = {}
        self.output_df = None

    def create_population(self, name, **population_params):
        """
        Creates a population with the specifed parameters and attach it to this
        container.
        """
        if name in self.populations:
            raise ValueError("refusing to overwrite existing population: {} "
                             "".format(name))

        self.populations[name] = population.Population(
            container=self, **population_params)
        return self.populations[name]

    def load_population(self, population_id, namespace=None):
        """
        Load this population definition add attach it to this container
        """

        # Defaulting to the namespace associated to this container if none
        # specified
        if namespace is None:
            namespace = self.name

        loaded = persist_gen.load_population(namespace=namespace,
                                             population_id=population_id, container=self)
        self.populations[population_id] = loaded
        return loaded


    def create_story(self, name, **story_params):
        """
        Creates a story with the provided parameters and attach it to this
        container.
        """

        existing = self.get_story(name)

        if existing is None:
            story = Story(name=name, **story_params)
            self.stories.append(story)
            return story

        else:
            raise ValueError("Cannot add story {}: another story with "
                             "identical name is already in the container".format(name))

    def get_story(self, story_name):
        """
        Looks up and story by name in this container and returns it. Returns none
        if not found.
        """
        remaining_stories = filter(
            lambda a: a.name == story_name, self.stories)
        try:
            return next(remaining_stories)
        except StopIteration:
            logging.debug("story not found: {}".format(story_name))
            return None

    def get_population_of(self, story_name):
        """
        Looks up the initiating population associated to this story
        """
        return self.get_story(story_name).triggering_population

    def attach_generator(self, gen_id, generator):
        """
        "attach" a random generator to this container, s.t. it gets persisted
        with the rest
        """
        if gen_id in self.generators:
            raise ValueError("refusing to replace existing generator: {} "
                             "".format(gen_id))

        self.generators[gen_id] = generator

    def load_generator(self, gen_type, gen_id):
        """
        Load this generator definition add attach it to this container
        """
        gen = persist_gen.load_generator(
            namespace=self.name, gen_type=gen_type, gen_id=gen_id)

        self.attach_generator(gen_id, gen)
        return gen

    def create_df(self, logs):
        if self.output_df is None:
            self.output_df = logs

        else:
            self.output_df = self.output_df.append(logs,ignore_index=True)

    @staticmethod
    def save_logs(log_id, logs, log_output_folder):
        """
        Appends those logs to the corresponding output file, creating it if
        it does not exist or appending lines to it otherwise.
        """

        # save_dataframe(container, respDataframe, wsprefix, outputdburl):
        #
        # components.core_components.utils.utility.save_dataframe(self,logs,wsprefix, outputdburl )



        output_file = os.path.join(log_output_folder, "{}.csv".format(log_id))

        if not os.path.exists(log_output_folder):
            os.makedirs(log_output_folder)

        if logs.shape[0] > 0:
            logging.debug("appending {} rows to {}".format(
                logs.shape[0], output_file))

            if not os.path.exists(output_file):
                # If these are this first persisted logs, we create the file
                # and include the field names as column header.
                logs.to_csv(output_file, index=False, header=True)

            else:
                # Otherwise, open the existing log file in append mode and add
                # the new logs at the end, this time without columns headers.
                with open(output_file, "a") as out_f:
                    logs.to_csv(out_f, index=False, header=False)

    def save_dataframe(self, dataframe, fileName, output_folder, delete_existing_logs=False):

        if os.path.exists(output_folder):
            if delete_existing_logs:
                ensure_non_existing_dir(output_folder)
            else:
                raise EnvironmentError("{} exists and delete_existing_logs is "
                                       "False => refusing to start and "
                                       "overwrite logs".format(output_folder))
        self.save_logs(fileName, dataframe, output_folder)



    def runtimed(self, duration, log_output_folder, delete_existing_logs=False):
        """
        Executes all stories in the container for as long as requested.

        :param duration: duration of the desired simulation (start date is
        dictated by the clock)
        :type duration: pd.TimeDelta

        :param log_output_folder: folder where to write the logs.
        :type log_output_folder: string

        :param delete_existing_logs:
        """

        n_iterations = self.clock.n_iterations(duration) * 2
        # logging.debug("Starting container for {} iterations of {} for a "
        #              "total duration of {}".format(
        #                  n_iterations, self.clock.step_duration, duration
        #              ))

        if os.path.exists(log_output_folder):
            if delete_existing_logs:
                ensure_non_existing_dir(log_output_folder)
            else:
                raise EnvironmentError("{} exists and delete_existing_logs is "
                                       "False => refusing to start and "
                                       "overwrite logs".format(log_output_folder))

        logging.debug("total steps  : {}".format(duration))
        for step_number in range(n_iterations):
            # logging.debug("step : {}".format(step_number))

            for story in self.stories:
                for log_id, logs in story.execute().items():
                    # utility.save_dataframe(self, logs, self.parameter.wsprefix, self.parameter.outputdburl)
                    self.create_df(logs)
                    # self.save_logs(log_id, logs, log_output_folder)

            self.clock.increment()

        # df = pd.read_csv("output/example_scenario/{}.csv".format(log_id))
        # print(self.output_df.head(10))
        # print(self.output_df.shape)
        df = self.output_df
        self.output_df = None
        return df


    def run(self, duration, log_output_folder, delete_existing_logs=False):
        """
        Executes all stories in the container for as long as requested.

        :param duration: duration of the desired simulation (start date is
        dictated by the clock)
        :type duration: pd.TimeDelta

        :param log_output_folder: folder where to write the logs.
        :type log_output_folder: string

        :param delete_existing_logs:
        """

        n_iterations = duration * 2
        # logging.debug("Starting container for {} iterations of {} for a "
        #              "total duration of {}".format(
        #                  n_iterations, self.clock.step_duration, duration
        #              ))

        if os.path.exists(log_output_folder):
            if delete_existing_logs:
                ensure_non_existing_dir(log_output_folder)
            else:
                raise EnvironmentError("{} exists and delete_existing_logs is "
                                       "False => refusing to start and "
                                       "overwrite logs".format(log_output_folder))

        logging.debug("total steps  : {}".format(duration))
        for step_number in range(n_iterations):
            logging.debug("step : {}".format(step_number))

            for story in self.stories:
                for log_id, logs in story.execute().items():
                    # utility.save_dataframe(self, logs, self.parameter.wsprefix, self.parameter.outputdburl)
                    self.create_df(logs)
                    # self.save_logs(log_id, logs, log_output_folder)

            self.clock.increment()

        # df = pd.read_csv("output/example_scenario/{}.csv".format(log_id))
        # print(self.output_df.head(10))
        # print(self.output_df.shape)
        df = self.output_df
        self.output_df = None
        return df

    @staticmethod
    def load_from_db(container_name):

        logging.debug("loading container {}".format(container_name))

        namespace_folder = persist_gen.namespace_folder(namespace=container_name)
        config_file = os.path.join(namespace_folder, "container_config.json")

        with open(config_file, "r") as config_h:
            config = json.load(config_h)

            clock_config = {
                "start": pd.Timestamp(config["clock_config"]["start"]),
                "step_duration": pd.Timedelta(
                    str(config["clock_config"]["step_duration"]))
            }

            container = Container(name=container_name, master_seed=config["master_seed"],
                                  **clock_config)

            for population_id in persist_gen.list_populations(namespace=container_name):
                container.load_population(population_id)

            for gen_type, gen_id in persist_gen.list_generators(namespace=container_name):
                container.load_generator(gen_type=gen_type, gen_id=gen_id)

            return container

    def save_to_db(self, overwrite=False):
        """
        Create a db namespace named after this container and saves all the
        populations there.

        Only static data is saved, not the stories.
        """

        logging.debug("saving container {}".format(self.name))

        if persist_gen.is_namespace_existing(namespace=self.name):
            if overwrite:
                logging.warning(
                    "overwriting existing container {}".format(self.name))
                persist_gen.remove_namespace(namespace=self.name)

            else:
                raise IOError("refusing to remove existing {} namespace since "
                              "overwrite parameter is False".format(self.name))

        namespace_folder = persist_gen.create_namespace(namespace=self.name)
        config_file = os.path.join(namespace_folder, "container_config.json")
        with open(config_file, "w") as o:
            config = {"master_seed": self.master_seed,
                      "clock_config": {
                          "start": self.clock_params["start"].isoformat(),
                          "step_duration": str(self.clock_params["step_duration"])}
                      }
            json.dump(config, o, indent=4)

        logging.debug("saving all populations")
        for population_id, ac in self.populations.items():
            persist_gen.save_population(ac, namespace=self.name,
                                        population_id=population_id)

        logging.debug("saving all generators")
        for gen_id, generator in self.generators.items():
            persist_gen.save_generator(generator, namespace=self.name, gen_id=gen_id)

        logging.debug("container saved")

    def save_params_to_db(self, params_type, params):
        """
        Saves the params object to the container folder in the DB for future reference
        :param params_type: "build", "run" or "target"
        :param params: the params object
        """
        target_file = os.path.join(persist_gen.namespace_folder(self.name),
                                   "params_{}.json".format(params_type))

        with open(target_file, "w") as outfile:
            json.dump(params, outfile)

    def description(self):

        return {
            "container_name": self.name,
            "master_seed": self.master_seed,
            "populations": {id: population.description()
                            for id, population in self.populations.items()
                            },
            "generators": {gen_id: gen.description()
                           for gen_id, gen in self.generators.items()
                           },
        }



    def __str__(self):
        return json.dumps(self.description(), indent=4)
