import pandas as pd
import jsonpickle
import datetime
from mimesis import Datetime
from random import randrange
import components.core_components.utils.utility
from components.core_components.utils.helper import *
from components.core_components.generators.generator import Generator


class DateTimeGenerator(Generator):

    def __init__(self, name=None, table_name=None, column_name=None, rule=None, seedyear=None, method=None, days_diff=0,
                 hours_diff=0, start_date=None, end_date=None, initiating_population=None):
        Generator.__init__(self)
        self.name = name
        self.table_name = table_name
        self.column_name = column_name
        self.method = method
        self.rule = rule
        self.seedyear = datetime.datetime.now().year if seedyear is None else seedyear
        self.initiating_population = initiating_population
        self.days_diff = days_diff
        self.hours_diff = hours_diff
        if start_date is None:
            self.start_date = datetime.datetime.now()
        else:
            self.start_date = datetime.datetime.strptime(start_date, "%Y/%m/%d")
        if end_date is None:
            self.end_date = datetime.datetime.now()
        else:
            self.end_date = datetime.datetime.strptime(end_date, "%Y/%m/%d")

    def prepare_datetime_list(self, size, populationDF, method):
        new_value_list = []
        dt = Datetime()
        if self.table_name is not None:
            ext_dataframe = components.core_components.utils.utility.get_table(self.table_name, parameter=None)

        if self.method.lower() == "calculatedate":
            key_list = populationDF[self.column_name]
            for item, value in key_list.iteritems():
                year = self.seedyear - value
                new_value_list.append(dt.date(start=year, end=year))
            return new_value_list
        if self.method.lower() == "modify_date":
            key_list = populationDF[self.column_name]
            for item, value in key_list.iteritems():
                value = value + datetime.timedelta(days=int(self.days_diff))
                value = value + datetime.timedelta(hours=float(self.hours_diff))
                new_value_list.append(value)
            return new_value_list
        if self.method.lower() == "generate_date":
            for i in range(size):
                delta = self.start_date - self.end_date
                delta_sec = abs((delta.days * 24 * 60 * 60) + delta.seconds)
                random_secs = randrange(delta_sec) if delta_sec != 0 else 0
                new_value_list.append(self.start_date+datetime.timedelta(seconds=random_secs))
            return new_value_list

    def generate(self, size, population):
        if self.end_date < self.start_date:
            logging.error("End date {} is less then Start date {}".format(self.end_date, self.start_date))
            return size * [None]
        if population is not None:
            if isinstance(population, pd.DataFrame) and self.name in population.columns:
                population_dataframe = population
            elif not isinstance(population, pd.DataFrame):
                population_dataframe = population.to_dataframe(size=size)

            return self.prepare_datetime_list(size, population_dataframe, self.method)
        # elif self.initiating_population is not None:
        #     print("+++++++++in inti pop is not none")

        else:
            if self.table_name:
                df = components.core_components.utils.utility.get_table(self.table_name, parameter=None)
            else:
                return ["Table name not provided"] * size
            result_list = self.prepare_datetime_list(size, df, self.method)
            if size != len(result_list):
                if size > len(result_list):
                    extra_lenght = size - len(result_list)
                    result_list = result_list + ['NA'] * extra_lenght
                    return result_list
                if size < len(result_list):
                    return result_list[:size]

            return result_list

    def applyRule(self, size, population):
        pass

    def lookup(self, condition, **fakerKwargs):
        return condition

    def transform(self, init_values, **fakerKwargs):
        return init_values

    def validate(self, init_values, **fakerKwargs):
        return init_values

    def improve(self, init_values, **fakerKwargs):
        return init_values

    def build(self, init_values, **fakerKwargs):
        return init_values


if __name__ == '__main__':

    population_gen_param = jsonpickle.decode("""
                {  
                    "generator_list":[  
                        {  
                            "generator_name":"SequencialGenerator",
                            "column_name":"age",
                            "parameters":{  
                                "start":2,
                                "prefix":""
                            }
                        }
                    ]
                }
              """)

    size = 10
    container = createContainerObject(name="dependent_column_generator_table", size=size, master_seed=1234)

    population = initializePopulation(container=container)

    gen_instance_list = []

    try:
        for gen_param in population_gen_param.get("generator_list"):
            logging.debug('initializeGenerators with param : {}'.format(gen_param))
            gen_instance = generator_factory.getInstance(gen_param)
            gen_instance_list.append(gen_instance)
    except Exception as e:
        logging.error('Exception occurred : '.format(e))

    population = createPopulation(gen_instance_list=gen_instance_list, population=population, size=container.size)
    print(population.to_dataframe(size))
    ##########helper : ends

    body = jsonpickle.decode("""
        {  
           "generator_name":"DateTimeGenerator",
           "column_name":"DOB",
           "parameters":{  
              "table_name":"persona",
              "select_column_name":"age",
              "method":"generate_date",
              "start_date":"2019/4/1",
              "end_date":"2019/5/1"          
           }
        }
              """)

    gen = DateTimeGenerator()
    gen.name = body.get('column_name', None)
    gen.rule = body.get('generator_rule', None)
    gen.usage = body.get('usage', None)
    parameters = body.get('parameters', None)
    if parameters:
        gen.table_name = parameters.get('table_name', None)
        gen.column_name = parameters.get('select_column_name', None)
        gen.method = parameters.get('method', None)
        gen.seedyear = parameters.get('seedyear', None)
        gen.start_date = parameters.get('start_date', datetime.datetime.now().strftime('%Y/%m/%d'))
        gen.end_date = parameters.get('end_date', datetime.datetime.now().strftime('%Y/%m/%d'))
    result = gen.generate(size=10, population=None)

    print(result)
