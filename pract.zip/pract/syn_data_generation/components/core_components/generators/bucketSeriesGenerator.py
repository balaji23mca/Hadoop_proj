import numpy as np
from numpy.random.mtrand import RandomState

from components.core_components.generators.generator import Generator
from components.core_components.generators.utils.generator_utility import merge_2_dicts


class BucketSeriesGenerator(Generator):
    """
        Generator wrapping any numpy.Random method.
    """

    def __init__(self, name=None, method=None, seed=1234, numpy_method=None, rule=None, usage=None,
                 **list_generator_parameters):
        """Initialise a random number generator

        :param method: string: must be a valid numpy.Randomstate method that
            accept the "size" parameter

        :param list_generator_parameters: dict, see descriptions below
        :param seed: int, seed of the generator
        :return: create a random number generator of type "gen_type", with its parameters and seeded.
        """
        Generator.__init__(self)
        self.rule = rule
        self.name = name
        self.seed = seed
        self.method = method
        self.usage = usage
        self.list_generator_parameters = list_generator_parameters
        self.numpy_method = numpy_method  # getattr(self.state, method)

    def generate(self, size, population):
        self.state = RandomState(self.seed)
        self.numpy_method = getattr(self.state, self.method)
        all_params = merge_2_dicts({"size": size}, self.list_generator_parameters)
        result = self.numpy_method(**all_params)
        result = list(map(lambda x: eval(x), result))

        return list(map(lambda x: np.random.choice(a=list(range(x[0], x[1]))), result))

    def transform(self, init_values, **fakerKwargs):
        # print("transforming values --> ", len(init_values) )
        return init_values

    def validate(self, init_values, **fakerKwargs):
        # print("validate values --> ", len(init_values) )
        return init_values

    def improve(self, init_values, **fakerKwargs):
        # print("improve values --> ", len(init_values) )
        return init_values

    def build(self, init_values, **fakerKwargs):
        # print("build values --> ", len(init_values) )
        return init_values

    def description(self):
        return {
            "type": "BucketSeriesGenerator",
            "method": self.method,
            "list_generator_parameters": self.list_generator_parameters}


if __name__ == '__main__':
    import jsonpickle

    body = jsonpickle.decode("""
{  
   "generator_name":"BucketSeriesGenerator",
   "column_name":"age",
   "distribution_type":"choice",
   "parameters":{
      "a":[  
         "20,30",
         "30,40"
      ],
      "p":[  
         0.5,
         0.5
      ]
   },
   "usage":[  
                      "dynamic"
                   ]
}
              """)

    gen = BucketSeriesGenerator()
    gen.name = body.get('column_name', None)
    gen.rule = body.get('generator_rule', None)
    gen.method = body.get('distribution_type', None)
    gen.list_generator_parameters = body.get('parameters', None)
    gen.usage = body.get('usage', None)

    result = gen.generate(size=10, population=None)

    print(result)
