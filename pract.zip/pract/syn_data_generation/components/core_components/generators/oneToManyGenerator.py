from components.core_components.generators.generator import Generator
import numpy as np


class OneToManyGenerator(Generator):
    def __init__(self, value=0, name=None, rule=None, usage=None):
        Generator.__init__(self)
        self.name = name
        self.value = value

    def generate(self, size, population=None):
        result = [self.value] * size
        return result


if __name__ == '__main__':
    import jsonpickle

    body = jsonpickle.decode("""
        {  
           "generator_name":"OneToManyGenerator",
           "column_name":"value"
        }
              """)

    gen = OneToManyGenerator()
    gen.name = body.get('column_name', None)
    result = gen.generate(size=10, population=None)

    print(result)
