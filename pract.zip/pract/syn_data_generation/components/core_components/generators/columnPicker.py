import pandas as pd
import time
import  components.core_components.utils.utility
from components.core_components.generators.generator import Generator


class ColumnPicker(Generator):

    def __init__(self, name=None, table_name=None, column_name=None, rule=None, seed=None, key=None,
                 initiating_population=None):
        Generator.__init__(self)
        self.name = name
        self.table_name = table_name
        self.column_name = column_name
        self.key = key
        self.rule = rule
        self.initiating_population = initiating_population

    def generate(self, size, population):

        if population is not None:
            if isinstance(population, pd.DataFrame) and self.key in population.columns:
                if self.key:
                    new_value_list = []
                    population_dataframe = population

                    key_list = population_dataframe[self.key]

                    key_list = list(map(str, key_list))
                    start_time1 = time.time()
                    ext_dataframe = components.core_components.utils.utility.get_table(self.table_name, parameter=None)
                    # print('time spent in fetching df: %.3f seconds' % (time.time() - start_time1))

                    start_time1 = time.time()
                    ext_dataframedict = ext_dataframe[ext_dataframe[self.key].isin(key_list)][[self.key, self.column_name]].set_index(
                        self.key).to_dict()[self.column_name]
                    # print('time spent in creating dict: %.3f seconds' % (time.time() - start_time1))

                    start_time1 = time.time()
                    for key in key_list:
                        new_value_list.append(ext_dataframedict.get(key, 0) )
                    # print('time spent for loop: %.3f seconds' % (time.time() - start_time1))


                    return new_value_list

                else:
                    return population.to_dataframe(size=size)[self.column_name]

            elif not isinstance(population, pd.DataFrame):
                if self.key:
                    new_value_list = []
                    population_dataframe = population.to_dataframe(size=size)

                    key_list = population_dataframe[self.key]

                    ext_dataframe = components.core_components.utils.utility.get_table(self.table_name, parameter=population.container.parameter)
                    ext_dataframedict = ext_dataframe[ext_dataframe[self.key].isin(key_list)][[self.key, self.column_name]].set_index(
                        self.key).to_dict()[self.column_name]
                    # print('time spent in creating dict: %.3f seconds' % (time.time() - start_time1))

                    start_time1 = time.time()
                    for key in key_list:
                        new_value_list.append(ext_dataframedict.get(key, 0) )
                    return new_value_list
                else:
                    if self.table_name:
                        df = components.core_components.utils.utility.get_table(self.table_name, parameter=population.container.parameter)
                        if size != len(df.index):
                            if size > len(df.index):
                                extra_lenght = size - len(df.index)
                                extra_series = pd.Series(00, index=range(1, extra_lenght + 1))
                                return pd.concat([df[self.column_name], extra_series])
                            if size < len(df.index):
                                return df.iloc[:size][self.column_name]


                        return df[self.column_name]
                    else:
                        return population.to_dataframe(size=size)[self.column_name]


        elif self.initiating_population is not None:
            if self.key:
                new_value_list = []
                population_dataframe = self.initiating_population.to_dataframe(size=size)

                key_list = population_dataframe[self.key]

                ext_dataframe = components.core_components.utils.utility.get_table(self.table_name,
                                                  parameter=self.initiating_population.container.parameter)
                ext_dataframedict = \
                ext_dataframe[ext_dataframe[self.key].isin(key_list)][[self.key, self.column_name]].set_index(
                    self.key).to_dict()[self.column_name]
                # print('time spent in creating dict: %.3f seconds' % (time.time() - start_time1))

                start_time1 = time.time()
                for key in key_list:
                    new_value_list.append(ext_dataframedict.get(key, 0))
                return new_value_list
            else:
                if self.table_name:
                    df = components.core_components.utils.utility.get_table(self.table_name, parameter=self.initiating_population.container.parameter)
                    return df[self.column_name]
                else:
                    return self.initiating_population.to_dataframe(size=size)[self.column_name]

        else:
            if self.table_name:
                df = components.core_components.utils.utility.get_table(self.table_name, parameter=None)
            else:
                return ["Table name not provided"] * size

            if size != len(df.index):
                if size > len(df.index):
                    extra_lenght = size - len(df.index)
                    extra_series = pd.Series('NA', index=range(1, extra_lenght + 1))
                    return pd.concat([df[self.column_name], extra_series])
                if size < len(df.index):
                    extra_lenght = len(df.index) - size
                    return df.iloc[:size][self.column_name]

            return df[self.column_name]



    def applyRule(self, size, population):
        pass

    def lookup(self, condition, **fakerKwargs):
        # print("-- lookup values --")
        return condition

    def transform(self, init_values, **fakerKwargs):
        # print("transforming values --> ", len(init_values) )
        return init_values

    def validate(self, init_values, **fakerKwargs):
        # print("validate values --> ", len(init_values) )
        return init_values

    def improve(self, init_values, **fakerKwargs):
        # print("improve values --> ", len(init_values) )
        return init_values

    def build(self, init_values, **fakerKwargs):
        # print("build values --> ", len(init_values) )
        return init_values


if __name__ == '__main__':
    import jsonpickle
    from components.core_components.utils.helper import *;
    import jsonpickle

    ##########helper : start
    population_gen_param = jsonpickle.decode("""
                {  
                    "generator_list":[  
                        {  
                            "generator_name":"SequencialGenerator",
                            "column_name":"person_id",
                            "parameters":{  
                                "start":2,
                                "prefix":""
                            }
                        }
                    ]
                }
              """)

    size = 90
    container = createContainerObject(name="dependent_column_generator_table", size=size, master_seed=1234);

    population = initializePopulation(container=container)

    gen_instance_list = []

    try:
        for gen_param in population_gen_param.get("generator_list"):
            logging.debug('initializeGenerators with param : {}'.format(gen_param))
            gen_instance = generator_factory.getInstance(gen_param)
            gen_instance_list.append(gen_instance)
    except Exception as e:
        logging.error('Exception occurred : '.format(e))

    population = createPopulation(gen_instance_list=gen_instance_list, population=population,
                                  size=container.size);
    print(population.to_dataframe(size))
    ##########helper : ends

    body = jsonpickle.decode("""
        {  
           "generator_name":"ColumnPicker",
           "column_name":"age",
           "parameters":{  
              "table_name":"Person",
              "select_column_name":"age",
              "key":"person_id"
           },
           "usage":[  
              "static"
           ]
        }
              """)

    gen = ColumnPicker()
    gen.name = body.get('column_name', None)
    gen.rule = body.get('generator_rule', None)
    gen.usage = body.get('usage', None)
    parameters = body.get('parameters', None)
    if parameters:
        gen.table_name = parameters.get('table_name', None)
        gen.column_name = parameters.get('select_column_name', None)
        gen.key = parameters.get('key', None)
    result = gen.generate(size=90, population=None)

    print(result)
