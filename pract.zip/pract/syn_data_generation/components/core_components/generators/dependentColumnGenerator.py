import numpy as np
import pandas as pd

from components.core_components.generators.generator import Generator


class DependentColumnGenerator(Generator):
    def __init__(self, name=None, oldColumn=None, choices=None, newColName=None, conditions=None, rule=None, seed=None,
                 initiating_population=None):
        Generator.__init__(self)

        self.rule = rule
        self.name = name
        self.oldColumn = oldColumn
        self.choices = choices
        self.newColName = newColName
        self.conditions = conditions
        self.initiating_population = initiating_population

    def prepareCondition(self, conditions, oldColumn, df):
        np_conditions = []
        if "|" not in conditions and len(conditions) > 1:

            for condition in conditions:
                for vals in oldColumn:
                    arrt = 'getattr(df, "{}")'.format(vals)
                    word1 = "'getattr(df, \"{}\")'".format(vals)
                    word2 = "getattr(df, \"{}\")".format(vals)
                    condition = condition.replace(vals, arrt).replace(word1,
                                                                      word2).replace('[', '').replace(']', '')
                np_conditions.append(eval(condition))

        else:

            for vals in oldColumn:
                arrt = 'getattr(df, "{}")'.format(vals)
                word1 = "'getattr(df, \"{}\")'".format(vals)
                word2 = "getattr(df, \"{}\")".format(vals)
                conditions = conditions.replace(vals, arrt).replace(word1,
                                                                    word2).replace('[', '').replace(']', '')
            result = [x.strip() for x in conditions.split('|')]
            for val in result:
                np_conditions.append(eval(val))

        # for vals in oldColumn:
        #     arrt = 'getattr(df, "{}")'.format(vals)
        #     conditions = conditions.replace(vals, arrt).replace("'getattr(df, \"age\")'", "getattr(df, \"age\")")
        return np_conditions

        # print(" Existing Data frame : ", self.data)

    def generate(self, size, population):
        if isinstance(population, pd.DataFrame) and set(self.oldColumn).issubset(population.columns):
            df = population
        else:
            if  not isinstance(population, pd.DataFrame):
                df = population.to_dataframe()
            elif self.initiating_population:
                df = self.initiating_population.to_dataframe()
        np_conditions = self.prepareCondition(self.conditions, self.oldColumn, df)
        result = np.select(np_conditions, self.choices, default=np.nan)

        for i in range(len(result)):
            tmp_array = result[i].tolist().split(',')

            tmp_array_1 = result[i].split(':')
            if len(tmp_array_1) > 1:
                # print(tmp_array_1)
                a = tmp_array_1[0].replace('(', '').replace(')', '')
                p = tmp_array_1[1].replace('(', '').replace(')', '')
                a = eval(a)
                p = eval(p)

                result[i] = np.random.choice(a, p=p)
                continue

            if len(tmp_array) > 1:
                result[i] = np.random.choice(tmp_array).replace('(', '').replace(')', '')
        df["column"] = result

        return df["column"]

#eval(self.choices[1].replace('(', '').replace(')', '').split(':')[0])

    def applyRule(self, size, population):
        pass

    def lookup(self, condition, **fakerKwargs):
        # print("-- lookup values --")
        return condition

    def transform(self, init_values, **fakerKwargs):
        # print("transforming values --> ", len(init_values) )
        return init_values

    def validate(self, init_values, **fakerKwargs):
        # print("validate values --> ", len(init_values) )
        return init_values

    def improve(self, init_values, **fakerKwargs):
        # print("improve values --> ", len(init_values) )
        return init_values

    def build(self, init_values, **fakerKwargs):
        # print("build values --> ", len(init_values) )
        return init_values


if __name__ == '__main__':
    from components.core_components.utils.helper import *;
    import jsonpickle

    ##########helper : start
    population_gen_param = jsonpickle.decode("""
        {  
           "generator_list":[  
              {  
                 "generator_name":"BucketSeriesGenerator",
                 "column_name":"age",
                 "distribution_type":"choice",
                 "parameters":{"a": ["13,30", "30,40", "40,50", "50,60"], "p": [0.5, 0.2, 0.1, 0.2]},
                 "usage":[  
                    "dynamic"
                 ]
              },
              {  
                 "generator_name":"ListGenerator",
                 "column_name":"gender",
                 "distribution_type":"choice",
                 "parameters":{  
                    "a":[  
                       "male",
                       "female"
                    ],
                    "p":[  
                       0.50,
                       0.50
                    ]
                 },
                 "usage":[  
                    "dynamic"
                 ]
              }
           ]
        }
              """)

    size = 10
    container = createContainerObject(name="dependent_column_generator_table", size=size, master_seed=1234);

    population = initializePopulation(container=container)

    gen_instance_list = []

    try:
        for gen_param in population_gen_param.get("generator_list"):
            logging.debug('initializeGenerators with param : {}'.format(gen_param))
            gen_instance = generator_factory.getInstance(gen_param)
            gen_instance_list.append(gen_instance)
    except Exception as e:
        logging.error('Exception occurred : '.format(e))

    population = createPopulation(gen_instance_list=gen_instance_list, population=population,
                                  size=container.size);
    print(population.to_dataframe(size))
    ##########helper : ends

    #######

    # ###### WITH SQL #### STARTS
    # from components.core_components.utils.database.db_helper import read_table
    #
    # dburl = "mysql+pymysql://user:password@34.246.21.248/datagen"
    # # run_script_file(dburl)
    # table_name = "dependent_generator_conditions"
    #
    # filter = {
    #     'column_index': [1],
    #     'table_id': [1],  # Note that Age is a string
    # }
    # data = read_table(table_name, dburl, wsprefix=None, filter=filter)
    #
    # # print(data.to_json (orient='records', lines=True))
    # choices_list = []
    # conditions_list = []
    # dependent_column_list = []
    # # list(dict.fromkeys(iteration_filedList)
    # for index, row in data.iterrows():
    #     choices_list.append(row['choices'])
    #     conditions_list.append(row['conditions'])
    #
    #     tmp_array = row['dependent_column'].split(',')
    #     if len(tmp_array) > 1:
    #         for j in range(len(tmp_array)):
    #             dependent_column_list.append(tmp_array[j])
    #
    #     else:
    #         dependent_column_list.append(row['dependent_column'])
    #
    # #######
    #
    # ###### WITH SQL ####
    # body = jsonpickle.decode("""
    #                     {
    #                        "column_name":"job_type",
    #                        "parameters":{
    #                           "conditions": "",
    #                           "dependent_column": "",
    #                           "choices": ""
    #                        },
    #                        "generator_name":"DependentColumnGenerator"
    #
    #                     }
    #               """)
    #
    # print(body)
    #
    # body["parameters"]["conditions"] = conditions_list
    # body["parameters"]["dependent_column"] = list(dict.fromkeys(dependent_column_list))
    # body["parameters"]["choices"] = choices_list
    # print(body)
    # ###### WITH SQL #### ENDS

    ##### without SQL #### starts

    body = jsonpickle.decode("""
                    {
                       "column_name":"job_type",
                       "parameters":{
                          "conditions":"[('age' < 18) | ('age' >= 18) & ('age' <= 30) & ('gender'  == 'male')  | ('age' >= 18) & ('age' <= 30) & ('gender'  == 'female') | ('age' > 30)  ]",
                          "dependent_column":[
                             "age","gender"
                          ],
                          "choices":[
                             "Catch them Young Savings Account",
                             "(Salary Saving Account,Personal Loan Account,Credit Card )",
                             "(Salary Account,Car Loan Account)",
                             "Current Account"
                          ]
                       },
                       "generator_name":"DependentColumnGenerator",
                       "usage":[
                          "dynamic"
                       ]
                    }
              """)

    ###### without SQL #### ends
    gen = DependentColumnGenerator()
    gen.name = body.get('column_name', None)
    gen.oldColumn = body.get('parameters').get('dependent_column', None)
    gen.choices = body.get('parameters').get('choices', None)
    gen.conditions = body.get('parameters').get('conditions', None)

    res = gen.generate(size, population)
    print(res)
