import json
import logging

import numpy as np
from numpy.random.mtrand import RandomState

from components.core_components.generators.generator import Generator
from components.core_components.generators.utils.generator_utility import merge_2_dicts


class ListGenerator(Generator):
    """
        Generator wrapping any numpy.Random method.
    """

    def __init__(self, name=None, method=None, seed=None, rule=None, numpy_method=None, usage=None,
                 **list_generator_parameters):
        """Initialise a random number generator

        :param method: string: must be a valid numpy.Randomstate method that
            accept the "size" parameter

        :param list_generator_parameters: dict, see descriptions below
        :param seed: int, seed of the generator
        :return: create a random number generator of type "gen_type", with its parameters and seeded.
        """
        Generator.__init__(self)
        self.rule = rule
        self.name = name
        self.seed = seed
        self.method = method
        self.usage = usage
        self.list_generator_parameters = list_generator_parameters
        self.usage = usage
        self.numpy_method = numpy_method


    def generate(self, size, population):
        from random import randint
        self.seed = randint(1000, 9999)
        self.state = RandomState(self.seed)
        self.numpy_method = getattr(self.state, self.method)
        all_params = merge_2_dicts({"size": size}, self.list_generator_parameters)
        return self.numpy_method(**all_params)

    def transform(self, init_values, **fakerKwargs):
        # print("transforming values --> ", len(init_values) )
        return init_values

    def validate(self, init_values, **fakerKwargs):
        # print("validate values --> ", len(init_values) )
        return init_values

    def improve(self, init_values, **fakerKwargs):
        # print("improve values --> ", len(init_values) )
        return init_values

    def build(self, init_values, **fakerKwargs):
        # print("build values --> ", len(init_values) )
        return init_values

    def description(self):
        return {
            "type": "ListGenerator",
            "method": self.method,
            "list_generator_parameters": self.list_generator_parameters
        }

    def save_to(self, output_file):
        logging.debug("saving generator to {}".format(output_file))

        # saving the numpy RandomState instance, converting the numpy array
        # to enable json serialization
        np_state = self.state.get_state()
        state = {
            "method": self.method,
            "list_generator_parameters": self.list_generator_parameters,
            "numpy_state": (np_state[0], np_state[1].tolist(), np_state[2],
                            np_state[3], np_state[4])
        }
        with open(output_file, "w") as outf:
            json.dump(state, outf, indent=4)

    @staticmethod
    def load_from(input_file):
        logging.debug("loading numpy generator from {}".format(input_file))

        with open(input_file, "r") as inf:
            json_payload = json.load(inf)

            # Initializing the generator with an incorrect seed just to make
            # the constructor happy, then setting the state
            gen = ListGenerator(
                method=json_payload["method"],
                seed=1234,
                **json_payload["list_generator_parameters"])

            # retrieving the numpy state + converting list to np.array as needed
            state_raw_ = json_payload["numpy_state"]
            np_state = (state_raw_[0], np.array(state_raw_[1]), state_raw_[2],
                        state_raw_[3], state_raw_[4])

            gen.state = np.random.seed(1234)
            gen.state.set_state(np_state)
            return gen


Generator.file_loaders["ListGenerator"] = ListGenerator.load_from

if __name__ == '__main__':
    import jsonpickle

    # body = jsonpickle.decode("""
    #     {
    #        "generator_name":"ListGenerator",
    #        "column_name":"age",
    #        "distribution_type":"choice",
    #        "parameters":{
    #           "a":[
    #              "20",
    #              "30"
    #           ],
    #           "p":[
    #              0.5,
    #              0.5
    #           ]
    #        },
    #        "usage":[
    #           "dynamic"
    #        ]
    #     }
    #           """)

    body = jsonpickle.decode("""
        {  
           "generator_name":"ListGenerator",
           "column_name":"age",
           "distribution_type":"randint",
           "parameters":{  
              "low": 10,
              "high":15
           },
           "usage":[  
              "dynamic"
           ]
        }
              """)
    gen = ListGenerator()
    gen.name = body.get('column_name', None)
    gen.rule = body.get('generator_rule', None)
    gen.method = body.get('distribution_type', None)
    gen.list_generator_parameters = body.get('parameters', None)
    gen.usage = body.get('usage', None)

    result = gen.generate(size=10, population=None)

    print(result)
