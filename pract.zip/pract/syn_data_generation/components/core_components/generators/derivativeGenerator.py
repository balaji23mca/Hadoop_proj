import  components.core_components.utils.utility
import pandas as pd
from components.core_components.generators.generator import Generator

class DerivativeGenerator(Generator):

    def __init__(self, name=None, table_name=None, column_name=None, rule=None, seed=None, derivative_columns=None,
                 initiating_population=None, derivative_factors = None, operator = None):
        Generator.__init__(self)
        self.name = name
        self.table_name = table_name
        self.column_name = column_name
        self.derivative_columns = derivative_columns
        self.rule = rule
        self.initiating_population = initiating_population
        self.derivative_factors = derivative_factors
        self.operator = operator

    def generate(self, size, population):

        if self.table_name :
            df = components.core_components.utils.utility.get_table(self.table_name, parameter=None)

            if (self.table_name or self.column_name) and self.operator == '*':
                i = 0
                for val in self.derivative_columns:
                    if (i == 0):
                        #df[self.column_name] = (df[val].astype(float) * self.derivative_factors[i])
                        df[self.column_name] = df[val].astype(float).multiply(other=self.derivative_factors[i], fill_value=0)
                    else:
                        df[self.column_name] = df[self.column_name] + df[val].astype(float).multiply(other=self.derivative_factors[i], fill_value=0)
                    i = i + 1

            if (self.table_name or self.column_name) and self.operator == '/':
                i = 0
                for val in self.derivative_columns:
                    if(i == 0):
                        df[self.column_name] = df[val].astype(float).divide(other=self.derivative_factors[i], fill_value=0)
                    else:
                        df[self.column_name] = df[self.column_name] + df[val].astype(float).divide(other=self.derivative_factors[i], fill_value=0)
                    i = i + 1
            df[self.column_name] = pd.Series(map(lambda x: round(x, 3), df[self.column_name]))
            return df[self.column_name]
        else:
            if isinstance(population, pd.DataFrame):
                df = population.copy()
            else:
                df = population.to_dataframe(size=size)

            if (self.table_name or self.column_name) and self.operator == '*':
                i = 0
                for val in self.derivative_columns:
                    if (i == 0):
                        df[self.column_name] = (df[val].astype(float) * self.derivative_factors[i])

                    else:
                        df[self.column_name] = df[self.column_name] + (df[val].astype(float) * self.derivative_factors[i])
                    i = i + 1

            if (self.table_name or self.column_name) and self.operator == '/':
                i = 0
                for val in self.derivative_columns:
                    if(i == 0):
                        df[self.column_name] = (df[val].astype(float) / self.derivative_factors[i])
                    else:
                        df[self.column_name] = df[self.column_name] + (df[val].astype(float) / self.derivative_factors[i])
                    i = i + 1

            df[self.column_name] = pd.Series(map(lambda x: round(x, 3), df[self.column_name]))
            return df[self.column_name]


    def applyRule(self, size, population):
        pass

    def lookup(self, condition, **fakerKwargs):
        # print("-- lookup values --")
        return condition

    def transform(self, init_values, **fakerKwargs):
        # print("transforming values --> ", len(init_values) )
        return init_values

    def validate(self, init_values, **fakerKwargs):
        # print("validate values --> ", len(init_values) )
        return init_values

    def improve(self, init_values, **fakerKwargs):
        # print("improve values --> ", len(init_values) )
        return init_values

    def build(self, init_values, **fakerKwargs):
        # print("build values --> ", len(init_values) )
        return init_values


if __name__ == '__main__':
    import jsonpickle
    from components.core_components.utils.helper import *;
    import jsonpickle

    body = jsonpickle.decode("""
        {
           "generator_name":"DerivativeGenerator",
           "column_name":"transaction_amount",
           "parameters":{
              "table_name":"account", 
              "derivative_columns" : ["balance"],
              "derivative_factors" : [0.7],
              "operator" : "*"
           },
           "usage":[
              "static"
           ]
        }
              """)


    gen = DerivativeGenerator()
    gen.column_name = body.get('column_name', None)
    gen.name = body.get('column_name', None)
    gen.rule = body.get('generator_rule', None)
    gen.usage = body.get('usage', None)
    parameters = body.get('parameters', None)

    if parameters:
        try:
            gen.table_name = parameters.get('table_name',None)
            gen.derivative_columns = parameters.get('derivative_columns', None)  # a list of dependent columns
            gen.derivative_factors = parameters.get('derivative_factors', None)  # a list of factors for each columns
            gen.operator = parameters.get('operator',None)
        # try:
        #     for key in derivative_columns:
        #         gen.table_name = parameters.get('table_name', None)
        #         gen.key = key  # parameters.get('key', None)
        #         gen.derivative_factor = derivative_factors[i]
        #         i = i + 1
        except Exception as e:
            print(e)
        result = gen.generate(size=150, population=None)

    print(result)