import numpy as np

from components.core_components.generators.generator import Generator
#from components.core_components.utils import utility


class CorrelatedGenerator(Generator):

    def __init__(self, name=None, table_name=None, column_name=None, rule=None, feature1=None, feature2=None, act_low=None,
                 act_high=None, Exp_corr=None, seed=None):
        Generator.__init__(self)
        self.name = name
        self.table_name = table_name
        self.column_name = column_name

        self.feature1 = feature1
        self.feature2 = feature2
        self.act_low = act_low
        self.act_high = act_high
        self.Exp_corr = Exp_corr

        self.rule = rule

    def generate(self, size, population):
        df = population.to_dataframe(size)
        # df = utility.get_table(self.table_name)

        res = self.corr_btw_features(data=df, feature1=self.feature1, feature2=self.feature2, act_low=self.act_low, act_high=self.act_high,
                                Exp_corr=self.Exp_corr)

        return res

    def corr_btw_features(self, data, feature1, feature2, act_low, act_high, Exp_corr):
        # Initializing const and variable to appropriate values
        count = 1
        delta = 0
        act_low_param = 19
        act_high_param = 60
        delta_const = 333
        # print(delta_const)
        # Read data and sort it by feature1
        feature1_data = data[[feature1]]
        # print(feature1_data)
        sorted_data = feature1_data.sort_values(by=[feature1])
        feature2 = feature1_data.eval(feature1)

        def is_almost_equal(x, y, epsilon=0.011):
            return abs(x - y) <= epsilon

        # loop through feature2 and correct corelation iteratively
        for count in range(len(feature2)):

            inter_sorted_feature = feature2[count:int(len(feature2) - delta)].sort_values()
            new_feature = inter_sorted_feature.append(feature2[len(inter_sorted_feature):])
            iter1_cor = np.corrcoef(sorted_data[feature1], new_feature)

            # condition to match actual corelation matching with expected??
            if (is_almost_equal(iter1_cor[0, 1], Exp_corr)):
                break
            # return (len(salary)- delta)
            # print("Fail and delta is ",delta)
            delta = delta + 10

        s3 = feature2[1:int(len(feature2) - delta)].sort_values()
        y = s3.append(feature2[len(s3):])
        # print(np.corrcoef(sorted_age.age,y),delta)

        # generate salary and should be between lower nad upper range
        self.column_name = list(
            map(lambda x: ((x) * (np.random.uniform(act_low / act_low_param, act_high / act_high_param)) + delta_const), y))
        for (i, item) in enumerate(self.column_name):
            if item > act_high or item < act_low:
                self.column_name[i] = np.random.uniform(act_low, act_high)

        # print("correlation is {}".format(np.corrcoef(sorted_data.age, y)))
        salary = list(map(lambda x: round(x, 3), self.column_name))
        #return (self.column_name)
        return salary

    def applyRule(self, size, population):
        pass

    def lookup(self, condition, **fakerKwargs):
        # print("-- lookup values --")
        return condition

    def transform(self, init_values, **fakerKwargs):
        # print("transforming values --> ", len(init_values) )
        return init_values

    def validate(self, init_values, **fakerKwargs):
        # print("validate values --> ", len(init_values) )
        return init_values

    def improve(self, init_values, **fakerKwargs):
        # print("improve values --> ", len(init_values) )
        return init_values

    def build(self, init_values, **fakerKwargs):
        # print("build values --> ", len(init_values) )
        return init_values

if __name__ == '__main__':
   import jsonpickle
   from components.core_components.utils.helper import *;

   ##########helper : start
   population_gen_param = jsonpickle.decode("""
       {  
          "generator_list":[  
             {  
                "generator_name":"ListGenerator",
                "column_name":"age",
                "distribution_type":"choice",
                "parameters":{  
                   "a":[  
                      20,
                      30,
                      40,
                      50
                   ],
                   "p":[  
                      0.25,
                      0.25,
                      0.25,
                      0.25
                   ]
                },
                "usage":[  
                   "dynamic"
                ]
             },
             {  
                "generator_name":"ListGenerator",
                "column_name":"gender",
                "distribution_type":"choice",
                "parameters":{  
                   "a":[  
                      "male",
                      "female"
                   ],
                   "p":[  
                      0.50,
                      0.50
                   ]
                },
                "usage":[  
                   "dynamic"
                ]
             }
          ]
       }
             """)

   size = 10
   container = createContainerObject(name="dependent_column_generator_table", size=size, master_seed=1234);

   population = initializePopulation(container=container)

   gen_instance_list = []

   try:
       for gen_param in population_gen_param.get("generator_list"):
           logging.debug('initializeGenerators with param : {}'.format(gen_param))
           gen_instance = generator_factory.getInstance(gen_param)
           gen_instance_list.append(gen_instance)
   except Exception as e:
       logging.error('Exception occured : '.format(e))

   population = createPopulation(gen_instance_list=gen_instance_list, population=population,
                                 size=container.size);
   # print(population.to_dataframe(size))
   ##########helper : ends


   body = jsonpickle.decode("""
       {
          "generator_name":"CorrelatedGenerator",
          "column_name":"new_col",
          "parameters":{"table_name":"persona","column_name":"age","feature1" : "age", "feature2" : "salary", "act_low" : 50000, "act_high" : 80000, "Exp_corr" : 0.80},
          "usage":[
             "static"
          ]
       }
                 """)
   gen = CorrelatedGenerator()
   gen.column_name = body.get('column_name', None)
   gen.rule = body.get('generator_rule', None)
   gen.usage = body.get('usage', None)
   parameters = body.get('parameters', None)
   if parameters:
       gen.method = parameters.get('method', None)
       gen.feature1 = parameters.get('feature1', None)
       #gen.feature2 = parameters.get('feature2', None)
       gen.act_low = parameters.get('act_low', None)
       gen.act_high = parameters.get('act_high',None)
       gen.Exp_corr = parameters.get('Exp_corr',None)
   result = gen.generate(size=10, population=population)
   print(result)
