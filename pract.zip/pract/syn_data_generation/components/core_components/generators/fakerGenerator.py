# from faker import Faker

from mimesis import Address
from mimesis import Datetime
from mimesis import Person

from components.core_components.generators.generator import Generator


class FakerGenerator(Generator):
    """
    Generator wrapping Faker factory
    """

    def __init__(self, method=None, name=None, rule=None, seed=None, **fakerKwargs):
        Generator.__init__(self)
        self.rule = rule
        self.name = name
        self.method = method
        self.api = None
        self.fakerKwargs = fakerKwargs


    def lookup(self, condition, **fakerKwargs):
        # print("-- lookup values --")
        return condition

    def generate(self, size, population):
        if self.api == "Address":
            self.fake = Address()
        elif self.api == "Datetime":
            self.fake = Datetime()
        else:
            self.fake = Person()

        method = getattr(self.fake, self.method)
        return [method(**self.fakerKwargs) for _ in range(size)]

    def transform(self, init_values, **fakerKwargs):
        # print("transforming values --> ", len(init_values) )
        return init_values

    def validate(self, init_values, **fakerKwargs):
        # print("validate values --> ", len(init_values) )
        return init_values

    def improve(self, init_values, **fakerKwargs):
        # print("improve values --> ", len(init_values) )
        return init_values

    def build(self, init_values, **fakerKwargs):
        # print("build values --> ", len(init_values) )
        return init_values


if __name__ == '__main__':
    import jsonpickle

    # body = jsonpickle.decode("""
    #     {
    #        "generator_name":"FakerGenerator",
    #        "column_name":"name",
    #        "parameters":{
    #           "method":"address"
    #        },
    #        "usage":[
    #           "static"
    #        ]
    #     }
    #               """)

    body = jsonpickle.decode("""
        {  
           "generator_name":"FakerGenerator",
           "column_name":"name",
           "parameters":{  
                "api":"Datetime",
                "method":"datetime",
                "date_scope": {"start":1950, "end":1990}
           },
           "usage":[  
              "static"
           ]
        }
                  """)
    gen = FakerGenerator()
    gen.name = body.get('column_name', None)
    gen.rule = body.get('generator_rule', None)
    gen.usage = body.get('usage', None)
    parameters = body.get('parameters', None)
    if parameters:
        gen.api = parameters.get('api', None)
        gen.method = parameters.get('method', None)
        gen.fakerKwargs = parameters.get('date_scope', None)
    result = gen.generate(size=10, population=None)

    print(result)
