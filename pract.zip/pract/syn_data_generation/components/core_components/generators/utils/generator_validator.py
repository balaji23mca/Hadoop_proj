import jsonpickle

import components.core_components.generators.bucketSeriesGenerator
import components.core_components.generators.columnPicker
import components.core_components.generators.constantGenerator
import components.core_components.generators.correlatedGenerator
import components.core_components.generators.dependentColumnGenerator
import components.core_components.generators.fakerGenerator
import components.core_components.generators.listGenerator
import components.core_components.generators.sequencialGenerator
import components.core_components.generators.datetimeGenerator
import components.core_components.generators.derivativeGenerator


def DerivativeGenerator(row):
    return True


def OneToManyGenerator(row):
    return True

def ColumnPicker(row):
    return True


def CorrelatedGenerator(row):
    return True


def ConstantGenerator(row):
    return True


def FixedValuesGenerator(row):
    return True


def BucketSeriesGenerator(row):
    return True


def ListGenerator(row):
    from jsonschema import validate
    #
    # schema = {
    #     "type": "object",
    #     "properties": {
    #         "central_tendency_measure": {"type": "null"},
    #         "column_data_type": {"type": "string"},
    #         "column_index": {"type": "integer"},
    #         "column_length": {"type": "integer"},
    #         "column_name": {"type": "string"},
    #         "correlation": {"type": "null"},
    #         "distribution_type": {"type": "string"},
    #         "generator_name": {"type": "string"},
    #         "parameters": {"type": "object"},
    #         "rule": {"type": ["null", "object"]},
    #         "table_id": {"type": "integer"},
    #         "table_name": {"type": "string"}
    #     },
    # }
    # result = (validate(instance=row, schema=schema))
    return True


def SequencialGenerator(row):  # 'parameters': '{"start":0,"prefix":"id_","max_length":10}'
    return True


def FakerGenerator(row):
    return True

def DateTimeGenerator(row):
    return True

def DependentColumnGenerator(row):
    return True


def validate(row):
    validationResult = False
    switcher = {
        'ColumnPicker': ColumnPicker,
        'ConstantGenerator': ConstantGenerator,
        'BucketSeriesGenerator': BucketSeriesGenerator,
        'ListGenerator': ListGenerator,
        'SequencialGenerator': SequencialGenerator,
        'FakerGenerator': FakerGenerator,
        'DependentColumnGenerator': DependentColumnGenerator,
        'CorrelatedGenerator': CorrelatedGenerator,
        'OneToManyGenerator': OneToManyGenerator,
        'DateTimeGenerator':DateTimeGenerator,
        'DerivativeGenerator': DerivativeGenerator
    }

    try:
        functionObj = switcher.get(row['generator_name'], None)
        if functionObj:
            validationResult = functionObj(row)

    except Exception as e:
        print(e)
        print('Exception occurred while validating for param {}'.format(row))
    return validationResult


if __name__ == '__main__':
    body = jsonpickle.decode("""
            {
              "central_tendency_measure": null,
              "column_data_type": "String",
              "column_index": 2,
              "column_length": 11,
              "column_name": "gender",
              "correlation": null,
              "distribution_type": "choice",
              "generator_name": "ListGenerator",
              "parameters": {
                "a": [
                  "male",
                  "female"
                ],
                "p": [
                  0.6,
                  0.4
                ]
              },
              "rule": "null",
              "table_id": 1,
              "table_name": "persona"
            }
                  """)
    gen = validate(body)
    print(gen)
