import jsonpickle

from components.core_components.generators.utils import generator_factory


def call_ColumnPicker():
    body = jsonpickle.decode("""
        {  
           "generator_name":"ColumnPicker",
           "column_name":"age",
           "parameters":{  
              "table_name":"persona_1004",
              "select_column_name":"age"
           },
           "usage":[  
              "static"
           ]
        }
              """)

    gen = generator_factory.getInstance(body)
    result = gen.generate(size=10, population=None)
    print(result)


def call_ConstantGenerator():
    body = jsonpickle.decode("""
        {  
           "generator_name":"ConstantGenerator",
           "column_name":"value",
           "parameters":{  
              "value":"hello world"
           },
           "usage":[  
              "static"
           ]
        }
              """)

    gen = generator_factory.getInstance(body)
    result = gen.generate(size=10, population=None)
    print(result)


def call_BucketSeriesGenerator():
    body = jsonpickle.decode("""
    {  
       "generator_name":"BucketSeriesGenerator",
       "column_name":"age",
       "distribution_type":"choice",
       "parameters":{
          "a":[  
             "20,30",
             "30,40"
          ],
          "p":[  
             0.5,
             0.5
          ]
       },
       "usage":[  
                          "dynamic"
                       ]
    }
                  """)
    gen = generator_factory.getInstance(body)
    result = gen.generate(size=10, population=None)
    print(result)


def call_ListGenerator():
    body = jsonpickle.decode("""
        {  
           "generator_name":"ListGenerator",
           "column_name":"age",
           "distribution_type":"choice",
           "parameters":{  
              "a":[  
                 "20",
                 "30"
              ],
              "p":[  
                 0.5,
                 0.5
              ]
           },
           "usage":[  
              "dynamic"
           ]
        }
              """)
    gen = generator_factory.getInstance(body)
    result = gen.generate(size=10, population=None)
    print(result)


def call_SequencialGenerator():
    body = jsonpickle.decode("""
                {  
                   "generator_name":"SequencialGenerator",
                   "parameters":{  
                      "start":0,
                      "prefix":"transaction_id_99",
                      "max_length":10
                   },
                   "column_name":"transaction_id",
                   "usage":[  
                      "dynamic"
                   ]
                }
              """)
    gen = generator_factory.getInstance(body)
    result = gen.generate(size=10, population=None)
    print(result)


def call_FakerGenerator():
    body = jsonpickle.decode("""
        {  
           "generator_name":"FakerGenerator",
           "column_name":"name",
           "parameters":{  
              "method":"name"
           },
           "usage":[  
              "static"
           ]
        }
                  """)
    gen = generator_factory.getInstance(body)
    result = gen.generate(size=10, population=None)
    print(result)


def call_DependentColumnGenerator():
    from components.core_components.utils.helper import createContainerObject, initializePopulation, createPopulation;

    body = jsonpickle.decode("""
                    {  
                       "column_name":"job_type",
                       "parameters":{  
                          "conditions":"[('age' >= 20) & ('age' < 40) & ('gender'  == 'female') | ('age' >= 40) & ('age' <= 50) & ('gender'  == 'male')]",
                          "dependent_column":[  
                             "age","gender"
                          ],
                          "choices":[  
                             "business",
                             "non_salaried"
                          ]
                       },
                       "generator_name":"DependentColumnGenerator",
                       "usage":[  
                          "dynamic"
                       ]
                    }
              """)
    gen = generator_factory.getInstance(body)

    ##########helper : start
    population_gen_param = jsonpickle.decode("""
        {  
           "generator_list":[  
              {  
                 "generator_name":"ListGenerator",
                 "column_name":"age",
                 "distribution_type":"choice",
                 "parameters":{  
                    "a":[  
                       20,
                       30,
                       40,
                       50
                    ],
                    "p":[  
                       0.25,
                       0.25,
                       0.25,
                       0.25
                    ]
                 },
                 "usage":[  
                    "dynamic"
                 ]
              },
              {  
                 "generator_name":"ListGenerator",
                 "column_name":"gender",
                 "distribution_type":"choice",
                 "parameters":{  
                    "a":[  
                       "male",
                       "female"
                    ],
                    "p":[  
                       0.50,
                       0.50
                    ]
                 },
                 "usage":[  
                    "dynamic"
                 ]
              }
           ]
        }
              """)

    size = 10
    container = createContainerObject(name="dependent_column_generator_table", size=size, master_seed=1234);

    population = initializePopulation(container=container)

    gen_instance_list = []

    try:
        for gen_param in population_gen_param.get("generator_list"):
            gen_instance = generator_factory.getInstance(gen_param)
            gen_instance_list.append(gen_instance)
    except Exception as e:
        print(e)
    population = createPopulation(gen_instance_list=gen_instance_list, population=population,
                                  size=container.size);
    # print(population.to_dataframe(size))
    ##########helper : ends

    result = gen.generate(size=10, population=population)
    print(result)


if __name__ == '__main__':
    # call_ColumnPicker()
    # call_ConstantGenerator()
    # call_BucketSeriesGenerator()
    call_ListGenerator()
    # call_SequencialGenerator()
    # call_FakerGenerator()
    # call_DependentColumnGenerator()
