import time

import os.path
import seaborn as sn
import matplotlib.pyplot as plt

import components.core_components.cache_management.cache_helper
from components.core_components.utils import utility
from components.core_components.utils.database.db_helper import *
from components.core_components.table_container import container

execution_flag = ["completed", "completed"]


def read_config_table(table_name, dburl, wsprefix=None, filter=None):
    data = read_table(table_name, dburl, wsprefix=None, filter=None)
    return data


# def read_config_table(fname):
#     start_time = time.time()
#     with open(fname) as f:
#         content = f.readlines()
#     # you may also want to remove whitespace characters like `\n` at the end of each line
#     content = [x.strip().split('|') for x in content]
#     logging.debug(' Execution time - in reading config - : %.3f seconds' % (time.time() - start_time))
#
#     return content


def create_container_object(name, size, master_seed, parameter=None,step_duration=None):
    start_time = time.time()
    created_container = container.Container(name, size, master_seed=master_seed, parameter=parameter,step_duration = step_duration)
    logging.debug(' Execution time - in creating container - : %.3f seconds' % (time.time() - start_time))
    return created_container


def initialize_population(container, populationName):
    start_time = time.time()
    gen_param = {
        'generator_name': 'SequencialGenerator',
    }

    ids_gen = components.core_components.generators.utils.generator_factory.getInstance(gen_param)

    if populationName:
        population = container.create_population(name=populationName, size=container.size,
                                                 ids_gen=ids_gen)
    else:
        population = container.create_population(name=container.name, size=container.size,
                                         ids_gen=ids_gen)

    logging.debug(' Execution time - in creating generator objects - : %.3f seconds' % (time.time() - start_time))
    return population


def create_population(gen_instance_list, population, size):
    global execution_flag
    start_time = time.time()
    logging.debug("creating population")

    for i in range(len(gen_instance_list)):
        try:
            logging.debug(' Executing for column name {} using generator {}'.format(gen_instance_list[i].name,
                                                                                   type(gen_instance_list[i])))
            population.create_attribute(gen_instance_list[i].name, init_gen=gen_instance_list[i])

        except Exception as e:
            logging.error(e)
            logging.error(' Exception occurred while executing  for column name {} using generator {}'.format(
                gen_instance_list[i].name,
                type(gen_instance_list[i])))
            execution_flag = ["failed", type(e).__name__]
            return
            # exception_gen = components.core_components.generators.constantGenerator.ConstantGenerator(
            #     value=00,
            #     name=gen_instance_list[i].name)
            # population.create_attribute(exception_gen.name, init_gen=exception_gen)

    logging.debug(' Execution time - in creating population - : %.3f seconds' % (time.time() - start_time))
    return population


def generate_graph(respDataframe, gen_instance_list):
  logging.debug('----------- starting generation of graph----------' )
  start_time = time.time()
  df = respDataframe
  dict = {}
  list = []
  for j in range(len(gen_instance_list)):

      if gen_instance_list[j].get('generator_name') == "ListGenerator" and gen_instance_list[j].get('distribution_type') == "choice":

          #dict['column_name'] = gen_instance_list[i].column_name
          #param = gen_instance_list[i].parameters
          # dict['a'] = param['a']
          # dict['p'] = param['p']
          # dict['distribution_type'] = gen_instance_list[i].distribution_type
          # list.append(dict)
          import numpy as np
          #import matplotlib.pyplot as plt

          # data to plot
          n_groups = len(gen_instance_list[j].get('parameters').get('p'))

          actual_martial_status_distribution = gen_instance_list[j].get('parameters').get('p')

          x = df[gen_instance_list[j].get('column_name')].value_counts().to_frame()
          y = x.iloc[0:len(x), 0]
          new_l = []
          for i in range(len(x)):
              final_y1 = y[i] / sum(y)
              new_l.append(final_y1)
          observed_martial_status_distribution = new_l

          # create plot
          fig, ax = plt.subplots()
          index = np.arange(n_groups)
          bar_width = 0.25
          opacity = 0.7

          rects1 = plt.bar(index, actual_martial_status_distribution, bar_width,
                           alpha=opacity,
                           color='b',
                           label='Actual distribution_type')

          rects2 = plt.bar(index + bar_width, observed_martial_status_distribution, bar_width,
                           alpha=opacity,
                           color='g',
                           label='Observed distribution_type')

          def autolabel(rects):
              for rect in rects:
                  height = rect.get_height()
                  ax.text(rect.get_x() + rect.get_width() / 2., 1.0 * height,
                          '%.2f' % float(height),
                          ha='center', va='bottom')

          autolabel(rects1)
          autolabel(rects2)

          plt.xlabel('Attribute distribution_type')
          plt.ylabel('Distributin ranges')
          plt.title('Comparison of attribute of persona')
          plt.xticks(index + bar_width, gen_instance_list[j].get('parameters').get('a'), horizontalalignment='right', rotation = 45)#('Married', 'Unmarried'))
          plt.legend()

          plt.tight_layout()
          # plt.show()
          logging.debug('-----------> created graph for column {}'.format(gen_instance_list[j].get('column_name')))
          plt.savefig(os.path.normpath(os.path.join(os.path.dirname(__file__), '../../../../output/graphs/')) +'/'+ gen_instance_list[j].get('column_name')+'_'+gen_instance_list[j].get('table_name')+'_ActualVsExpected')
          plt.clf()
      if gen_instance_list[j].get('generator_name') == "BucketSeriesGenerator" and gen_instance_list[j].get('distribution_type') == "choice":
          a = gen_instance_list[j].get('parameters').get('a')#a = ["13,30", "30,40", "40,50", "50,60"]
          # "p": [0.5, 0.2, 0.2, 0.1]}
          new_lis = []
          n_list = []
          for i in range(len(a)):
              res = a[i].split(",")
              for k in range(2):
                  new_lis.append(int(res[k]))

          def bucket_gen_cal(feat):

              t = 0
              #x = 0
              for i in range(len(a)):
                  x = df[(df[feat] > new_lis[t]) & (df[feat] < new_lis[t + 1])].count() / (
                      df[feat].count())
                  n_list.append(x[feat])
                  t = t + 2
          bucket_gen_cal(gen_instance_list[j].get('column_name'))

          n_groups = len(gen_instance_list[j].get('parameters').get('p'))

          actual_martial_status_distribution = gen_instance_list[j].get('parameters').get('p')

          #x = df[gen_instance_list[j].get('column_name')].value_counts().to_frame()
          #y = x.iloc[0:len(x), 0]
          #new_l = []
          #for i in range(len(x)):
           #   final_y1 = y[i] / sum(y)
            #  new_l.append(final_y1)
          observed_martial_status_distribution = n_list

          # create plot
          fig, ax = plt.subplots()
          index = np.arange(n_groups)
          bar_width = 0.25
          opacity = 0.7

          rects1 = plt.bar(index, actual_martial_status_distribution, bar_width,
                           alpha=opacity,
                           color='b',
                           label='Actual distribution_type')

          rects2 = plt.bar(index + bar_width, observed_martial_status_distribution, bar_width,
                           alpha=opacity,
                           color='g',
                           label='Observed distribution_type')

          def autolabel(rects):
              for rect in rects:
                  height = rect.get_height()
                  ax.text(rect.get_x() + rect.get_width() / 2., 1.0 * height,
                          '%.2f' % float(height),
                          ha='center', va='bottom')

          autolabel(rects1)
          autolabel(rects2)

          plt.xlabel('Attribute distribution_type')
          plt.ylabel('Distributin ranges')
          plt.title('Comparison of attribute of persona')
          plt.xticks(index + bar_width, gen_instance_list[j].get('parameters').get('a'), horizontalalignment='right',
                     rotation=45)  # ('Married', 'Unmarried'))
          plt.legend()

          plt.tight_layout()
          # plt.show()
          logging.debug('-----------created graph for column {}'.format(gen_instance_list[j].get('column_name')))
          plt.savefig(os.path.normpath(os.path.join(os.path.dirname(__file__), '../../../../output/graphs/')) + '/' +
                      gen_instance_list[j].get('column_name')+"_"+gen_instance_list[j].get('table_name')+'_ActualVsExpected')
          plt.clf()
  logging.debug('-----------generation of graph completed')
  # for i in range(len(gen_instance_list)):
  #     print(gen_instance_list[i]) # todo : create list of dict with keys column_name , distribution_type ,  parameters
  logging.debug(' Execution time - in applying rule - : %.3f seconds' % (time.time() - start_time))

def EDA_graphs(data, meta_config_list):


    plt.style.use('seaborn-whitegrid')

    def plot_cat_graph(data):

        col_names = data.select_dtypes(exclude=['int', 'float']).columns.tolist()
        #num_cols = col_names.remove("person_id")
        fig, ax = plt.subplots(len(col_names), figsize=(5, 22))
        fig.tight_layout()
        for i, col_val in enumerate(col_names):
            sn.countplot(data[col_val], ax=ax[i])
            # ax[i].set_title('Freq dist '+col_val, fontsize=10)
            ax[i].set_xlabel(col_val, fontsize=8)
            ax[i].set_ylabel('Count', fontsize=8)

        fig.show()

    def univariate_numeric_graphs(data, feature, graph_type,table_name):
        if graph_type == "Hist_Graph":
            # Histogram
            # sn.distplot(data[feature])
            plt.hist(data[feature], 5, histtype='bar',
                     align='mid', color='c', edgecolor='black')
            #plt.show()
            plt.savefig(os.path.normpath(os.path.join(os.path.dirname(__file__), '../../../../output/graphs/')) + '/' +feature+"_"++table_name+"_"
                        "Hist_Graph_EDA")
            plt.clf()
        elif graph_type == 'Box_Graph':
            # sn.boxplot(data[feature])
            fig = plt.figure()
            ax = fig.add_subplot(1, 1, 1)
            # Variable
            # ax.boxplot(data[feature])
            plt.boxplot(data[feature], patch_artist=True, notch='True')
            plt.savefig(os.path.normpath(os.path.join(os.path.dirname(__file__), '../../../../output/graphs/')) + '/' +feature+"_"++table_name+"_"
                        "Box_Graph_EDA")
            plt.clf()
            #plt.show()

        elif graph_type == "Line_Graph":
            values = data[feature]
            plt.plot(values)
            plt.savefig(os.path.normpath(os.path.join(os.path.dirname(__file__), '../../../../output/graphs/')) + '/' +feature+"_"++table_name+"_"
                        "Line_Graph_EDA")
            plt.clf()
            #plt.show()
        else:
            pass
            # print("invalid data")

    def univariate_categoric_graphs(data, feature, graph_type,table_name):
        if graph_type == "Bar_Graph":
            # bar plot
            ret_1 = sn.countplot(data[feature])
            #ax_1 = sn.boxplot(x=data[feature1], y=data[feature2], data=data)
            #biva_fig = ax_1.get_figure()
            #biva_fig.savefig("gender_salary_niladri_modified.png")
            ret_fig = ret_1.get_figure()
            plt.xticks(rotation=45, ha='right')
            ret_fig.savefig(os.path.normpath(os.path.join(os.path.dirname(__file__), '../../../../output/graphs/')) + '/' +feature+"_"+table_name+"_"
                        "Bar_Graph")
            plt.clf()
            #plt.show()
        elif graph_type == 'Box_Graph':
            ret_1 = sn.boxplot(data[feature])
            ret_fig = ret_1.get_figure()
            ret_fig.savefig(os.path.normpath(os.path.join(os.path.dirname(__file__),
                                                          '../../../../output/graphs/')) + '/' + feature + "_" + table_name + "_"
                                                            "Box_Graph")
            plt.clf()
#Pie graph is not complete
        elif graph_type == 'Pie_Graph':
            #values = get_actual_distribution(data, feature)
            # values = get_actual_distribution(data,'gender')
            colors = ['b', 'g', 'r', 'c', 'm', 'y']
            labels = ['cat1', 'cat2', 'cat3']
            # explode = (0.2, 0, 0, 0, 0, 0)
            #plt.pie(values, colors=colors,
             #       autopct='%1.1f%%',
              #      counterclock=False, shadow=True)
            plt.title('Population Density Index')
            plt.legend(labels, loc=3)
            #plt.show()
            plt.savefig(os.path.normpath(os.path.join(os.path.dirname(__file__), '../../../../output/graphs/')) + '/' +feature+"_"+ table_name + "_"
                        "Pie_Graph_EDA")
            plt.clf()

        else:
            pass
            # print("invalid data")

    def bivariate_graphs(data, feature1, feature2, graph_type, table_name):
        if graph_type == "Violin_Graph":
            sn.violinplot(data[feature1], data[feature2])  # Variable Plot
            sn.despine()
        elif graph_type == "Box_Graph":
            ax_1 = sn.boxplot(x=data[feature1], y=data[feature2], data=data)
            biva_fig = ax_1.get_figure()
            biva_fig.savefig(os.path.normpath(os.path.join(os.path.dirname(__file__), '../../../../output/graphs/')) + '/' +feature1+"Vs"+feature2+"_"+ table_name)
        else:
            pass
            # print("invalid data")

    #plot_cat_graph(data)

    if meta_config_list:
        for i in range(len(meta_config_list)):
            if meta_config_list[i].get('graph_parameters', None):
                for j in range(len(eval(meta_config_list[i].get('graph_parameters', None)))):
                    l = len(eval(meta_config_list[i].get('graph_parameters', None))[j])
                    if l == 1:
                        graph_type_sample = eval(meta_config_list[i].get('graph_parameters', None))[0].get('graph_type')
                        if (data[meta_config_list[i].get('column_name', None)].dtype == np.int64 or data[
                            meta_config_list[i].get('column_name', None)].dtype == np.float64) \
                                and graph_type_sample != 'Config_Validator':
                            for dict in eval(meta_config_list[i].get('graph_parameters', None)):
                                univariate_numeric_graphs(data, meta_config_list[i].get('column_name', None),
                                                          dict.get('graph_type', None),meta_config_list[i].get('table_name', None))

                        elif graph_type_sample != 'Config_Validator':
                            for dict in eval(meta_config_list[i].get('graph_parameters', None)):
                                univariate_categoric_graphs(data, meta_config_list[i].get('column_name', None),
                                                            dict.get('graph_type', None),meta_config_list[i].get('table_name', None))

                    if l == 2:
                        bivariate_graphs(data, meta_config_list[i].get('column_name', None),dict.get('y_axis',None),
                                         dict.get('graph_type', None), meta_config_list[i].get('table_name', None))
            # elif meta_config_list[i].get('graph_parameters',None):
            #     l = len(eval(meta_config_list[i].get('graph_parameters',None)))
            #     if l == 3:
            #         bivariate_graphs(data, meta_config_list[i].get('column_name', None),
            #                                       dict.get('graph_type', None),meta_config_list[i].get('table_name', None))

    # univariate_numeric_graphs(data, "salary", graph_type='hist_plot')

    #univariate_categoric_graphs(data, "marital_status", graph_type= 'bar_plot')
    #bivariate_graphs(data, "salary", "gender", graph_type='box_plot')



def apply_rules(respDataframe, gen_instance_list):
    start_time = time.time()
    df = respDataframe
    try:
        for i in range(len(gen_instance_list)):
            if (gen_instance_list[i].rule):
                word = gen_instance_list[i].rule
                # word = eval(word)
                col = df[word['dependent_column']]
                conditions = (word['conditions'])
                for vals in col:
                    arrt = 'getattr(df, "{}")'.format(vals)
                    word1 = "'getattr(df, \"{}\")'".format(vals)
                    word2 = "getattr(df, \"{}\")".format(vals)
                    conditions = conditions.replace(vals, arrt).replace(word1, word2)
                df.loc[eval(conditions), gen_instance_list[i].name] = word['action']
        logging.debug(' Execution time - in applying rule - : %.3f seconds' % (time.time() - start_time))
    except Exception as e:
        logging.debug('Exception occurred in applyRules {}'.format(e))

    finally:
        logging.debug('----------- apply_rules execution time : %.3f seconds' % (time.time() - start_time))
    return df


def apply_outliers(respDataframe, gen_instance_list):
    start_time = time.time()
    df = respDataframe
    data = df
    data = data._get_numeric_data()
    return generate_outliers(df, data, 0.1)


def get_execution_flag():
    global execution_flag
    return execution_flag


def set_execution_flag(status=["completed", "completed"]):
    global execution_flag
    execution_flag = status


def generate_outliers(df, numeric_col, per):
    from numpy.random import seed
    from numpy import mean
    from numpy import std
    import numpy as np
    import pandas as pd
    from random import sample

    # seed the random number generator
    seed(2019)
    for data in numeric_col:
        del df[data]
        name = data
        data = numeric_col[data]
        data_mean, data_std = mean(data), std(data)
        # identify outliers
        cut_off = data_std * 3
        lower, upper = data_mean - cut_off, data_mean + cut_off

        # create random index
        rindex = np.array(sample(range(len(data)), int(len(data) * per)))
        data.iloc[rindex] = np.random.choice([lower - (np.random.uniform(1, 10)), upper + (np.random.uniform(1, 10))],
                                             len(rindex), p=[0.3, 0.7])

        # identify outliers
        outliers = [x for x in data if x < lower or x > upper]
        print('Identified outliers: %d' % len(outliers))
        # returning dataframe
        appending_col = pd.DataFrame({name: data})
        df = df.join(appending_col)
    return df


def apply_missing_values(respDataframe):
    start_time = time.time()
    df = respDataframe
    # generate_missing_values(df.age)
    col_list = []
    for col in respDataframe:
        col_list.append(df[col])
    return pd.DataFrame(list(map(generate_missing_values, col_list))).transpose()
    # list1 = list(map(generate_missing_values,[df.age,df.marital_status] ))


def generate_missing_values(col, per=0.2):
    import numpy as np
    from random import sample
    # create random index
    rindex = np.array(sample(range(len(col)), int(len(col) * per)))
    col.iloc[rindex] = "NA"
    print('******Identified NA*****:', col.isna().sum())
    return (col)


def save_dataframe(container, dataframe, wsprefix, inputdburl, outputdburl):
    start_time = time.time()

    logging.debug(' Execution time - in saving cache data - : %.3f seconds' % (time.time() - start_time))

    if outputdburl:
        utility.save_to_db(wsprefix, dataframe, container.name, outputdburl,use_async = False)

    else:
        container.save_dataframe(
            dataframe=dataframe,
            fileName=container.name,
            output_folder="output/example_scenario",
            delete_existing_logs=True
        )

    logging.debug(' Execution time - in saving dataframe - : %.3f seconds' % (time.time() - start_time))
