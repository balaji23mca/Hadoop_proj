import jsonpickle
import datetime
import components.core_components.generators.bucketSeriesGenerator
import components.core_components.generators.columnPicker
import components.core_components.generators.constantGenerator
import components.core_components.generators.correlatedGenerator
import components.core_components.generators.dependentColumnGenerator
import components.core_components.generators.fakerGenerator
import components.core_components.generators.listGenerator
import components.core_components.generators.sequencialGenerator
import components.core_components.generators.oneToManyGenerator
import components.core_components.generators.derivativeGenerator
import components.core_components.generators.datetimeGenerator
import logging


def DerivativeGenerator(body,initiating_population=None):
    gen = components.core_components.generators.derivativeGenerator.DerivativeGenerator()
    gen.name = body.get('column_name', None)
    gen.column_name = body.get('column_name', None)
    gen.rule = body.get('generator_rule', None)
    gen.usage = body.get('usage', None)
    parameters = body.get('parameters', None)
    if parameters and isinstance(parameters, dict):
        try:
            gen.table_name = parameters.get('table_name', None)
            #gen.derived_column_name = parameters.get('derived_column_name', None)
            gen.derivative_columns = parameters.get('derivative_columns', None)
            gen.derivative_factors = parameters.get('derivative_factors', None)
            gen.operator = parameters.get('operator',None)
        except Exception as e:
            logging.error(e)

    elif parameters and isinstance(parameters, str):
        try:
            parameters = jsonpickle.decode(parameters)
            gen.table_name = parameters.get('table_name', None)
            #gen.derived_column_name = parameters.get('derived_column_name', None)
            gen.derivative_columns = parameters.get('derivative_columns', None)
            gen.derivative_factors = parameters.get('derivative_factors', None)
            gen.operator = parameters.get('operator',None)
        except Exception as e:
            logging.error(e)

    if initiating_population:
        gen.initiating_population = initiating_population

    return gen


def OneToManyGenerator(row,initiating_population=None):
    gen = components.core_components.generators.oneToManyGenerator.OneToManyGenerator()
    gen.name = row.get('column_name', None)
    return gen


def ColumnPicker(row,initiating_population=None):
   gen = components.core_components.generators.columnPicker.ColumnPicker()
   gen.name = row.get('column_name', None)
   gen.rule = row.get('generator_rule', None)
   gen.usage = row.get('usage', None)

   parameters = row.get('parameters', None)

   if parameters and isinstance(parameters, dict):
       try:
           gen.table_name = parameters.get('table_name', None)
           gen.column_name = parameters.get('select_column_name', None)
           gen.key = parameters.get('key', None)
       except Exception as e:
           print(e)

   elif parameters and isinstance(parameters, str):
       try:
           parameters = jsonpickle.decode(parameters)
           gen.table_name = parameters.get('table_name', None)
           gen.column_name = parameters.get('select_column_name', None)
           gen.key = parameters.get('key', None)
       except Exception as e:
           print(e)

   if initiating_population:
        gen.initiating_population = initiating_population

   return gen


def DateTimeGenerator(row,initiating_population=None):
   gen = components.core_components.generators.datetimeGenerator.DateTimeGenerator()
   gen.name = row.get('column_name', None)
   gen.rule = row.get('generator_rule', None)
   gen.usage = row.get('usage', None)

   parameters = row.get('parameters', None)

   if parameters and isinstance(parameters, dict):
       try:
           gen.table_name = parameters.get('table_name', None)
           gen.column_name = parameters.get('select_column_name', None)
           gen.method = parameters.get('method', None)
           gen.seedyear = parameters.get('seedyear', datetime.datetime.now().year)
           gen.days_diff = parameters.get('number_of_days', 0)
           gen.hours_diff = parameters.get('number_of_hours', 0)
           start_date = parameters.get('start_date', None)
           end_date = parameters.get('end_date', None)
           if start_date is None or start_date == '':
               gen.start_date = datetime.datetime.now()
           else:
               gen.start_date = datetime.datetime.strptime(start_date, "%Y/%m/%d")
           if end_date is None or end_date == '':
               gen.end_date = datetime.datetime.now()
           else:
               gen.end_date = datetime.datetime.strptime(end_date, "%Y/%m/%d")
       except Exception as e:
           print(e)

   elif parameters and isinstance(parameters, str):
       try:
           parameters = jsonpickle.decode(parameters)
           gen.table_name = parameters.get('table_name', None)
           gen.column_name = parameters.get('select_column_name', None)
           gen.method = parameters.get('method', None)
           gen.seedyear = parameters.get('seedyear', datetime.datetime.now().year)
           gen.days_diff = parameters.get('number_of_days', 0)
           gen.hours_diff = parameters.get('number_of_hours', 0)
           # gen.start_date = parameters.get('start_date', None)
           # gen.end_date = parameters.get('end_date', None)
           start_date = parameters.get('start_date', None)
           end_date = parameters.get('end_date', None)
           if start_date is None:
               gen.start_date = datetime.datetime.now()
           else:
               gen.start_date = datetime.datetime.strptime(start_date, "%Y/%m/%d")
           if end_date is None:
               gen.end_date = datetime.datetime.now()
           else:
               gen.end_date = datetime.datetime.strptime(end_date, "%Y/%m/%d")
       except Exception as e:
           print(e)

   if initiating_population:
        gen.initiating_population = initiating_population

   return gen


def CorrelatedGenerator(row,initiating_population=None):
   gen = components.core_components.generators.correlatedGenerator.CorrelatedGenerator()
   gen.name = row.get('column_name', None)
   gen.rule = row.get('generator_rule', None)
   gen.usage = row.get('usage', None)
   parameters = row.get('parameters', None)
   if parameters:
       gen.method = parameters.get('method', None)
       gen.feature1 = parameters.get('feature1', None)
       gen.act_low = parameters.get('act_low', None)
       gen.act_high = parameters.get('act_high',None)
       gen.Exp_corr = parameters.get('Exp_corr',None)


   return gen

def ConstantGenerator(row,initiating_population=None):
    gen = components.core_components.generators.constantGenerator.ConstantGenerator()
    gen.name = row.get('column_name', None)
    gen.rule = row.get('generator_rule', None)
    gen.usage = row.get('usage', None)

    parameters = row.get('parameters', None)

    if parameters and isinstance(parameters, dict):
        try:
            gen.value = parameters.get('value', None)
        except Exception as e:
            print(e)

    elif parameters and isinstance(parameters, str):
        try:
            parameters = jsonpickle.decode(parameters)
            gen.value = parameters.get('value', None)
        except Exception as e:
            print(e)
    return gen


def FixedValuesGenerator(row,initiating_population=None):
    gen = components.core_components.generators.fixedValuesGenerator.FixedValuesGenerator()
    gen.name = str(row['column_name'])
    gen.method = str(row['parameters'])

    return gen


def BucketSeriesGenerator(row,initiating_population=None):
    gen = components.core_components.generators.bucketSeriesGenerator.BucketSeriesGenerator()
    gen.name = row.get('column_name', None)
    gen.rule = row.get('generator_rule', None)
    gen.method = row.get('distribution_type', None)

    gen.usage = row.get('usage', None)
    parameters = row.get('parameters', None)
    if parameters and isinstance(parameters, dict):
        try:
            gen.list_generator_parameters = parameters
        except Exception as e:
            print(e)

    elif parameters and isinstance(parameters, str):
        try:
            parameters = jsonpickle.decode(parameters)
            gen.list_generator_parameters = parameters
        except Exception as e:
            print(e)

    return gen


def ListGenerator(row,initiating_population=None):
    gen = components.core_components.generators.listGenerator.ListGenerator()
    gen.name = row.get('column_name', None)
    gen.rule = row.get('generator_rule', None)
    gen.method = row.get('distribution_type', None)

    gen.usage = row.get('usage', None)
    gen.seed = row.get('seed', 1)
    parameters = row.get('parameters', None)
    for key in parameters.keys():
        if key == 'ListofValues':
            parameters['a'] = parameters[key]
            del parameters[key]
        if key == 'Probability':
            parameters['p'] = parameters[key]
            del parameters[key]

    if parameters and isinstance(parameters, dict):
        try:
            gen.list_generator_parameters = parameters
        except Exception as e:
            print(e)
    elif parameters and isinstance(parameters, str):
        try:
            parameters = jsonpickle.decode(parameters)
            gen.list_generator_parameters = parameters
        except Exception as e:
            print(e)
    return gen


def SequencialGenerator(row,initiating_population=None):  # 'parameters': '{"start":0,"prefix":"id_","max_length":10}'
    gen = components.core_components.generators.sequencialGenerator.SequencialGenerator()
    gen.name = row.get('column_name', None)
    gen.rule = row.get('generator_rule', None)
    gen.usage = row.get('usage', None)
    parameters = row.get('parameters', None)

    if parameters and isinstance(parameters, dict):
        try:
            gen.counter = parameters.get('start', 0)
            gen.prefix = parameters.get('prefix', "id_")
            gen.max_length = parameters.get('max_length', 5)
        except Exception as e:
            print(e)

    elif parameters and isinstance(parameters, str):
        try:
            parameters = jsonpickle.decode(parameters)
            gen.counter = parameters.get('counter', 0)
            gen.prefix = parameters.get('prefix', "id_")
            gen.max_length = parameters.get('max_length', 5)
        except Exception as e:
            print(e)

    return gen


def FakerGenerator(row,initiating_population=None):
    gen = components.core_components.generators.fakerGenerator.FakerGenerator(method = str(row['parameters']))
    gen.name = row.get('column_name', None)
    gen.rule = row.get('generator_rule', None)
    gen.usage = row.get('usage', None)
    parameters = row.get('parameters', None)

    if parameters and isinstance(parameters, dict):
        try:
            gen.api = parameters.get('api', None)
            gen.method = parameters.get('method', None)
            if parameters.get('date_scope'):
                gen.fakerKwargs = parameters.get('date_scope', None)
        except Exception as e:
            print(e)

    elif parameters and isinstance(parameters, str):
        try:
            parameters = jsonpickle.decode(parameters)
            gen.method = parameters.get('method', None)
        except Exception as e:
            print(e)

    return gen



def DependentColumnGenerator(row,initiating_population=None):
    gen = components.core_components.generators.dependentColumnGenerator.DependentColumnGenerator()
    gen.name = row.get('column_name', None)
    parameters = row.get('parameters', None)

    if parameters and isinstance(parameters, dict):
        try:
            gen.oldColumn = parameters.get('dependent_column', None)
            gen.choices = parameters.get('choices', None)
            gen.conditions = parameters.get('conditions', None)
        except Exception as e:
            print(e)
    elif parameters and isinstance(parameters, str):
        try:
            parameters = jsonpickle.decode(parameters)
            gen.oldColumn = parameters.get('dependent_column', None)
            gen.choices = parameters.get('choices', None)
            gen.conditions = parameters.get('conditions', None)
        except Exception as e:
            print(e)

    if initiating_population:
        gen.initiating_population = initiating_population
    return gen


def getInstance(row,initiating_population=None):
    switcher = {
        'ColumnPicker': ColumnPicker,
        'ConstantGenerator': ConstantGenerator,
        'BucketSeriesGenerator': BucketSeriesGenerator,
        'ListGenerator': ListGenerator,
        'SequencialGenerator': SequencialGenerator,
        'FakerGenerator': FakerGenerator,
        'DependentColumnGenerator': DependentColumnGenerator,
        'CorrelatedGenerator': CorrelatedGenerator,
        'OneToManyGenerator': OneToManyGenerator,
        'DateTimeGenerator': DateTimeGenerator,
        'DerivativeGenerator': DerivativeGenerator
    }
    try:
        functionObj = switcher.get(row['generator_name'], None)
        gen = functionObj(row,initiating_population=initiating_population)

    except Exception as e:
        print(e)
        print('Exception occurred in getInstance for param {}'.format(row))
        gen = components.core_components.generators.constantGenerator.ConstantGenerator(
            value="Exception in creating generator : {}".format(row['generator_name']),
            name=row['column_name'])
    return gen


if __name__ == '__main__':
    body = jsonpickle.decode("""
    {  
       "generator_name":"BucketSeriesGenerator",
       "column_name":"age",
       "distribution_type":"choice",
       "parameters":{
          "a":[  
             "20,30",
             "30,40"
          ],
          "p":[  
             0.5,
             0.5
          ]
       },
       "usage":[  
                          "dynamic"
                       ]
    }
                  """)
    gen = getInstance(body)
    res = gen.generate(size=10, population=None)
    print(res)