import json
import logging

from components.core_components.generators.generator import Generator
from components.core_components.generators.utils.generator_utility import build_ids


class SequencialGenerator(Generator):
    """
    Generator of sequencial unique values
    """

    def __init__(self, name=None, start=0, prefix="id_", max_length=5, rule=None, usage=None):
        Generator.__init__(self)
        self.rule = rule
        self.counter = int(start)
        self.prefix = prefix
        self.max_length = max_length
        self.name = name
        self.usage = usage

    def generate(self, size, population):
        # forcing size as int, also making sure we never get floating point
        # values in ids (can happen if size results from some scaling)
        size_i = int(size)
        #        size_i = size
        values = build_ids(size_i, self.counter, self.prefix, self.max_length)
        self.counter += size_i
        return values

    def description(self):
        return {
            "type": "SequencialGenerator",
            "prefix": self.prefix,
            "max_length": self.max_length
        }

    def lookup(self, condition, **fakerKwargs):
        # print("-- lookup values --")
        return condition

    def transform(self, init_values, **fakerKwargs):
        # print("transforming values --> ", len(init_values) )
        return init_values

    def validate(self, init_values, **fakerKwargs):
        # print("validate values --> ", len(init_values) )
        return init_values

    def improve(self, init_values, **fakerKwargs):
        # print("improve values --> ", len(init_values) )
        return init_values

    def build(self, init_values, **fakerKwargs):
        # print("build values --> ", len(init_values) )
        return init_values

    def save_to(self, output_file):
        logging.debug("saving sequencial generator to {}".format(output_file))

        state = {
            "counter": int(self.counter),
            "prefix": self.prefix,
            "max_length": self.max_length
        }
        with open(output_file, "w") as outf:
            json.dump(state, outf, indent=4)

    @staticmethod
    def load_from(input_file):
        logging.debug("loading generator from {}".format(input_file))

        with open(input_file, "r") as inf:
            state = json.load(inf)

            return SequencialGenerator(
                start=state["counter"],
                prefix=state["prefix"],
                max_length=state["max_length"])

if __name__ == '__main__':
    import jsonpickle

    body = jsonpickle.decode("""
                {  
                   "generator_name":"SequencialGenerator",
                   "parameters":{  
                      "start":1001,
                      "prefix":"",
                      "max_length":4
                   },
                   "column_name":"transaction_id",
                   "usage":[  
                      "dynamic"
                   ]
                }
              """)

    gen = SequencialGenerator()
    gen.name = body.get('column_name', None)
    gen.rule = body.get('generator_rule', None)
    gen.usage = body.get('usage', None)
    parameters = body.get('parameters', None)
    if parameters:
        gen.counter = parameters.get('start', 0)
        gen.prefix = parameters.get('prefix', "id_")
        gen.max_length = parameters.get('max_length', 5)

    result = gen.generate(size=10, population=None)

    print(result)
