from components.core_components.generators.generator import Generator
import numpy as np

class ConstantGenerator(Generator):
    def __init__(self, value="", name=None, rule=None, usage=None):
        Generator.__init__(self)
        self.value = value
        self.name = name
        self.rule = rule
        self.usage = usage

    def generate(self, size, population=None):
        result = [self.value] * size
        for i in range(len(result)):
            if isinstance(result[i], str):
                tmp_array = result[i].split(',')
                if len(tmp_array) > 1:
                    result[i] = np.random.choice(tmp_array).replace('(', '').replace(')', '')
        return result


if __name__ == '__main__':
    import jsonpickle

    body = jsonpickle.decode("""
        {  
           "generator_name":"ConstantGenerator",
           "column_name":"value",
           "parameters":{  
              "value":"hello world"
           },
           "usage":[  
              "static"
           ]
        }
              """)

    gen = ConstantGenerator()
    gen.name = body.get('column_name', None)
    gen.rule = body.get('generator_rule', None)
    gen.usage = body.get('usage', None)
    parameters = body.get('parameters', None)
    if parameters:
        gen.value = parameters.get('value', None)

    result = gen.generate(size=10, population=None)

    print(result)
