import logging
import os

app_path = ""
def setup_logging():
    global app_path
    tp = os.path.dirname(__file__)
    tp2 = os.path.dirname(tp)
    tp3 = os.path.dirname(tp2)
    app_path = os.path.dirname(tp3)
    log_output_folder = os.path.join(app_path, "output", "logs")
    if not os.path.exists(log_output_folder):
        os.makedirs(log_output_folder)

    output_file = os.path.join(log_output_folder, "{}.log".format("app"))
    for handler in logging.root.handlers[:]:
        logging.root.removeHandler(handler)
    logging.basicConfig(filename=output_file,
                    filemode='a',
        format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
        level=logging.INFO)

    # set up logging to console
    console = logging.StreamHandler()
    console.setLevel(logging.DEBUG)
    # set a format which is simpler for console use
    formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
    console.setFormatter(formatter)
    # add the handler to the root logger
    logging.getLogger('').addHandler(console)

    logger = logging.getLogger(__name__)