import logging
import threading
import os
import pandas as pd
import numpy as np
from flask_restplus import abort
from pandas import read_sql_table
from sqlalchemy import create_engine, text, MetaData
from components import rest_app_settings
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker


def check_db_connection(dburl):
    if dburl:
        if isinstance(dburl, str):
            uri = dburl

        if isinstance(dburl, dict):
            uri = dburl.get("uri", None)

        if uri:
            try:
                engine = create_engine(uri, echo=False)
                if engine.connect():
                    responseStr = rest_app_settings.CONNECTION_SUCCESSFUL
                engine.dispose()
                return responseStr

            except Exception as e:
                logging.error("Exception occurred at check_db_connection")
                raise e
        else:
            return rest_app_settings.CONNECTION_FAILED
    else:
        abort(500, "Input DB not specified")


def has_table(table_name, dburl, wsprefix = None):
    is_table_exists = False
    if isinstance(dburl, str):
        uri = dburl

    elif isinstance(dburl, dict):
        uri = dburl.get("uri", None)

    engine = create_engine(uri, echo=False)
    if wsprefix:
        is_table_exists = engine.dialect.has_table(engine, wsprefix + '_' + table_name)
    else:
        is_table_exists = engine.dialect.has_table(engine, table_name)

    return is_table_exists


def drop_table(table_name, dburl, wsprefix=None):
    import warnings
    warnings.filterwarnings("ignore")

    # is_table_exists = False
    if isinstance(dburl, str):
        uri = dburl

    elif isinstance(dburl, dict):
        uri = dburl.get("uri", None)

    engine = create_engine(uri, echo=False)
    if wsprefix:
        is_table_exists = engine.dialect.has_table(engine, wsprefix + '_' + table_name)
    else:
        is_table_exists = engine.dialect.has_table(engine, table_name)

    if is_table_exists:
        try:
            logging.debug('deleting table {}'.format(table_name))
            base = declarative_base()
            metadata = MetaData(engine, reflect=True)
            table = metadata.tables.get(table_name)
            base.metadata.drop_all(engine, [table], checkfirst=True)
            return False
        except Exception as e:
            logging.error("Exception occurred at drop_table".format(e))
            return True



def truncate_table(table_name, dburl, wsprefix=None):
    import warnings
    warnings.filterwarnings("ignore")

    # is_table_exists = False
    if isinstance(dburl, str):
        uri = dburl

    elif isinstance(dburl, dict):
        uri = dburl.get("uri", None)

    engine = create_engine(uri, echo=False)
    if wsprefix:
        is_table_exists = engine.dialect.has_table(engine, wsprefix + '_' + table_name)
    else:
        is_table_exists = engine.dialect.has_table(engine, table_name)

    if is_table_exists:
        try:
            logging.debug('deleting table {}'.format(table_name))
            Session = sessionmaker(bind=engine)
            session = Session()
            session.execute('''TRUNCATE TABLE {}'''.format(table_name))
            session.commit()
            session.close()
        except Exception as e:
            logging.error("Exception occurred at truncate_table".format(e))
            return True

def get_table_size(table_name, dburl, wsprefix = None):
    if isinstance(dburl, str):
        uri = dburl

    elif isinstance(dburl, dict):
        uri = dburl.get("uri", None)

    if wsprefix:
        data = read_sql_table(wsprefix + '_' + table_name, uri)
    else:
        data = read_sql_table(table_name, uri)

    return len(data.index)


def read_table(table_name, dburl, wsprefix = None,filter = None):
    if isinstance(dburl, str):
        uri = dburl

    elif isinstance(dburl, dict):
        uri = dburl.get("uri", None)

    if wsprefix:
        data = read_sql_table(wsprefix + '_' + table_name, uri)
    else:
        data = read_sql_table(table_name, uri)

    if filter:
        for key, values in filter.items():
            data = data[data[key].isin(values)]
    return data


def save_data(wsprefix, data, uri):
    df = pd.DataFrame.from_records(data.get("list", None))
    table_name = data.get("table_name", None)
    save_to_db(wsprefix, df, table_name, uri)


def save_to_db(wsprefix, df, table_name, dburl, use_async=True,if_exists='replace'):
    logging.debug('saving {} rows in {} table.'.format(len(df),table_name ))
    if isinstance(dburl, str):
        uri = dburl

    elif isinstance(dburl, dict):
        uri = dburl.get("uri", None)

    if use_async:
        thread = threading.Thread(target=async_save_to_db, args=(wsprefix, df, table_name, uri,if_exists))
        thread.start()
        thread.join()

    else:
        try:
            engine = create_engine(uri, echo=False)
            if engine.connect():
                if wsprefix:
                    df.to_sql(wsprefix + '_' + table_name, con=engine, if_exists=if_exists, index=False)
                    if engine.dialect.has_table(engine, wsprefix + '_' + table_name):
                        engine.connect()
                        return 'Table saved successfully'
                else:
                    df.to_sql(table_name, con=engine, if_exists=if_exists, index=False)
                    if engine.dialect.has_table(engine, table_name):
                        engine.connect()
                        return 'Table saved successfully'
        except Exception as e:
            logging.error("Exception occurred at save_to_db".format(e))
            raise e


def async_save_to_db(wsprefix, df, table_name, outputdburl, if_exists):
    try:
        engine = create_engine(outputdburl, echo=False)
        if wsprefix:
            df.to_sql(wsprefix + '_' + table_name, con=engine, if_exists=if_exists, index=False)
            if engine.dialect.has_table(engine, wsprefix + '_' + table_name):
                engine.connect()
                return 'Table saved successfully'
        else:
            df.to_sql(table_name, con=engine, if_exists=if_exists, index=False)
            if engine.dialect.has_table(engine, table_name):
                engine.connect()
                return 'Table saved successfully'
    except Exception as e:
        logging.error("Exception occurred at async_save_to_db".format(e))
        raise e


def run_script_file(sql_file_path, dburl):
    if isinstance(dburl, str):
        uri = dburl

    elif isinstance(dburl, dict):
        uri = dburl.get("uri", None)
    try:
        file = open(sql_file_path)
        engine = create_engine(uri, echo=False)
        if engine.connect():
            escaped_sql = file.read().split(';')
            for query in escaped_sql:
                 engine.execute(text(query))
    except Exception as e:
        logging.error("Exception occurred at save_to_db".format(e))
        raise e


def save_config(config_json, table_name, fileName="sql_script.sql", indexing=True):
    from components.core_components.utils.helper import readParameter
    parameter = readParameter()
    sql_file_path = os.path.normpath(
        os.path.join(os.path.dirname(__file__), '../../../../input/insert_script/{}'.format(fileName)))
    run_script_file(sql_file_path, parameter.inputdburl)
    engine = create_engine(parameter.inputdburl, echo=False)
    df = pd.DataFrame(config_json)
    df.to_sql(con=engine, name=table_name, if_exists='append', index=indexing)





def table_script(table_name, column_prpt,dburl):
    from components.core_components.utils.helper import readParameter
    parameter = readParameter()
    sql_script = "DROP TABLE IF EXISTS `"+table_name+"`; CREATE TABLE `"+table_name+"`("
    column_str = ""
    index_id_column = ""
    for i, value in column_prpt.iterrows():
        table_name = value["table_name"]
        if value.get("is_index_column", None) == 'Y':
            index_id_column = value.get("column_name", None)
        if value.get("is_reference_column", None) and str(value.get('is_reference_column')).upper() == "Y":
            if str(value.get('is_helper_column',"N")).upper() != "Y":
                if str(value["column_data_type"]).lower() == "date" or str(
                        value["column_data_type"]).lower() == "datetime":
                    column_str = column_str + "`" + value["column_name"] + "` " + value["column_data_type"] + str(",")
                else:
                    column_str = column_str + "`" + value["column_name"] + "` " + value["column_data_type"] + "(" + str(
                        value["column_length"]) + str("),")
            else:
                pass
        else:
            if str(value["column_data_type"]).lower() == "date" or str(value["column_data_type"]).lower() == "datetime":
                column_str = column_str + "`" + value["column_name"] + "` " + value["column_data_type"] + str(",")
            else:
                column_str = column_str + "`" + value["column_name"] + "` " + value["column_data_type"] + "(" + str(
                    value["column_length"]) + str("),")
    tabledata = read_table(parameter.formation_conditions, parameter.inputdburl)
    column_name = []
    for i, value in tabledata.iterrows():
        if value["table_name"] == table_name:
            counter_party_column_name = value.get("counter_party_column_name", None)
            if counter_party_column_name:
                for counter_party_val  in counter_party_column_name:
                    if counter_party_val:
                        column_name.append(counter_party_val)
    for i in set(column_name):
        if i is not None:
            counter_party_name = "counter_party_{}".format(i)
            column_str = column_str + "`" + counter_party_name + "` " + "varchar(50),"

    tabledata1 = read_table("table_details", parameter.inputdburl)
    for i, value in tabledata1.iterrows():
        if value["table_name"] == table_name:
            if value.get("relationships", None):
                relationships = value.get('relationships')
                if _get_relationship_type(relationships) == "ONE_TO_MANY":
                    column_str = column_str + " `time_series` datetime,"

    sql_script = sql_script + column_str[:-1] + ", INDEX ("+index_id_column+")" + ") ENGINE=InnoDB DEFAULT CHARSET = latin1"
    try:
        os.remove("sql_output_script.sql")
    except OSError as e:
        logging.error("creating file sql_output_script.sql")
    with open("sql_output_script.sql", "a") as f:
        f.write(sql_script)
    sql_file_path = os.path.normpath(
        os.path.join(os.getcwd(), 'sql_output_script.sql'))
    run_script_file(sql_file_path, dburl)


def _get_relationship_type(relationships):
    relationship_type = 'ONE_TO_ONE'
    if isinstance(relationships, dict):
        relationship_type = relationships.get('rel_type', None)
    else:
        for row in relationships :
            if row.get('rel_type', None) and row.get('rel_type') == "ONE_TO_MANY":
                relationship_type = 'ONE_TO_MANY'
    return relationship_type


def create_output_tables(tableprpty,columnprpty):
    table_names = np.unique(columnprpty['table_name'])

    batch_job_table_names = _get_batch_job_table_names(tableprpty)

    if len(batch_job_table_names) > 0:
        gk = columnprpty.groupby('table_name')
        for i in table_names:
            if not _isTableExists(i):
                table_script(i, gk.get_group(i)[["column_name", "column_data_type", "column_length","is_reference_column","is_helper_column" ,"table_name","is_index_column"]])
    else:
        gk = columnprpty.groupby('table_name')
        for i in table_names:
            table_script(i, gk.get_group(i)[["column_name", "column_data_type", "column_length","is_reference_column","is_helper_column" ,"table_name","is_index_column"]])


def _isTableExists(table_name):
    from components.core_components.utils.helper import readParameter
    parameter = readParameter()
    return  has_table(table_name, parameter.outputdburl, wsprefix = None)


def drop_tables_if_exists(tableprpty, dburl):
    logging.debug('calling drop_tables_if_exists')
    table_names = np.unique(tableprpty['table_name'])
    for table_name in table_names:
        drop_table(table_name, dburl, wsprefix = None)

def create_all_output_tables(tableprpty,columnprpty,dburl):
    logging.debug('calling create_all_output_tables')

    table_names = np.unique(columnprpty['table_name'])

    gk = columnprpty.groupby('table_name')
    for i in table_names:
        table_script(i, gk.get_group(i)[["column_name", "column_data_type", "column_length","is_reference_column","is_helper_column" ,"table_name", "is_index_column"]],dburl)



def check_tables(tableprpty, columnprpty, dburl, wsprefix = None):
    table_names = np.unique(columnprpty['table_name'])
    batch_job_table_names = _get_batch_job_table_names(tableprpty)

    if len(batch_job_table_names) > 0:
        table_names = tableprpty[tableprpty['active_status'] == 'Y']['table_name']

        cleaned_list = [ x for x in table_names.tolist() if x not in batch_job_table_names ]

        for table_name in cleaned_list:
            drop_table(table_name, dburl, wsprefix)
    else:
        for table_name in table_names:
            drop_table(table_name, dburl, wsprefix)


def _get_batch_job_table_names(tableprpty):
    batch_job_table_names_list = []
    for index, row in tableprpty.iterrows():
        table_parameters = row.get('table_parameters', None)
        if table_parameters:
            batch = table_parameters.get('batch', None)
            if batch and batch == 'Y':
                batch_job_table_names_list.append(row.get('table_name', None))
    return batch_job_table_names_list


def to_sql_key(df, dburl, tablename, id_column, if_exists='replace', index=True):
    if isinstance(dburl, str):
        uri = dburl

    elif isinstance(dburl, dict):
        uri = dburl.get("uri", None)

    engine = create_engine(uri, echo=False)
    df.to_sql(tablename, con=engine, if_exists=if_exists, index=index)

    with engine.connect() as con:
        con.execute('ALTER TABLE {} ADD PRIMARY KEY ({})'.format(tablename,id_column))


def update_row(dburl, table_name, update_col, update_val, index_clm, index_val, wsprefix=None):
    if isinstance(dburl, str):
        uri = dburl

    elif isinstance(dburl, dict):
        uri = dburl.get("uri", None)

    engine = create_engine(uri, echo=False)
    if wsprefix:
        is_table_exists = engine.dialect.has_table(engine, wsprefix + '_' + table_name)
    else:
        is_table_exists = engine.dialect.has_table(engine, table_name)

    if is_table_exists:
        try:
            logging.debug('updating table {}'.format(table_name))
            Session = sessionmaker(bind=engine)
            session = Session()
            session.execute("UPDATE `{}` SET `{}` = '{}' WHERE (`{}` = '{}')".format(table_name, update_col, update_val, index_clm, index_val))
            session.commit()
            session.close()
        except Exception as e:
            logging.error("Exception occurred at updating table: {}".format(e))
            return True


def get_row_count(dburl, table_name):
    engine = create_engine(dburl, echo=False)
    cursor = engine.raw_connection().cursor()
    cursor.execute("SELECT * from {}".format(table_name))
    row_count = cursor.rowcount
    return row_count

if __name__ == '__main__':
    dburl = "mysql+pymysql://user:password@localhost/syn_data_generation"
    print(get_row_count(dburl, 'column_details'))
    # df = pd.DataFrame({'a':[11,22,33,44], 'b':['aa','bb','cc','dd']})
    # to_sql_key(df, dburl, tablename="dev", id_column='a', if_exists='replace', index=False)
    # update_row(dburl=dburl, table_name='dev', update_col='b', update_val='zz', index_clm='a', index_val=22)
