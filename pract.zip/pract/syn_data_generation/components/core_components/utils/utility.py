import collections
import configparser
import logging
import os.path
import time
import pandas as pd
from flask import session
from components.core_components.cache_management.cache_helper import cache_write
from components.core_components.generators.utils import generator_validator
from components.core_components.utils import helper
from components.core_components.utils.database import db_helper

const_path = os.path.normpath(os.path.join(os.path.dirname(__file__), '../../../output/cache/'))

parameter = collections.namedtuple('parameter',
                                   ['wsprefix', 'inputdburl', 'outputdburl', 'columnprpty', 'tableprpty',
                                    'demographicprpty', 'dependentgenparam', 'formation_conditions', 'joblogdburl',
                                    'jobtable','poolsize'])


def execute():
    from components.orchestrations import main
    main.execute_new()


def validate_generator_param(column_prptys_meta_json_list):
    validity_list = []
    try:
        if isinstance(column_prptys_meta_json_list, list):
            for gen_param in column_prptys_meta_json_list:
                logging.debug('Validating param : {}'.format(gen_param))
                validity_response = generator_validator.validate(gen_param)
                validity_list.append(validity_response)
        return validity_list
    except Exception as e:
        logging.debug('Exception occurred in validate_generator_param')
        logging.error(e)
    finally:
        logging.debug('----------- validateGeneratorParam ENDS -----------')


def read_parameter(configfile=None):
    if session:
        wsprefix = session.get('workspace', None)

        if wsprefix:
            wsname = wsprefix
        else:
            wsname = "temp"

        inputdburl = session.get(wsname + '_' + 'inputdb', None)
        outputdburl = session.get(wsname + '_' + 'outputdb', None)

        columnprpty = session.get(wsname + '_' + 'columnprpty', None)
        tableprpty = session.get(wsname + '_' + 'tableprpty', None)
        demographicprpty = session.get(wsname + '_' + 'demographicprpty', None)
        dependentgenparam = session.get(wsname + '_' + 'dependentgenparam', None)
        formation_conditions = session.get(wsname + '_' + 'formation_conditions', None)

        joblogdburl = session.get(wsname + '_' + 'joblogdburl', None)
        jobtable = session.get(wsname + '_' + 'jobtable', None)
        poolsize = session.get(wsname + '_' + 'poolsize', None)

    else:
        config = configparser.RawConfigParser()
        if configfile:
            config.read(configfile)
        else:
            from components.core_components.logging import app_path
            config.read(os.path.join(app_path, 'generation_config_file.properties'))

        inputdburl = config.get('DatabaseSection', 'inputdburl', fallback=None);
        outputdburl = config.get('DatabaseSection', 'outputdburl', fallback=None);
        wsprefix = config.get('DatabaseSection', 'wsprefix', fallback=None);

        columnprpty = config.get('DatabaseSection', 'columnprpty', fallback=None);
        tableprpty = config.get('DatabaseSection', 'tableprpty', fallback=None);
        demographicprpty = config.get('DatabaseSection', 'demographicprpty', fallback=None);
        dependentgenparam = config.get('DatabaseSection', 'dependentgenparam', fallback=None);
        formation_conditions = config.get('DatabaseSection', 'formation_conditions', fallback=None);

        joblogdburl = config.get('DatabaseSection', 'joblogdburl', fallback=None);
        jobtable = config.get('DatabaseSection', 'jobtable', fallback=None);

        poolsize = config.get('DatabaseSection', 'poolsize', fallback=None);

    parameter1 = parameter(wsprefix=wsprefix, inputdburl=inputdburl, outputdburl=outputdburl, columnprpty=columnprpty,
                           tableprpty=tableprpty, demographicprpty=demographicprpty,
                           dependentgenparam=dependentgenparam, formation_conditions=formation_conditions,
                           joblogdburl=joblogdburl, jobtable=jobtable,poolsize = poolsize )
    return parameter1


def save_dataframe(container, respDataframe, wsprefix, outputdburl, if_exists=None):
    start_time = time.time()

    logging.debug(' Execution time - in saving cache data - : %.3f seconds' % (time.time() - start_time))
    if outputdburl:
        db_helper.save_to_db(wsprefix, respDataframe, container.name, outputdburl, use_async=True, if_exists=if_exists)

    else:
        container.save_dataframe(
            dataframe=respDataframe,
            fileName=container.name,
            output_folder="output/example_scenario",
            delete_existing_logs=True
        )

    logging.debug(' Execution time - in saving dataframe - : %.3f seconds' % (time.time() - start_time))


def fetch_table(table_name, parameter=None,filter=None):
    if not parameter:
        parameter = helper.readParameter()

    if parameter.wsprefix:
        respDataframe = db_helper.read_table(table_name=table_name, dburl=parameter.outputdburl,
                                             wsprefix=parameter.wsprefix,
                                             filter=None)
        cache_write(table_name=table_name, df=respDataframe, wsprefix=parameter.wsprefix, use_async=True)

        return respDataframe
    else:
        respDataframe = db_helper.read_table(table_name=table_name, dburl=parameter.outputdburl, wsprefix=None,
                                             filter=None)
        cache_write(table_name=table_name, df=respDataframe, wsprefix=None, use_async=True)
        return respDataframe


def fetch_table(table_name, inputdburl, wsprefix=None, filter=filter):

    if wsprefix:
        respDataframe = db_helper.read_table(table_name=table_name, dburl=inputdburl,
                                             wsprefix=wsprefix,
                                             filter=None)
        cache_write(table_name=table_name, df=respDataframe, wsprefix=wsprefix, use_async=True)

        return respDataframe
    else:
        respDataframe = db_helper.read_table(table_name=table_name, dburl=inputdburl, wsprefix=None,
                                             filter=None)
        cache_write(table_name=table_name, df=respDataframe, wsprefix=None, use_async=True)
        if filter:
            for key, values in filter.items():
                respDataframe = respDataframe[respDataframe[key].isin(values)]
        return respDataframe


def get_table(table_name, parameter=None,filter=None):
    if not parameter:
        parameter = helper.readParameter()

    if parameter.wsprefix:
        wsname = parameter.wsprefix
    else:
        wsname = "temp"

    if parameter.wsprefix:
        respDataframe = db_helper.read_table(table_name=table_name, dburl=parameter.joblogdburl,
                                             wsprefix=parameter.wsprefix,
                                             filter=None)
        return respDataframe
    else:
        respDataframe = db_helper.read_table(table_name=table_name, dburl=parameter.joblogdburl, wsprefix=None,
                                             filter=None)
        return respDataframe
