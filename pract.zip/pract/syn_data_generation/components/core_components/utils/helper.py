import logging

import pandas as pd
from components import rest_app_settings
from components.core_components.cache_management import cache_helper
from components.core_components.generators.utils import generator_factory, generator_helper
from components.core_components.utils import utility
from components.core_components.utils.database import db_helper


def cacheClean(wsprefix=None):
    try:
        cache_helper.cache_clean(wsprefix)

    except Exception as e:
        logging.debug('Exception occurred in cache_clean {}'.format(e))

    finally:
        logging.debug('----------- call to cache_clean completed -----------')


def readParameter(configfile=None):
    try:
        return utility.read_parameter(configfile)
    except Exception as e:
        logging.error('Exception occurred in readParameter {}'.format(e))
        raise e
    finally:
        logging.debug('----------- call to readparameter completed -----------')


def checkDbConnections(dburl, connectionType):
    try:
        response = db_helper.check_db_connection(dburl)
        if response:
            logging.debug('----------- {} connection successful'.format(connectionType))
        else:
            logging.debug('----------- {} connection failure'.format(connectionType))
        return response
    except Exception as e:
        logging.debug('----------- {} Exception occurred in checkDbConnections'.format(connectionType))
        logging.error(e)
        return rest_app_settings.CONNECTION_FAILED
    finally:
        logging.debug('----------- {} connection check completed'.format(connectionType))


def readDependentGeneratorConditions(columnprpty, table_name,dburl):
    try:
        for index_label, row_series in columnprpty.iterrows():
            # For each row update the 'Bonus' value to it's double
            if not row_series.get("parameters", None):
                if (row_series.get("generator_name") == 'DependentColumnGenerator'):
                    filter = {
                        'column_name': [row_series.get('column_name')],
                        'table_name': [row_series.get('table_name')]  # Note that Age is a string
                    }

                    dataf = db_helper.read_table(table_name, dburl, wsprefix=None, filter=filter)

                    choices_list = []
                    conditions_list = []
                    dependent_column_list = []

                    for index, row in dataf.iterrows():
                        choices_list.append(row['choices'])
                        conditions_list.append(row['conditions'])

                        tmp_array = row['dependent_column'].split(',')
                        if len(tmp_array) > 1:
                            for j in range(len(tmp_array)):
                                dependent_column_list.append(tmp_array[j])

                        else:
                            dependent_column_list.append(row['dependent_column'])

                    dict_param = {}
                    dict_param['conditions'] = conditions_list
                    dict_param['dependent_column'] = list(dict.fromkeys(dependent_column_list))
                    dict_param['choices'] = choices_list

                    columnprpty.at[index_label, 'parameters'] = dict_param

        return columnprpty
    except Exception as e:
        logging.debug('Exception occurred in reading external data {}'.format(columnprpty))
        logging.error(e)
    finally:
        logging.debug('----------- call to readDependentGeneratorConditions completed {}'.format(columnprpty))


def readConfigTable(table_name, dburl, wsprefix=None, filter=None):
    try:

        return db_helper.read_table(table_name, dburl, wsprefix, filter)
    except Exception as e:
        logging.debug('Exception occurred in reading table {}'.format(table_name))
        # logging.error(e)
    finally:
        logging.debug('----------- call to readConfigTable completed')


def validateGeneratorParam(column_prptys_meta_json_list):
    try:
        return utility.validate_generator_param(column_prptys_meta_json_list)
    except Exception as e:
        logging.debug('Exception occurred in validateGeneratorParam')
        logging.error(e)
    finally:
        logging.debug('----------- validateGeneratorParam ENDS -----------')


def transformConfig(column_prptys_meta):
    import jsonpickle
    import pandas as pd
    column_prptys_meta_json_list = []
    try:
        if isinstance(column_prptys_meta, pd.core.frame.DataFrame):

            for index, row in column_prptys_meta.iterrows():
                try:
                    if isinstance(row, pd.core.series.Series):
                        str_row = row.to_json(orient='index')
                        dict_row = jsonpickle.decode(str_row)
                        str_parameters = dict_row.get('parameters', None)
                        if str_parameters and not isinstance(str_parameters, dict):
                            dict_row.update({'parameters': jsonpickle.decode(str_parameters)})
                        row = dict_row
                    logging.debug('creating config for {}'.format(row.get('column_name', None)))
                    column_prptys_meta_json_list.append(row)
                except Exception as e:
                    logging.debug('Exception occurred in converting to json {}'.format(row))
                    logging.error(e)

        elif isinstance(column_prptys_meta, list):
            column_prptys_meta_json_list = column_prptys_meta

        return column_prptys_meta_json_list

    except Exception as e:
        logging.debug('Exception occurred in transformConfig to json')
        logging.error(e)
    finally:
        logging.debug('----------- transformConfig ENDS -----------')


def initializePopulation(container, populationName=None):
    try:
        return generator_helper.initialize_population(container, populationName)
    except Exception as e:
        logging.debug('Exception occurred in initializePopulation')
        logging.error(e)
    finally:
        logging.debug('----------- initializePopulation ENDS -----------')


def hasTable(table_name, wsprefix, dburl):
    try:
        return db_helper.has_table(table_name, dburl, wsprefix)
    except Exception as e:
        logging.debug('Exception occurred in hasTable')
        logging.error(e)
    finally:
        logging.debug('----------- hasTable ENDS -----------')


def getTableSize(table_name, wsprefix, dburl):
    try:
        return db_helper.get_table_size(table_name, dburl, wsprefix)
    except Exception as e:
        logging.debug('Exception occurred in getTableSize')
        logging.error(e)
    finally:
        logging.debug('----------- getTableSize ENDS -----------')


def createContainerObject(name, size, master_seed, parameter=None,step_duration=pd.Timedelta("1h")):
    try:
        return generator_helper.create_container_object(name, size, master_seed=master_seed, parameter=parameter,step_duration=step_duration)
    except Exception as e:
        logging.debug('Exception occurred in createContainerObject')
        logging.error(e)
    finally:
        logging.debug('----------- createContainerObject ENDS -----------')


def initializeGenerators(config_table_name, table_name, dburl, wsprefix=None):
    try:
        gen_instance_list = []
        column_prptys_meta = readConfigTable(config_table_name, dburl, wsprefix,
                                             filter={'table_name': [table_name]}).sort_values(['column_sequence_id'])
        for index, row in column_prptys_meta.iterrows():
            gen_instance = generator_factory.getInstance(row)
            gen_instance_list.append(gen_instance)

        return gen_instance_list
    except Exception as e:
        logging.debug('Exception occurred in initializeGenerators')
        logging.error(e)
    finally:
        logging.debug('----------- initializeGenerators ENDS -----------')


def initializePersonaGenerators(column_prptys_meta_json_list):
    try:
        gen_instance_list = []
        if isinstance(column_prptys_meta_json_list, list):
            for gen_param in column_prptys_meta_json_list:
                logging.debug('initializeGenerators with param : {}'.format(gen_param))
                gen_instance = generator_factory.getInstance(gen_param)
                gen_instance_list.append(gen_instance)
        return gen_instance_list
    except Exception as e:
        logging.error(e)
    finally:
        logging.debug('----------- initializeGenerators ENDS -----------')


def createPopulation(gen_instance_list, population, size):
    try:
        return generator_helper.create_population(gen_instance_list, population, size)
    except Exception as e:
        logging.debug('Exception occurred in createPopulation')
        logging.error(e)
    finally:
        logging.debug('----------- createPopulation ENDS -----------')

def batchCacheclean(obj_name):

    try:
        return cache_helper.batch_cacheclean(obj_name)
    except Exception as e:
        logging.debug('Exception occurred in batchCacheWrite')
        logging.error(e)
    finally:
        logging.debug('----------- batchCacheRead ENDS -----------')

def batchCacheWrite(obj_name, df):

    try:
        return cache_helper.batch_cache_write(obj_name, df)
    except Exception as e:
        logging.debug('Exception occurred in batchCacheWrite')
        logging.debug(e)
    finally:
        logging.debug('----------- batchCacheWrite ENDS -----------')

def batchCacheRead(obj_name):

    try:
        return cache_helper.batch_cache_read(obj_name)
    except Exception as e:
        logging.debug('Exception occurred in batchCacheWrite')
        logging.debug(e)
    finally:
        logging.debug('----------- batchCacheRead ENDS -----------')



def saveDataframe(container, respDataframe, wsprefix, outputdburl, if_exists=None):
    try:
        return utility.save_dataframe(container, respDataframe, wsprefix, outputdburl,if_exists)
    except Exception as e:
        logging.debug('Exception occurred in saveDataframe')
        logging.error(e)
    finally:
        logging.debug('----------- saveDataframe ENDS -----------')

def generateEDAGraph(respDataframe, gen_instance_list) :
    try:
        return generator_helper.EDA_graphs(respDataframe, gen_instance_list)
    except Exception as e:
        logging.debug('Exception occurred in generateEDAGraph')
        logging.debug(e)
    finally:
        logging.debug('----------- generateEDAGraph ENDS -----------')

def generateGraph(respDataframe, gen_instance_list):
    try:
        return generator_helper.generate_graph(respDataframe, gen_instance_list)
    except Exception as e:
        logging.debug('Exception occurred in generateGraph')
        logging.debug(e)
    finally:
        logging.debug('----------- generateGraph ENDS -----------')

def EDA_graphs(respDataframe, meta_config_list):
    try:
        return generator_helper.EDA_graphs(respDataframe,meta_config_list)
    except Exception as e:
        logging.debug('Exception occurred in generateGraph')
        logging.error(e)
    finally:
        logging.debug('----------- generateGraph ENDS -----------')

def applyRules(respDataframe, gen_instance_list):
    try:
        return generator_helper.apply_rules(respDataframe, gen_instance_list)
    except Exception as e:
        logging.debug('Exception occurred in applyRules')
        logging.error(e)
    finally:
        logging.debug('----------- applyRules ENDS -----------')


def applyOutliers(respDataframe, gen_instance_list):
    try:
        return generator_helper.apply_outliers(respDataframe, gen_instance_list)
    except Exception as e:
        logging.debug('Exception occurred in apply_outliers')
        logging.error(e)
    finally:
        logging.debug('----------- apply_outliers ENDS -----------')


def applyMissingValues(respDataframe):
    try:
        return generator_helper.apply_missing_values(respDataframe)
    except Exception as e:
        logging.debug('Exception occurred in applyMissingValues')
        logging.error(e)
    finally:
        logging.debug('----------- applyMissingValues ENDS -----------')


def generateGraphs(personaDataframe):
    try:
        import seaborn as sns
        import matplotlib.pyplot as plt

        df = personaDataframe[['age', 'salary', 'total_monthly_income', 'annual_income']]
        # Plot
        plt.figure(figsize=(12, 10), dpi=80)
        sns.heatmap(df.corr(), xticklabels=df.corr().columns, yticklabels=df.corr().columns, cmap='RdYlGn', center=0,
                    annot=True)

        # Decorations
        plt.title('Correlogram of persona', fontsize=22)
        plt.xticks(fontsize=12)
        plt.yticks(fontsize=12)
        plt.show(block=True)
    except Exception as e:
        logging.debug('Exception occurred in generateGraphs')
        logging.error(e)
    finally:
        logging.debug('----------- generateGraphs ENDS -----------')
