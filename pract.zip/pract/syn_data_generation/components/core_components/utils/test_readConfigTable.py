from unittest import TestCase


class TestReadConfigTable(TestCase):
    def test_readConfigTable(self):
        self.fail()
