import os , os.path
import threading

import pandas as pd
import logging

const_path = os.path.normpath(os.path.join(os.path.dirname(__file__), '../../../output/cache/'))

pickle_path = os.path.normpath(os.path.join(os.path.dirname(__file__), '../../../output/pickle/'))

def cache_clean(wsprefix,use_async = True):

        if wsprefix:
            wsname = wsprefix
        else:
            wsname = "temp"

        path_url = os.path.join(const_path, wsname)

        if os.path.exists(path_url):
            os.remove(path_url)
        else:
            logging.debug('no cache of previous run') #batchCacheRead


def batch_cacheclean(obj_name):
    path_url = os.path.join(pickle_path, obj_name)

    if os.path.exists(path_url):
        os.remove(path_url)
    else:
        logging.debug('File does not exists')

def batch_cache_read(obj_name):
    path_url = os.path.join(pickle_path, obj_name)
    data = pd.read_pickle(path_url)
    return data


def batch_cache_write(obj_name, dataframe_obj):
    path_url = os.path.join(pickle_path, obj_name)
    dataframe_obj.to_pickle(path_url)


def cache_write(table_name, df,wsprefix,use_async = True):
    # if use_async:
    #     thread = threading.Thread(target=async_cache_write, args=(table_name, df,wsprefix))
    #     thread.start()
    #     thread.join()
    # else:
    def get_df_name(df):
        name = [x for x in globals() if globals()[x] is df][0]
        return str(name)

    if not table_name:
        table_name = get_df_name(df)

    if wsprefix:
        wsname = wsprefix
    else:
        wsname = "temp"

    path_url = os.path.join(const_path, wsname)

    store = pd.HDFStore(path_url)

    if wsprefix:
        if wsprefix + '_' + table_name in store:
            # print("table already exists in cache,over writing cache : ", path_url)
            store.append(wsprefix + '_' + table_name, df, format='fixed', data_columns=True)
            store.close()  # closes the file
            # store[wsprefix + '_' + table_name] = df
        else:
            store.put(wsprefix + '_' + table_name, df, format='fixed', data_columns=True)
            store.close()  # closes the file
            # store[wsprefix + '_' + table_name] = df
            # print("Table added to the cache : ", path_url)
    else:
        if table_name in store:
            # print("table already exists in cache,over writing cache : ", path_url)
            store.append(table_name, df, format='fixed', data_columns=True)
            store.close()  # closes the file
            # store[wsprefix + '_' + table_name] = df
        else:
            store.put(table_name, df, format='fixed', data_columns=True)
            store.close()  # closes the file
            # store[wsprefix + '_' + table_name] = df
            logging.debug('----------- Cache created at {}'.format(path_url))
    store.close()
    store.close()


def async_cache_write(table_name, df,wsprefix):
    import warnings, pandas
    warnings.filterwarnings('ignore', category=pandas.io.pytables.PerformanceWarning)
    def get_df_name(df):
        name = [x for x in globals() if globals()[x] is df][0]
        return str(name)

    if not table_name:
        table_name = get_df_name(df)

    if wsprefix:
        wsname = wsprefix
    else:
        wsname = "temp"

    path_url = os.path.join(const_path, wsname)

    store = pd.HDFStore(path_url)

    if wsprefix:
        if wsprefix + '_' + table_name in store:
            # print("table already exists in cache,over writing cache : ", path_url)
            store.put(wsprefix + '_' + table_name, df, format='fixed', data_columns=True)
            store.close()  # closes the file
            # store[wsprefix + '_' + table_name] = df
        else:
            store.put(wsprefix + '_' + table_name, df, format='fixed', data_columns=True)
            store.close()  # closes the file
            # store[wsprefix + '_' + table_name] = df
            logging.debug('----------- Cache created at {}'.format(path_url))
    else:
        if table_name in store:
            # print("table already exists in cache,over writing cache : ", path_url)
            store.put(table_name, df, format='fixed', data_columns=True)
            store.close()  # closes the file
            # store[wsprefix + '_' + table_name] = df
        else:
            store.put(table_name, df, format='fixed', data_columns=True)
            store.close()  # closes the file
            # store[wsprefix + '_' + table_name] = df
            logging.debug('----------- Cache created at {}'.format(path_url))