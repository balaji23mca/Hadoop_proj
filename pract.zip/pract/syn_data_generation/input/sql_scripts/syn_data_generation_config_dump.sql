CREATE DATABASE  IF NOT EXISTS `syn_data_generation` /*!40100 DEFAULT CHARACTER SET utf8 */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `syn_data_generation`;
-- MySQL dump 10.13  Distrib 8.0.16, for Win64 (x86_64)
--
-- Host: localhost    Database: syn_data_generation
-- ------------------------------------------------------
-- Server version	8.0.16

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
 SET NAMES utf8 ;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `column_details`
--

DROP TABLE IF EXISTS `column_details`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
SET character_set_client = utf8 ;
CREATE TABLE `column_details` (
  `column_details_id` int(11) NOT NULL AUTO_INCREMENT,
  `column_name` text,
  `column_data_type` text,
  `column_length` bigint(20) DEFAULT NULL,
  `table_id` bigint(20) DEFAULT NULL,
  `table_name` text,
  `column_sequence_id` bigint(20) DEFAULT NULL,
  `generator_name` text,
  `parameters` json DEFAULT NULL,
  `graph_parameters` text,
  `distribution_type` text,
  `generator_rule` json DEFAULT NULL,
  `running_balance_parameters` text,
  `is_reference_column` varchar(45) DEFAULT NULL,
  `is_helper_column` varchar(45) DEFAULT NULL,
  `is_index_column` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`column_details_id`),
  UNIQUE KEY `index_UNIQUE` (`column_details_id`),
  KEY `table_id` (`table_id`)
) ENGINE=InnoDB AUTO_INCREMENT=72 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `column_details`
--

LOCK TABLES `column_details` WRITE;
/*!40000 ALTER TABLE `column_details` DISABLE KEYS */;
INSERT INTO `column_details` VALUES (1,'persona_id','varchar',22,1,'persona',1,'SequencialGenerator','{\"start\": 1, \"prefix\": \"\"}',NULL,NULL,NULL,NULL,NULL,NULL,'Y'),(2,'gender','varchar',11,1,'persona',2,'ListGenerator','{\"Probability\": [0.6, 0.4], \"ListofValues\": [\"male\", \"female\"]}',' [{\'graph_type\':\'Bar_Graph\'},{\'graph_type\':\'Config_Validator\'}]','choice',NULL,NULL,NULL,NULL,NULL),(3,'age','int',11,1,'persona',3,'BucketSeriesGenerator','{\"a\": [\"13,30\", \"30,40\", \"40,50\", \"50,60\"], \"p\": [0.3, 0.2, 0.2, 0.3]}','[{\'graph_type\':\'Config_Validator\'}]','choice',NULL,NULL,NULL,NULL,NULL),(4,'income_type','varchar',11,1,'persona',4,'ListGenerator','{\"Probability\": [0.3, 0.4, 0.3], \"ListofValues\": [\"low\", \"medium\", \"high\"]}','[{\'graph_type\':\'Config_Validator\'}]','choice',NULL,NULL,NULL,NULL,NULL),(5,'minor_major','varchar',11,1,'persona',5,'DependentColumnGenerator','{\"choices\": [\"major\", \"minor\"], \"conditions\": \"[(age >= 18) | (age < 18)]\", \"dependent_column\": [\"age\"]}',' [{\'graph_type\':\'Bar_Graph\'}]',NULL,NULL,NULL,NULL,NULL,NULL),(6,'marital_status','varchar',50,1,'persona',6,'ListGenerator','{\"Probability\": [0.565, 0.225, 0.0525, 0.1425, 0.015], \"ListofValues\": [\"married\", \"widowed\", \"never_married\", \"divorced\", \"separated\"]}','[{\'graph_type\':\'Config_Validator\'}]','choice','{\"action\": \"never_married\", \"conditions\": \"(\'age\' <= 22)\", \"dependent_column\": [\"age\"]}',NULL,NULL,NULL,NULL),(7,'employment_status','varchar',11,1,'persona',7,'ListGenerator','{\"Probability\": [0.9, 0.1], \"ListofValues\": [\"Y\", \"N\"]}',NULL,'choice','{\"action\": \"N\", \"conditions\": \"(\'age\' <= 22)\", \"dependent_column\": [\"age\"]}',NULL,NULL,NULL,NULL),(8,'current_employment_start_date','datetime',50,1,'persona',8,'FakerGenerator','{\"api\": \"Datetime\", \"method\": \"datetime\", \"date_scope\": {\"end\": 2018, \"start\": 2002}}',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(9,'job_title','varchar',50,1,'persona',9,'DependentColumnGenerator',NULL,' [{\'graph_type\':\'Bar_Graph\'}]',NULL,NULL,NULL,NULL,NULL,NULL),(10,'salary','float',50,1,'persona',10,'CorrelatedGenerator','{\"act_low\": 50000, \"Exp_corr\": 0.8, \"act_high\": 80000, \"feature1\": \"age\", \"feature2\": \"salary\", \"table_name\": \"persona\", \"column_name\": \"age\"}',NULL,NULL,'{\"action\": 0, \"conditions\": \"(\'age\' <= 22)\", \"dependent_column\": [\"age\"]}',NULL,NULL,NULL,NULL),(11,'total_income','float',50,1,'persona',11,'CorrelatedGenerator','{\"act_low\": 600000, \"Exp_corr\": 0.8, \"act_high\": 960000, \"feature1\": \"age\", \"feature2\": \"total_income\", \"table_name\": \"persona\", \"column_name\": \"age\"}',NULL,NULL,'{\"action\": 0, \"conditions\": \"(\'age\' <= 22)\", \"dependent_column\": [\"age\"]}',NULL,NULL,NULL,NULL),(12,'person_id','varchar',22,2,'person',1,'SequencialGenerator','{\"start\": 1, \"prefix\": \"\"}',NULL,NULL,NULL,NULL,NULL,NULL,'Y'),(13,'person_type','varchar',11,2,'person',2,'ConstantGenerator','{\"value\": 1}',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(14,'gender','varchar',11,2,'person',3,'ColumnPicker','{\"table_name\": \"persona\", \"select_column_name\": \"gender\"}',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(15,'age','int',11,2,'person',4,'ColumnPicker','{\"table_name\": \"persona\", \"select_column_name\": \"age\"}',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(16,'income_type','varchar',11,2,'person',5,'ColumnPicker','{\"table_name\": \"persona\", \"select_column_name\": \"income_type\"}',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(17,'dob','datetime',50,2,'person',6,'DateTimeGenerator','{\"method\": \"CalculateDate\", \"table_name\": \"persona\", \"select_column_name\": \"age\"}',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(18,'forenames','varchar',50,2,'person',7,'FakerGenerator','{\"method\": \"surname\"}',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(19,'middlename','varchar',50,2,'person',8,'FakerGenerator','{\"method\": \"name\"}',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(20,'lastname','varchar',50,2,'person',9,'FakerGenerator','{\"method\": \"last_name\"}',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(21,'preferred','varchar',50,2,'person',10,'ColumnPicker','{\"table_name\": \"\", \"select_column_name\": \"forenames\"}',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(22,'minor_major','varchar',11,2,'person',11,'ColumnPicker','{\"table_name\": \"persona\", \"select_column_name\": \"minor_major\"}',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(23,'marital_status','varchar',50,2,'person',12,'ColumnPicker','{\"table_name\": \"persona\", \"select_column_name\": \"marital_status\"}',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(24,'employment_status','varchar',11,2,'person',13,'ColumnPicker','{\"table_name\": \"persona\", \"select_column_name\": \"employment_status\"}',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(25,'active','varchar',11,2,'person',14,'ListGenerator','{\"Probability\": [0.9, 0.1], \"ListofValues\": [\"Y\", \"N\"]}',NULL,'choice',NULL,NULL,NULL,NULL,NULL),(26,'approved_date','datetime',50,2,'person',15,'DateTimeGenerator','{\"method\": \"generate_date\", \"end_date\": \"2019/5/1\", \"start_date\": \"2018/4/1\"}',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(27,'activation_date','datetime',50,2,'person',16,'DateTimeGenerator','{\"method\": \"modify_date\", \"number_of_days\": \"+1\", \"select_column_name\": \"approved_date\"}',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(28,'current_employment_start_date','datetime',50,2,'person',17,'ColumnPicker','{\"table_name\": \"persona\", \"select_column_name\": \"current_employment_start_date\"}',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(29,'job_title','varchar',50,2,'person',18,'ColumnPicker','{\"table_name\": \"persona\", \"select_column_name\": \"job_title\"}',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(30,'salary','float',50,2,'person',19,'ColumnPicker','{\"table_name\": \"persona\", \"select_column_name\": \"salary\"}',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(31,'maker_id','varchar',22,2,'person',20,'ListGenerator','{\"Probability\": [0.6, 0.4], \"ListofValues\": [\"EMP_M_001\", \"EMP_M_002\"]}',NULL,'choice',NULL,NULL,NULL,NULL,NULL),(32,'maker_date','datetime',50,2,'person',21,'ColumnPicker','{\"table_name\": \"\", \"select_column_name\": \"activation_date\"}',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(33,'checker_id','varchar',22,2,'person',22,'ListGenerator','{\"Probability\": [0.6, 0.4], \"ListofValues\": [\"EMP_C_003\", \"EMP_C_004\"]}',NULL,'choice',NULL,NULL,NULL,NULL,NULL),(34,'checker_date','datetime',50,2,'person',23,'DateTimeGenerator','{\"method\": \"modify_date\", \"number_of_hours\": \"+3\", \"select_column_name\": \"maker_date\"}',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(35,'modified_by','varchar',22,2,'person',24,'ListGenerator','{\"Probability\": [0.6, 0.4], \"ListofValues\": [\"EMP_C_005\", \"EMP_C_006\"]}',NULL,'choice',NULL,NULL,NULL,NULL,NULL),(36,'modified_date','datetime',50,2,'person',25,'DateTimeGenerator','{\"method\": \"modify_date\", \"number_of_days\": \"+1\", \"number_of_hours\": \"+3\", \"select_column_name\": \"maker_date\"}',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(37,'account_id','varchar',22,4,'account',1,'SequencialGenerator','{\"start\": 1000, \"prefix\": \"\", \"max_length\": 6}',NULL,NULL,NULL,NULL,NULL,NULL,'Y'),(38,'person_id','varchar',22,4,'account',2,'ColumnPicker','{\"table_name\": \"person\", \"select_column_name\": \"person_id\"}',NULL,NULL,NULL,NULL,'Y',NULL,NULL),(39,'bank_id','int',11,4,'account',6,'ConstantGenerator','{\"value\": 1001}',NULL,NULL,NULL,NULL,'Y',NULL,NULL),(40,'branch_id','int',15,4,'account',7,'ListGenerator','{\"Probability\": [0.2, 0.2, 0.2, 0.2, 0.2], \"ListofValues\": [10000375, 10000110, 10000345, 10000645, 10000982]}',NULL,'choice',NULL,NULL,'Y',NULL,NULL),(41,'age','int',11,4,'account',5,'ColumnPicker','{\"table_name\": \"person\", \"select_column_name\": \"age\"}',NULL,NULL,NULL,NULL,'Y',NULL,NULL),(42,'gender','varchar',11,4,'account',3,'ColumnPicker','{\"table_name\": \"person\", \"select_column_name\": \"gender\"}',NULL,NULL,NULL,NULL,'Y','Y',NULL),(43,'income_type','varchar',11,4,'account',4,'ColumnPicker','{\"table_name\": \"person\", \"select_column_name\": \"income_type\"}',NULL,NULL,NULL,NULL,'Y','Y',NULL),(44,'product_id','int',11,4,'account',8,'OneToManyGenerator',NULL,NULL,NULL,NULL,NULL,'Y',NULL,NULL),(45,'product_name','varchar',50,4,'account',9,'ColumnPicker','{\"key\": \"product_id\", \"table_name\": \"product\", \"select_column_name\": \"product_name\"}',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(46,'scheme_name','varchar',22,4,'account',10,'ConstantGenerator','{\"value\": \"SortCodeAccountNumber\"}',NULL,NULL,NULL,NULL,'Y',NULL,NULL),(47,'account_name','varchar',50,4,'account',11,'ColumnPicker','{\"table_name\": \"person\", \"select_column_name\": \"preferred\"}',NULL,NULL,NULL,NULL,'Y',NULL,NULL),(48,'job_title','varchar',50,4,'account',12,'ColumnPicker','{\"table_name\": \"person\", \"select_column_name\": \"job_title\"}',NULL,NULL,NULL,NULL,'Y','Y',NULL),(49,'account_currency','varchar',50,4,'account',13,'ConstantGenerator','{\"value\": \"GBP\"}',NULL,'',NULL,NULL,'Y',NULL,NULL),(50,'status','varchar',11,4,'account',14,'ConstantGenerator','{\"value\": \"ACTIVE\"}',NULL,NULL,NULL,NULL,'Y',NULL,NULL),(52,'salary','float',50,4,'account',16,'ColumnPicker','{\"table_name\": \"person\", \"select_column_name\": \"salary\"}',NULL,NULL,NULL,NULL,'Y',NULL,NULL),(53,'balance','float',50,4,'account',17,'DerivativeGenerator','{\"operator\": \"/\", \"table_name\": \"person\", \"derivative_columns\": [\"salary\"], \"derivative_factors\": [0.7]}',NULL,NULL,NULL,NULL,'Y',NULL,NULL),(54,'account_id','varchar',22,5,'transaction',1,'ColumnPicker','{\"table_name\": \"account\", \"select_column_name\": \"account_id\"}',NULL,NULL,NULL,NULL,'Y',NULL,NULL),(55,'transaction_id','varchar',50,5,'transaction',2,'SequencialGenerator','{\"start\": 100000001, \"prefix\": \"\", \"max_length\": 10}','[{\"graph_type\":\"Time_Series_Graph\",\"y_axis\":\"time_series\"}]',NULL,NULL,NULL,NULL,NULL,'Y'),(56,'transaction_reference','varchar',50,5,'transaction',3,'SequencialGenerator','{\"start\": 666000001, \"prefix\": \"\", \"max_length\": 10}',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(58,'bank_id','int',11,5,'transaction',5,'ColumnPicker','{\"table_name\": \"account\", \"select_column_name\": \"bank_id\"}',NULL,NULL,NULL,NULL,'Y',NULL,NULL),(59,'product_name','varchar',50,5,'transaction',6,'ColumnPicker','{\"table_name\": \"account\", \"select_column_name\": \"product_name\"}','[{\"graph_type\":\"Bar_Graph\",\"y_axis\":\"transaction_id\"}]',NULL,NULL,NULL,'Y',NULL,NULL),(60,'transactions','varchar',50,5,'transaction',7,'OneToManyGenerator',NULL,NULL,NULL,NULL,NULL,'Y',NULL,NULL),(61,'currency_code','varchar',11,5,'transaction',8,'ConstantGenerator','{\"value\": \"GBP\"}',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(62,'value_date_time','datetime',50,5,'transaction',9,'DateTimeGenerator','{\"method\": \"generate_date\", \"end_date\": \"\", \"start_date\": \"\"}',NULL,NULL,NULL,NULL,'Y',NULL,NULL),(63,'maker_id','varchar',22,5,'transaction',10,'ListGenerator','{\"Probability\": [0.6, 0.4], \"ListofValues\": [\"EMP_M_001\", \"EMP_M_002\"]}',NULL,'choice',NULL,NULL,NULL,NULL,NULL),(64,'maker_date','datetime',50,5,'transaction',11,'DateTimeGenerator','{\"method\": \"generate_date\", \"end_date\": \"\", \"start_date\": \"\"}',NULL,NULL,NULL,NULL,'Y',NULL,NULL),(65,'checker_id','varchar',22,5,'transaction',12,'ListGenerator','{\"Probability\": [0.6, 0.4], \"ListofValues\": [\"EMP_C_003\", \"EMP_C_004\"]}',NULL,'choice',NULL,NULL,NULL,NULL,NULL),(66,'checker_date','datetime',50,5,'transaction',13,'DateTimeGenerator','{\"method\": \"generate_date\", \"end_date\": \"\", \"start_date\": \"\"}',NULL,NULL,NULL,NULL,'Y',NULL,NULL),(67,'modified_by','varchar',22,5,'transaction',14,'ListGenerator','{\"Probability\": [0.6, 0.4], \"ListofValues\": [\"EMP_C_005\", \"EMP_C_006\"]}',NULL,'choice',NULL,NULL,NULL,NULL,NULL),(68,'modified_date','datetime',50,5,'transaction',15,'DateTimeGenerator','{\"method\": \"generate_date\", \"end_date\": \"\", \"start_date\": \"\"}',NULL,NULL,NULL,NULL,'Y',NULL,NULL),(69,'credit_debit_indicator','varchar',11,5,'transaction',16,'DependentColumnGenerator','{\"choices\": [\"Credit\", \"Credit\", \"Credit\", \"Credit\", \"Credit\", \"Credit\", \"Credit\", \"Debit\", \"Debit\", \"Debit\", \"Debit\", \"Debit\", \"Debit\", \"Debit\", \"Debit\", \"Debit\"], \"conditions\": \"[(transactions == \'Cash Deposit\') | (transactions ==\'Cheque Deposit\')| (transactions ==\'Salary Credit\')| (transactions ==\'Deposit Cheque\')| (transactions ==\'Redeem Fixed Deposit\')| (transactions ==\'Receive Rent\')| (transactions ==\'Receive Pension\')| (transactions ==\'Utility Bill Payments\') |(transactions ==\'Transfer Money to Family\') |(transactions ==\'Cash Withdrawal\') |(transactions ==\'Online Shopping\')| (transactions ==\'Pay at Store\')| (transactions ==\'Credit Card Payment\') |(transactions ==\'Pay by Cheque\')| (transactions ==\'Open Fixed Deposit\') |(transactions ==\'Pay by Debit Card\')]\", \"dependent_column\": [\"transactions\"]}',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(70,'balance','float',50,5,'transaction',17,'ColumnPicker','{\"key\": \"account_id\", \"table_name\": \"account\", \"select_column_name\": \"balance\"}','[{\"graph_type\":\"Grouped_Time_Series_Graph\",\"y_axis\":\"time_series\",\"grpby_param\":\"account_id\"}]',NULL,NULL,'{\"group_by_column\":\"account_id\", \"apply_to_column\":\"balance\", \"updater_column\":\"transaction_amount\", \"column_operator\":\"credit_debit_indicator\",\"action_operator\":None, \"conditions\":[\"Credit\",\"Debit\"]}',NULL,NULL,NULL),(71,'transaction_amount','float',50,5,'transaction',18,'DerivativeGenerator','{\"operator\": \"*\", \"table_name\": \"\", \"derivative_columns\": [\"balance\"], \"derivative_factors\": [0.1]}',NULL,NULL,NULL,NULL,NULL,NULL,NULL);
/*!40000 ALTER TABLE `column_details` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dependent_generator_conditions`
--

DROP TABLE IF EXISTS `dependent_generator_conditions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
SET character_set_client = utf8 ;
CREATE TABLE `dependent_generator_conditions` (
  `dependent_generator_conditions_index` int(11) NOT NULL AUTO_INCREMENT,
  `table_name` varchar(50) NOT NULL,
  `column_name` varchar(50) NOT NULL,
  `conditions` varchar(100) NOT NULL,
  `choices` varchar(100) NOT NULL,
  `dependent_column` varchar(100) NOT NULL,
  PRIMARY KEY (`dependent_generator_conditions_index`),
  UNIQUE KEY `condition_index_UNIQUE` (`dependent_generator_conditions_index`),
  KEY `dependent_generator_conditions_table_name_foreign_key` (`table_name`),
  KEY `dependent_generator_conditions_column_name_foreign_key` (`column_name`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dependent_generator_conditions`
--

LOCK TABLES `dependent_generator_conditions` WRITE;
/*!40000 ALTER TABLE `dependent_generator_conditions` DISABLE KEYS */;
INSERT INTO `dependent_generator_conditions` VALUES (1,'persona','job_title','(\'age\' < 18)','Minor','age'),(2,'persona','job_title','(\'age\' >= 18) & (\'age\'<= 22)','Student','age'),(3,'persona','job_title','(\'age\' >= 23) & (\'age\'<= 30) & (\'income_type\' == \'low\')','Admin Assistant','age,income_type'),(4,'persona','job_title','(\'age\' >= 23) & (\'age\'<= 30) & (\'income_type\' == \'medium\')','Software Developer','age,income_type'),(5,'persona','job_title','(\'age\' >= 23) & (\'age\'<= 30) & (\'income_type\' == \'high\')','Software Developer','age,income_type'),(6,'persona','job_title','(\'age\' >= 31) & (\'age\'<= 40) & (\'income_type\' == \'high\') & (\'gender\' == \'male\')','Analyst in City Brokerage Farm','age,income_type,gender'),(7,'persona','job_title','(\'age\' >= 31) & (\'age\'<= 40) & (\'income_type\' == \'medium\')','Bank Employee','age,income_type'),(8,'persona','job_title','(\'age\' >= 31) & (\'age\'<= 40) & (\'income_type\' == \'low\')','Single Shop Owner','age,income_type'),(9,'persona','job_title','(\'age\' >= 31) & (\'age\'<= 40) & (\'income_type\' == \'high\') & (\'gender\' == \'female\')','Director- Small Building Firm','age,income_type,gender'),(10,'persona','job_title','(\'age\' >= 41) & (\'age\'<= 50) & (\'income_type\' == \'low\')','Mobile Hair Stylist without own salon','age,income_type'),(11,'persona','job_title','(\'age\' >= 41) & (\'age\'<= 50) & (\'income_type\' == \'high\')','Restaurant Chain Owner','age,income_type'),(12,'persona','job_title','(\'age\' >= 41) & (\'age\'<= 50) & (\'income_type\' == \'medium\')','Restaurant Chain Owner','age,income_type'),(13,'persona','job_title','(\'age\' >= 51) & (\'age\'<= 60) & (\'income_type\' == \'high\')','Experienced Architect','age,income_type'),(14,'persona','job_title','(\'age\' >= 51) & (\'age\'<= 60) & (\'income_type\' == \'medium\')','Restaurant Chain Owner','age,income_type'),(15,'persona','job_title','(\'age\' >= 51) & (\'age\'<= 60) & (\'income_type\' == \'low\')','Bank Employee','age,income_type'),(16,'persona','job_title','(\'age\' >= 61)','Retired Employee','age');
/*!40000 ALTER TABLE `dependent_generator_conditions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `job`
--

DROP TABLE IF EXISTS `job`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
SET character_set_client = utf8 ;
CREATE TABLE `job` (
  `job_id` int(11) NOT NULL AUTO_INCREMENT,
  `recordNumber` int(11) DEFAULT NULL,
  `table_name` varchar(45) DEFAULT 'na',
  `start_time` datetime DEFAULT NULL,
  `end_time` datetime DEFAULT NULL,
  `status` varchar(50) DEFAULT 'not_started',
  `message` varchar(500) DEFAULT NULL,
  PRIMARY KEY (`job_id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `job`
--

LOCK TABLES `job` WRITE;
/*!40000 ALTER TABLE `job` DISABLE KEYS */;
INSERT INTO `job` VALUES (1,100,NULL,NULL,NULL,'not_started',' '),(2,100,NULL,NULL,NULL,'not_started',' ');
/*!40000 ALTER TABLE `job` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `table_details`
--

DROP TABLE IF EXISTS `table_details`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
SET character_set_client = utf8 ;
CREATE TABLE `table_details` (
  `table_id` int(11) NOT NULL,
  `table_name` varchar(50) NOT NULL,
  `table_parameters` json NOT NULL,
  `dependency_level` int(11) NOT NULL,
  `relationships` json DEFAULT NULL,
  `table_description` varchar(100) NOT NULL,
  `active_status` varchar(1) NOT NULL,
  `commit_size` int(11) DEFAULT NULL,
  PRIMARY KEY (`table_id`),
  UNIQUE KEY `table_id_UNIQUE` (`table_id`),
  UNIQUE KEY `table_name_UNIQUE` (`table_name`),
  KEY `table_name_foreign_key_idx` (`table_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `table_details`
--

LOCK TABLES `table_details` WRITE;
/*!40000 ALTER TABLE `table_details` DISABLE KEYS */;
INSERT INTO `table_details` VALUES (1,'persona','{\"master_seed\": 1234}',0,NULL,'persona table','Y',10),(2,'person','{\"master_seed\": 1234}',1,'{\"table\": \"persona\", \"rel_type\": \"ONE_TO_ONE\", \"rel_columns\": [[\"persona.persona_id\"], [\"person.person_id\"]]}','person table','Y',10),(3,'product','{\"master_seed\": 1234, \"sql_file_path\": \"product_static_data.sql\", \"sql_file_path_type\": \"RELATIVE\"}',0,NULL,'Static table ','Y',NULL),(4,'account','{\"duration\": \"1 day\", \"master_seed\": 1234}',2,'[{\"table\": \"person\", \"rel_type\": \"ONE_TO_ONE\", \"rel_columns\": [[\"person.person_id\"], [\"account.person_id\"]]}, {\"table\": \"product\", \"rel_type\": \"ONE_TO_MANY\", \"rel_columns\": [[\"product.product_id\"], [\"account.product_id\"]]}]','account table','Y',10),(5,'transaction','{\"duration\": \"3 months\", \"master_seed\": 1234}',3,'[{\"table\": \"account\", \"rel_type\": \"ONE_TO_ONE\", \"rel_columns\": [[\"account.account_id\"], [\"transaction.account_id\"]]}, {\"table\": \"product\", \"rel_type\": \"ONE_TO_MANY\", \"rel_columns\": [[\"product.product_name\"], [\"transaction.product_name\"]]}]','transaction table','Y',10);
/*!40000 ALTER TABLE `table_details` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `table_relationship_def`
--

DROP TABLE IF EXISTS `table_relationship_def`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
SET character_set_client = utf8 ;
CREATE TABLE `table_relationship_def` (
  `table_rel_defination_index` int(11) NOT NULL AUTO_INCREMENT,
  `table_name` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `conditions` varchar(200) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `column_name` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `list_of_probable_values` json DEFAULT NULL,
  `distribution_of_probable_values` json DEFAULT NULL,
  `probable_count_distribution_for_the_period` json DEFAULT NULL,
  `input_column_names` varchar(45) DEFAULT NULL,
  `probable_period_of_occurrence` json DEFAULT NULL,
  `counter_party_column_name` json DEFAULT NULL,
  PRIMARY KEY (`table_rel_defination_index`),
  UNIQUE KEY `conditions_index_UNIQUE` (`table_rel_defination_index`),
  KEY `table_rel_defination_table_name_foreign_key` (`table_name`),
  KEY `table_rel_defination_counter_party_foreign_key` (`column_name`)
) ENGINE=InnoDB AUTO_INCREMENT=29 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `table_relationship_def`
--

LOCK TABLES `table_relationship_def` WRITE;
/*!40000 ALTER TABLE `table_relationship_def` DISABLE KEYS */;
INSERT INTO `table_relationship_def` VALUES (1,'account','(\'age\' < 18)','product_id','[1002, 1008]',NULL,'{\"1\": 0.6, \"2\": 0.4}','age',NULL,NULL),(2,'account','(\'age\' >= 18) & (\'age\'<= 22)','product_id','[1013]',NULL,'{\"1\": 1}','age',NULL,NULL),(3,'account','(\'age\' >= 23) & (\'age\'<= 30) & (\'income_type\' == \'low\')','product_id','[1015]',NULL,'{\"1\": 1}','age,income_type',NULL,NULL),(4,'account','(\'age\' >= 23) & (\'age\'<= 30) & (\'income_type\' == \'medium\')','product_id','[1014, 1003]',NULL,'{\"1\": 0.6, \"2\": 0.4}','age,income_type',NULL,NULL),(5,'account','(\'age\' >= 31) & (\'age\'<= 40) & (\'income_type\' == \'high\') & (\'gender\' == \'male\')','product_id','[1014, 1003]',NULL,'{\"1\": 0.6, \"2\": 0.4}','age,income_type,gender',NULL,NULL),(6,'account','(\'age\' >= 31) & (\'age\'<= 40) & (\'income_type\' == \'medium\')','product_id','[1018, 1003]',NULL,'{\"1\": 0.6, \"2\": 0.4}','age,income_type',NULL,NULL),(7,'account','(\'age\' >= 31) & (\'age\'<= 40) & (\'income_type\' == \'low\')','product_id','[1004, 1010, 1003]',NULL,'{\"1\": 0.4, \"2\": 0.4, \"3\": 0.2}','age,income_type',NULL,NULL),(8,'account','(\'age\' >= 31) & (\'age\'<= 40) & (\'income_type\' == \'high\') & (\'gender\' == \'female\')','product_id','[1004, 1010]',NULL,'{\"1\": 0.6, \"2\": 0.4}','age,income_type,gender',NULL,NULL),(9,'account','(\'age\' >= 41) & (\'age\'<= 50) & (\'income_type\' == \'low\')','product_id','[1005, 1003]',NULL,'{\"1\": 0.6, \"2\": 0.4}','age,income_type',NULL,NULL),(10,'account','(\'age\' >= 41) & (\'age\'<= 50) & (\'income_type\' == \'high\')','product_id','[1004, 1008, 1003, 1010]',NULL,'{\"1\": 0.4, \"2\": 0.2, \"3\": 0.2, \"4\": 0.2}','age,income_type',NULL,NULL),(11,'account','(\'age\' >= 41) & (\'age\'<= 50) & (\'income_type\' == \'medium\')','product_id','[1004, 1008, 1003, 1010]',NULL,'{\"1\": 0.4, \"2\": 0.2, \"3\": 0.2, \"4\": 0.2}','age,income_type',NULL,NULL),(12,'account','(\'age\' >= 51) & (\'age\'<= 60) & (\'income_type\' == \'high\')','product_id','[1012, 1008, 1003]',NULL,'{\"1\": 0.4, \"2\": 0.4, \"3\": 0.2}','age,income_type',NULL,NULL),(13,'account','(\'age\' >= 51) & (\'age\'<= 60) & (\'income_type\' == \'medium\')','product_id','[1004, 1008, 1003, 1010]',NULL,'{\"1\": 0.4, \"2\": 0.2, \"3\": 0.2, \"4\": 0.2}','age,income_type',NULL,NULL),(14,'account','(\'age\' >= 51) & (\'age\'<= 60) & (\'income_type\' == \'low\')','product_id','[1018, 1003]',NULL,'{\"1\": 0.6, \"2\": 0.4}','age,income_type',NULL,NULL),(15,'account','(\'age\' >= 61)','product_id','[1016, 1008]',NULL,'{\"1\": 0.6, \"2\": 0.4}','age',NULL,NULL),(16,'account','(\'age\' >= 23) & (\'age\'<= 30) & (\'income_type\' == \'high\')','product_id','[1014, 1003]',NULL,'{\"1\": 0.6, \"2\": 0.4}','age,income_type',NULL,NULL),(17,'transaction','(\'product_name\' == \'Catch them Young Saving Account\')','transactions','[\"Cash Deposit\", \"Cheque Deposit\"]',NULL,'[{\"1-2\": 0.6, \"3-4\": 0.4}, {\"1-2\": 0.6, \"3-4\": 0.4}]','product_name','[\"monthly\", \"monthly\"]',NULL),(18,'transaction','(\'product_name\' == \'Credit Card\')','transactions','[\"Online Shopping\", \"Pay at Store\", \"Credit Card Payment\"]',NULL,'[{\"1-2\": 0.6, \"3-4\": 0.4}, {\"1-2\": 0.6, \"3-4\": 0.4}, {\"1-2\": 0.6, \"3-4\": 0.4}]','product_name','[\"monthly\", \"monthly\", \"monthly\"]',NULL),(19,'transaction','(\'product_name\' == \'Saving Account\')','transactions','[\"Cash Deposit\", \"Cash Withdrawal\"]',NULL,'[{\"1-2\": 0.6, \"3-4\": 0.4}, {\"1-2\": 0.6, \"3-4\": 0.4}]','product_name','[\"monthly\", \"monthly\"]',NULL),(20,'transaction','(\'product_name\' == \'Salary Saving Account\')','transactions','[\"Salary Credit\", \"Utility Bill Payments\", \"Transfer Money to Family\", \"Cash Withdrawal\"]',NULL,'[{\"1-2\": 0.6, \"3-4\": 0.4}, {\"1-2\": 0.6, \"3-4\": 0.4}, {\"1-2\": 0.6, \"3-4\": 0.4}, {\"1-2\": 0.6, \"3-4\": 0.4}]','product_name','[\"monthly\", \"monthly\", \"monthly\", \"daily\"]','[\"\", \"\", \"account_id\", \"\"]'),(21,'transaction','(\'product_name\' == \'Salary Account\')','transactions','[\"Salary Credit\", \"Cash Withdrawal\", \"Online Shopping\", \"Utility Bill Payments\"]',NULL,'[{\"1-2\": 0.6, \"3-4\": 0.4}, {\"1-2\": 0.6, \"3-4\": 0.4}, {\"1-2\": 0.6, \"3-4\": 0.4}, {\"1-2\": 0.6, \"3-4\": 0.4}]','product_name','[\"monthly\", \"monthly\", \"monthly\", \"daily\"]',NULL),(22,'transaction','(\'product_name\' == \'Current Account\')','transactions','[\"Pay by Cheque\", \"Deposit Cheque\", \"Cash Withdrawal\", \"Cash Deposit\"]',NULL,'[{\"1-2\": 0.6, \"3-4\": 0.4}, {\"1-2\": 0.6, \"3-4\": 0.4}, {\"1-2\": 0.6, \"3-4\": 0.4}, {\"1-2\": 0.6, \"3-4\": 0.4}]','product_name','[\"monthly\", \"monthly\", \"monthly\", \"daily\"]',NULL),(23,'transaction','(\'product_name\' == \'Daily Saver Saving Account\')','transactions','[\"Cash Deposit\", \"Cheque Deposit\"]','[0.2, 0.8]','[{\"1-2\": 0.6, \"3-4\": 0.4}, {\"1-2\": 0.6, \"3-4\": 0.4}]','product_name','[\"monthly\", \"monthly\"]',NULL),(24,'transaction','(\'product_name\' == \'Fixed Deposit Account\')','transactions','[\"Open Fixed Deposit\", \"Redeem Fixed Deposit\"]',NULL,'[{\"1-2\": 0.6, \"3-4\": 0.4}, {\"1-2\": 0.6, \"3-4\": 0.4}]','product_name','[\"monthly\", \"monthly\"]',NULL),(25,'transaction','(\'product_name\' == \'Overdraft Account\')','transactions','[\"Pay by Cheque\", \"Deposit Cheque\"]',NULL,'[{\"1-2\": 0.6, \"3-4\": 0.4}, {\"1-2\": 0.6, \"3-4\": 0.4}]','product_name','[\"monthly\", \"monthly\"]',NULL),(26,'transaction','(\'product_name\' == \'Staff Salary Account\')','transactions','[\"Utility Bill Payments\", \"Pay by Debit Card\", \"Pay by Cheque\", \"Pay at Store\", \"Transfer Money to Family\"]',NULL,'[{\"1-2\": 0.6, \"3-4\": 0.4}, {\"1-2\": 0.6, \"3-4\": 0.4}, {\"1-2\": 0.6, \"3-4\": 0.4}, {\"1-2\": 0.6, \"3-4\": 0.4}, {\"1-2\": 0.6, \"3-4\": 0.4}]','product_name','[\"monthly\", \"monthly\", \"monthly\", \"daily\", \"daily\"]','[\"\", \"\", \"\", \"\", \"account_id\"]'),(27,'transaction','(\'product_name\' == \'Premier Saving Account\')','transactions','[\"Utility Bill Payments\", \"Cash Deposit\", \"Cash Withdrawal\"]',NULL,'[{\"1-2\": 0.6, \"3-4\": 0.4}, {\"1-2\": 0.6, \"3-4\": 0.4}, {\"1-2\": 0.6, \"3-4\": 0.4}]','product_name','[\"monthly\", \"monthly\", \"monthly\"]',NULL),(28,'transaction','(\'product_name\' == \'Sr. Citizen Saving Account\')','transactions','[\"Receive Rent\", \"Receive Pension\", \"Pay at Store\", \"Cash Deposit\", \"Cash Withdrawal\", \"Utility Bill Pay\"]',NULL,'[{\"1-2\": 0.6, \"3-4\": 0.4}, {\"1-2\": 0.6, \"3-4\": 0.4}, {\"1-2\": 0.6, \"3-4\": 0.4}, {\"1-2\": 0.6, \"3-4\": 0.4}, {\"1-2\": 0.6, \"3-4\": 0.4}, {\"1-2\": 0.6, \"3-4\": 0.4}]','product_name','[\"monthly\", \"monthly\", \"monthly\", \"monthly\", \"daily\", \"daily\"]',NULL);
/*!40000 ALTER TABLE `table_relationship_def` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Current Database: `output`
--

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `output` /*!40100 DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;

USE `output`;

--
-- Current Database: `joblogdb`
--

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `joblogdb` /*!40100 DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;

USE `joblogdb`;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2019-07-24 16:44:57
