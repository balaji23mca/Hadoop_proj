from components.core_components.utils.database.db_helper import save_config

column_prptys_meta = [
    {
        "central_tendency_measure" : None,
        "column_data_type" : "varchar",
        "column_index" : 1,
        "column_length" : 11,
        "column_name" : "persona_id",
        "correlation" : None,
        "distribution" : None,
        "generator_name" : "SequencialGenerator",
        "parameters" : "{\"start\": 1, \"prefix\": \"\"}",
        "rule" : None,
        "table_id" : 1,
        "table_name" : "Persona",
        "table_parameters" : None
    },
    {
        "central_tendency_measure" : None,
        "column_data_type" : "varchar",
        "column_index" : 2,
        "column_length" : 11,
        "column_name" : "gender",
        "correlation" : None,
        "distribution" : "choice",
        "generator_name" : "ListGenerator",
        "parameters" : "{\"a\": [\"male\", \"female\"], \"p\": [0.6, 0.4]}",
        "rule" : None,
        "table_id" : 1,
        "table_name" : "Persona",
        "table_parameters" : None
    },
    {
        "central_tendency_measure" : None,
        "column_data_type" : "int",
        "column_index" : 3,
        "column_length" : 11,
        "column_name" : "age",
        "correlation" : None,
        "distribution" : "choice",
        "generator_name" : "BucketSeriesGenerator",
        "parameters" : "{\"a\": [\"13,30\", \"30,40\", \"40,50\", \"50,60\"], \"p\": [0.3, 0.2, 0.2, 0.3]}",
        "rule" : None,
        "table_id" : 1,
        "table_name" : "Persona",
        "table_parameters" : None
    },
    {
        "central_tendency_measure" : None,
        "column_data_type" : "varchar",
        "column_index" : 4,
        "column_length" : 11,
        "column_name" : "minor_major",
        "correlation" : None,
        "distribution" : None,
        "generator_name" : "DependentColumnGenerator",
        "parameters" : "{\"choices\": [\"major\", \"minor\"], \"conditions\": \"[(age >= 18) | (age < 18)]\", \"dependent_column\": [\"age\"]}",
        "rule" : None,
        "table_id" : 1,
        "table_name" : "Persona",
        "table_parameters" : None
    },
    {
        "central_tendency_measure" : None,
        "column_data_type" : "varchar",
        "column_index" : 5,
        "column_length" : 11,
        "column_name" : "marital_status",
        "correlation" : None,
        "distribution" : "choice",
        "generator_name" : "ListGenerator",
        "parameters" : "{\"a\": [\"married\", \"widowed\", \"never_married\", \"divorced\", \"separated\"], \"p\": [0.565, 0.225, 0.0525, 0.1425, 0.015]}",
        "rule" : "{\"action\": \"never_married\", \"conditions\": \"('minor_major' == 'minor')\", \"dependent_column\": [\"minor_major\"]}",
        "table_id" : 1,
        "table_name" : "Persona",
        "table_parameters" : None
    },
    {
        "central_tendency_measure" : None,
        "column_data_type" : "varchar",
        "column_index" : 6,
        "column_length" : 11,
        "column_name" : "employment_status",
        "correlation" : None,
        "distribution" : "choice",
        "generator_name" : "ListGenerator",
        "parameters" : "{\"a\": [\"Y\", \"N\"], \"p\": [0.9, 0.1]}",
        "rule" : "{\"action\": \"N\", \"conditions\": \"('minor_major' == 'minor')\", \"dependent_column\": [\"minor_major\"]}",
        "table_id" : 1,
        "table_name" : "Persona",
        "table_parameters" : None
    },
    {
        "central_tendency_measure" : None,
        "column_data_type" : "varchar",
        "column_index" : 7,
        "column_length" : 12,
        "column_name" : "current_employment_start_date",
        "correlation" : None,
        "distribution" : None,
        "generator_name" : "FakerGenerator",
        "parameters" : "{\"api\": \"Datetime\", \"method\": \"datetime\", \"date_scope\": {\"end\": 2018, \"start\": 2002}}",
        "rule" : None,
        "table_id" : 1,
        "table_name" : "Persona",
        "table_parameters" : None
    },
    {
        "central_tendency_measure" : None,
        "column_data_type" : "varchar",
        "column_index" : 8,
        "column_length" : 15,
        "column_name" : "job_title",
        "correlation" : None,
        "distribution" : "choice",
        "generator_name" : "ListGenerator",
        "parameters" : "{\"a\": [\"Student\", \"Software Developer\", \"Admin Assistant\", \"Director- Small Building Firm\", \"Analyst in City Brokerage Farm\", \"Single Shop Owner\", \"Bank Employee\", \"Mobile Hair Stylist without own salon\", \"Restaurant Chain Owner\", \"Experienced Architect\", \"Retired Employee\"], \"p\": [0.1, 0.2, 0.05, 0.05, 0.1, 0.1, 0.1, 0.05, 0.05, 0.1, 0.1]}",
        "rule" : "{\"action\": \"Minor\", \"conditions\": \"('minor_major' == 'minor')\", \"dependent_column\": [\"minor_major\"]}",
        "table_id" : 1,
        "table_name" : "Persona",
        "table_parameters" : None
    },
    {
        "central_tendency_measure" : None,
        "column_data_type" : "varchar",
        "column_index" : 9,
        "column_length" : 15,
        "column_name" : "salary",
        "correlation" : None,
        "distribution" : None,
        "generator_name" : "CorrelatedGenerator",
        "parameters" : "{\"act_low\": 50000, \"Exp_corr\": 0.8, \"act_high\": 80000, \"feature1\": \"age\", \"feature2\": \"salary\", \"table_name\": \"Persona\", \"column_name\": \"age\"}",
        "rule" : None,
        "table_id" : 1,
        "table_name" : "Persona",
        "table_parameters" : None
    },
    {
        "central_tendency_measure" : None,
        "column_data_type" : "varchar",
        "column_index" : 10,
        "column_length" : 15,
        "column_name" : "total_income",
        "correlation" : None,
        "distribution" : None,
        "generator_name" : "CorrelatedGenerator",
        "parameters" : "{\"act_low\": 600000, \"Exp_corr\": 0.8, \"act_high\": 960000, \"feature1\": \"age\", \"feature2\": \"total_income\", \"table_name\": \"Persona\", \"column_name\": \"age\"}",
        "rule" : None,
        "table_id" : 1,
        "table_name" : "Persona",
        "table_parameters" : None
    }
]

table_property_meta =[
    {
        "table_id" : 1,
        "table_name" : "Persona",
        "tabledescription" : "Person table",
        "dependency_level" : 0,
        "lastupddate" : "03/25/2019",
        "table_parameters" : "{\"master_seed\": 1234}",
        "status" : "Y",
        "related_tables" : None,
        "type" : "{\"size\": 100, \"relationship_type\": \"PERSONA\"}"
    },
    {
        "table_id" : 2,
        "table_name" : "Person",
        "tabledescription" : "user table",
        "dependency_level" : 1,
        "lastupddate" : "03/25/2019",
        "table_parameters" : "{\"master_seed\": 1234}",
        "status" : "Y",
        "related_tables" : "{\"size\": 100, \"table\": \"Persona\"}",
        "type" : "{\"relationship_type\": \"PARTICULARS\"}"
    },
    {
        "table_id" : 3,
        "table_name" : "Product",
        "tabledescription" : "Account",
        "dependency_level" : 1,
        "lastupddate" : "03/25/2019",
        "table_parameters" : "{\"master_seed\": 1234, \"sql_file_path\": \"product_static_data.sql\", \"sql_file_path_type\": \"RELATIVE\"}",
        "status" : "Y",
        "related_tables" : None,
        "type" : "{\"relationship_type\": \"STATIC\"}"
    },
    {
        "table_id" : 4,
        "table_name" : "Account",
        "tabledescription" : "Account table",
        "dependency_level" : 2,
        "lastupddate" : "03/25/2019",
        "table_parameters" : "{\"groups\": [{\"conditions\": \"('age' <  18)\", \"iterations\": 2, \"dependent_column\": [\"age\"]}, {\"conditions\": \"('age' >  18)\", \"iterations\": 1, \"dependent_column\": [\"age\"]}], \"master_seed\": 1234}",
        "status" : "Y",
        "related_tables" : "{\"size\": 100, \"table\": \"Person\"}",
        "type" : "{\"degree\": 1, \"relationship_type\": \"ACTIVITY\"}"
    },
    {
        "table_id" : 5,
        "table_name" : "Transaction",
        "tabledescription" : "Transaction table",
        "dependency_level" : 3,
        "lastupddate" : "03/25/2019",
        "table_parameters" : "{\"groups\": [{\"choices\": [{\"transaction_name\": \"(Own bank ATM withdrawal ,Other bank ATM withdrawal , Self withdrawal)\"}], \"conditions\": \"('transactions'== 'Cash withdrawal')\", \"dependent_column\": [\"transactions\"]}, {\"choices\": [{\"account\": \"COUNTERPARTY\"}, {\"transaction_name\": \"Transfer\"}], \"conditions\": \"('transactions' != 'Cash withdrawal')\", \"dependent_column\": [\"transactions\"]}], \"master_seed\": 1234}",
        "status" : "Y",
        "related_tables" : "{\"size\": 100, \"table\": \"Account\"}",
        "type" : "{\"degree\": 1, \"relationship_type\": \"ACTIVITY\"}"
    }
]

if __name__ == '__main__':
    save_config(column_prptys_meta, "column_property")
    save_config(table_property_meta, "table_property", indexing=False)
