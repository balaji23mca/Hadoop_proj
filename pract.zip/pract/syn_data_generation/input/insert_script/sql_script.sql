
DROP TABLE IF EXISTS `column_property`;

CREATE TABLE `column_property` (
  `central_tendency_measure` text,
  `column_data_type` text,
  `column_index` bigint(20) DEFAULT NULL,
  `column_length` bigint(20) DEFAULT NULL,
  `column_name` text,
  `correlation` text,
  `distribution_type` text,
  `generator_name` text,
  `parameters` json DEFAULT NULL,
  `rule` json DEFAULT NULL,
  `table_id` bigint(20) DEFAULT NULL,
  `table_name` text,
  `index` int(11) NOT NULL AUTO_INCREMENT,
  `table_parameters` json DEFAULT NULL,
  PRIMARY KEY (`index`),
  UNIQUE KEY `index_UNIQUE` (`index`)
) ENGINE=InnoDB AUTO_INCREMENT=35 DEFAULT CHARSET=latin1;


DROP TABLE IF EXISTS `table_property`;

CREATE TABLE `table_property` (
  `table_id` bigint(20) NOT NULL,
  `table_name` text NOT NULL,
  `tabledescription` text,
  `dependency_level` bigint(20) NOT NULL,
  `lastupddate` text,
  `countofrecords` bigint(20) DEFAULT NULL,
  `type` varchar(45) NOT NULL,
  `table_parameters` json DEFAULT NULL,
  `status` varchar(45) DEFAULT 'Y',
  `related_tables` json DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1
